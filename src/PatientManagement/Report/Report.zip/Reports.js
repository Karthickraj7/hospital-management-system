import React, { useRef, useState, useEffect, useCallback } from "react";
// import Barcode from "react-barcode";
import "./Report.css";
import axios from "axios";
import { useSelector } from "react-redux";
import jsPDF from "jspdf";
import { useReactToPrint } from "react-to-print";
import { toPng } from "html-to-image";
import { useNavigate } from "react-router-dom";
import Docsign from "../../Assets/aparna.jpg";
import Microsign from "../../Assets/Micro.png";
import { DataGrid } from "@mui/x-data-grid";
import JsBarcode from "jsbarcode";
import { createTheme, ThemeProvider } from "@mui/material/styles";
import { TiArrowDownThick, TiArrowUpThick } from "react-icons/ti";
import Dialog from "@mui/material/Dialog";
import DialogTitle from "@mui/material/DialogTitle";
import DialogContent from "@mui/material/DialogContent";
import DialogActions from "@mui/material/DialogActions";
import TextField from "@mui/material/TextField";
import ReactToPrint from "react-to-print";
import mammoth from "mammoth";
import ClassicEditor from "@ckeditor/ckeditor5-build-classic";
import { CKEditor } from "@ckeditor/ckeditor5-react";
import "../LabTechnician/ckeditor-custom.css";
import { Button, Select, MenuItem } from "@mui/material";
import html2canvas from "html2canvas";
import sdalogo from "../../Assets/sdalogo.jpg";
import isologo from "../../Assets/isologo.jpg";

import KMCHlogo from "../../Assets/KMCHlogo.png";

const theme = createTheme({
  components: {
    MuiDataGrid: {
      styleOverrides: {
        columnHeader: {
          backgroundColor: "var(--ProjectColor)",
          textAlign: "Center",
        },
        root: {
          "& .MuiDataGrid-root .MuiDataGrid-columnHeader, .MuiDataGrid-columnHeaderTitleContainer":
            {
              textAlign: "center",
              display: "flex !important",
              justifyContent: "center !important",
            },
          "& .MuiDataGrid-window": {
            overflow: "hidden !important",
          },
        },
        cell: {
          borderTop: "0px !important",
          borderBottom: "1px solid  var(--ProjectColor) !important",
          display: "flex",
          justifyContent: "center",
        },
      },
    },
  },
});

function CancelAppointmentDialog({
  open,
  onClose,
  onConfirm,
  cancelReason,
  setCancelReason,
}) {
  const handleConfirm = () => {
    // Call the onConfirm callback with the cancellation reason
    onConfirm(cancelReason);
    // Close the dialog
    onClose();
  };

  const handleClose = () => {
    setCancelReason("");
    onClose();
  };

  return (
    <Dialog open={open} onClose={onClose}>
      <DialogTitle>Reprint Register Reason</DialogTitle>
      <DialogContent>
        <TextField
          label="Reprint Reason"
          multiline
          rows={4}
          variant="outlined"
          fullWidth
          value={cancelReason}
          onChange={(e) => setCancelReason(e.target.value)}
        />
      </DialogContent>
      <DialogActions>
        <Button onClick={handleClose} color="primary">
          Close
        </Button>
        <Button onClick={handleConfirm} color="primary">
          Save
        </Button>
      </DialogActions>
    </Dialog>
  );
}

const generateBarcode = (value) => {
  try {
    const canvas = document.createElement("canvas");
    JsBarcode(canvas, value, {
      format: "CODE128",
      lineColor: "black",
      width: 2,
      height: 100,
      displayValue: true,
    });

    const image = canvas.toDataURL("image/png");
    console.log("image", image); // Check the generated image data URL
    return image;
  } catch (error) {
    console.error("Error generating barcode:", error);
  }
};

const TableComponent = React.forwardRef(
  (
    {
      patinetbillingbarcode,
      patinetbillingQr,
      capturedatas,
      report,
      summa,
      ClinicDetials,
      navigate,
      getSensitivityColor,
      uniqueOrganisms,
      alphabetHeaders,
      summa1,
      emailsent,
      SignPerson,
      printpapaer,
      isNoRendered,
      microandhistonumber,
      formatData,
      formatHeading,
      editMode,
      autoResizeTextarea,
      handleeditchange,
      setFormatData,
      formatMethodName,
      openmodels,
      setopenmodels,
      contentRef,
      uploadPlugin,
      isSidebarOpen,
      setContent,
      content,
      editmicrodata,
      formatName,
      touppercasefun,
      handleMouseUp,
      handleContentEditableInputChange,
      showmodel,
      setshowmodel,
      culturevalue,
      page,
      pageSize,
      dynamicColumns,
      setPage,
      showdown,
      totalPages,
      setEditMode,
      handleupdatesencitivity,
      handleSensitivityChange,
      hasAbnormalValues,
      imagePreview,
      getStatus,
      editableRef,
      handleBioChange,
      editBioData,
      handleInputChange,
      patientdetails,
    },
    ref
  ) => {
    return (
      <div>
        {summa?.length > 0 && (
          <table ref={ref} className="print-table33">
            <thead className="print_header">
              <div>
                {!emailsent && (
                  <div
                    className="hhheader"
                    style={{
                      height: "127px",
                      width: "100%",
                    }}
                  ></div>
                )}

                {emailsent && (
                  <div className="dsdwd_p9o">
                    <tr className="ededfedf_9jui">
                      <div className="hdyd_p05421oo">
                        <img src={sdalogo} alt="logo" />
                      </div>
                      <td className="hdyd_p05421">
                        <div className="dssdfcwef_p9">
                          <div>
                            <img src={KMCHlogo} alt="logo" />
                          </div>

<div >
                          <div className="dchfejjj0p">
                            <div className="dchfejjj0p_hhdc">
                              <h2>KARUNA MEDICAL COLLEGE HOSPITAL</h2>{" "}
                            </div>
                          </div>

                          <div className="dchfejjj0p_hhdc">
                            <h3>
                              VILAYODI - CHITTUR - PALAKKAD - KERALA - 678103
                            </h3>
                          </div>
                          </div>
                        </div>

                        <div className="hdyd_p05421">
                          <img src={isologo} alt="logo" />
                        </div>
                      </td>

                      <td
                        className="jjkd8i_line"
                        style={{
                          height: "3px",
                          width: "100%",
                          backgroundColor: "grey",
                          marginBottom: "5px",
                        }}
                      ></td>
                    </tr>
                  </div>
                )}

                {summa.some((item) => item.Report_Type === "OT") && (
                  <>
                    <div className="wiioo900">
                      <td>
                        <h3>
                          {capturedatas.Patient_Name}
                          {" , "}
                          {capturedatas.Refering_Hospital}
                        </h3>
                      </td>
                    </div>
                    <div className="wiioo900 nbjui_94d">
                      <tr className="new_billing_address_2 ededfedf_9jui">
                        <td className="new_billing_div_report ffddffn">
                          <label>
                            Collected <p>:</p>
                          </label>
                          <span>
                            {
                              summa[0]?.invoicedetails
                                ?.AnalyseInvestigationResult
                            }
                          </span>
                        </td>
                        <td className="new_billing_div_report ffddffn">
                          <label>
                            Received <p>:</p>
                          </label>
                          <span>
                            {
                              summa[0]?.invoicedetails
                                ?.AnalyseInvestigationSenior
                            }
                          </span>
                        </td>

                        <td className="new_billing_div_report hhh_p2q">
                          <label>
                            Barcode <p>:</p>
                          </label>
                          <span>{capturedatas.Barcode}</span>
                        </td>
                      </tr>
                    </div>
                  </>
                )}
              </div>
            </thead>

            <tbody className="print_body Selected-table-container">
              {console.log(summa)}

              {summa?.map((dpt, undex) => {
                if (
                  dpt.department === "MICROBIOLOGY" && // Exclude HISTOPATHOLOGY
                  dpt.testdetails.some((p) => p.Test_Code !== "RD0098")
                ) {
                  return (
                    <div key={undex} style={{ pageBreakAfter: "always" }}>
                      {dpt?.testdetails.map((group, groupIndex) => (
                        <table
                          key={groupIndex}
                          style={{
                            width: "91%",
                            position: "relative",
                            left: "50px",
                            pageBreakAfter: "always",
                          }}
                        >
                          {/* Each report type gets its own <thead> with the specific micronumber */}
                          <thead className="print_header">
                            {!summa.some(
                              (item) => item.Report_Type === "OT"
                            ) && (
                              <div className="wiioo900">
                                <tr className="new_billing_address_2 ededfedf_9jui">
                                  <td className="Register_btn_con_barcode">
                                    <div id="get_imagecontent_1">
                                      <img
                                        src={
                                          patinetbillingbarcode
                                            ? generateBarcode(
                                                patinetbillingbarcode
                                              )
                                            : ""
                                        }
                                        alt="barcodeimage"
                                        style={{
                                          width: "170px",
                                          height: "40px",
                                          objectFit: "fill",
                                        }}
                                      />
                                    </div>
                                  </td>
                                  <td className="new_billing_div_report">
                                    <label>
                                      Patient Name <p>:</p>
                                    </label>
                                    <span>
                                      {capturedatas.Title}.{" "}
                                      {capturedatas.Patient_Name}
                                    </span>
                                  </td>
                                  {microandhistonumber === "" && (
                                    <td className="new_billing_div_report">
                                      <label>
                                        Visit ID <p>:</p>
                                      </label>
                                      <span>{capturedatas.Visit_Id}</span>
                                    </td>
                                  )}
                                  <td className="new_billing_div_report">
                                    <label>
                                      Age/Gender <p>:</p>
                                    </label>
                                    <span>
                                      {capturedatas.Age}{" "}
                                      {capturedatas?.Time_Period}s/{" "}
                                      {capturedatas.Gender}
                                    </span>
                                  </td>
                                  <td className="new_billing_div_report">
                                    <label>
                                      Ref.Dr <p>:</p>
                                    </label>
                                    <span>{capturedatas.Refering_Doctor}</span>
                                  </td>
                                  {/* Display the micronumber specific to this report type */}
                                  {group.micronumber !== "" && (
                                    <td className="new_billing_div_report">
                                      <label>
                                        Micro.no <p>:</p>
                                      </label>
                                      <span>{group.micronumber}</span>
                                    </td>
                                  )}
                                  {/* <td className="new_billing_div_report">
                            <label>
                              Micro.no <p>:</p>
                            </label>
                            <span>{group.micronumber || "N/A"}</span>
                          </td> */}
                                  <td className="new_billing_div_report">
                                    <label>
                                      Ref Hospital <p>:</p>
                                    </label>
                                    <span>
                                      {capturedatas.Refering_Hospital}
                                    </span>
                                  </td>
                                </tr>

                                <tr className="new_billing_address_2 ededfedf_9jui">
                                  <td className="Register_btn_con_barcode">
                                    <div id="get_imagecontent_2">
                                      <img
                                        src={
                                          capturedatas && capturedatas.Barcode
                                            ? generateBarcode(
                                                capturedatas.Barcode
                                              )
                                            : ""
                                        }
                                        alt="barcodeimage"
                                        className="get_imagecontent_2_imhhhh"
                                      />
                                    </div>
                                  </td>
                                  <td className="new_billing_div_report ffddffn">
                                    <label>
                                      Invoice No <p>:</p>
                                    </label>
                                    <span>{capturedatas.Billing_Invoice}</span>
                                  </td>
                                  <td className="new_billing_div_report ffddffn">
                                    <label>
                                      Collected <p>:</p>
                                    </label>
                                    <span>
                                      {
                                        summa[0]?.invoicedetails
                                          ?.AnalyseInvestigationResult
                                      }
                                    </span>
                                  </td>
                                  <td className="new_billing_div_report ffddffn">
                                    <label>
                                      Received <p>:</p>
                                    </label>
                                    <span>
                                      {
                                        summa[0]?.invoicedetails
                                          ?.AnalyseInvestigationSenior
                                      }
                                    </span>
                                  </td>
                                  <td className="new_billing_div_report ffddffn">
                                    <label>
                                      Reported <p>:</p>
                                    </label>
                                    <span>
                                      {
                                        summa[0]?.invoicedetails
                                          ?.Approve_Test_Pathologist
                                      }
                                    </span>
                                  </td>
                                </tr>
                              </div>
                            )}
                          </thead>

                          <tbody>
                            <div className="print-page3jjj">
                              <div className="culture_report_data">
                                <div className="culture_test_header">
                                  <p> Service - {dpt.department}</p>
                                </div>
                                {console.log("Service", group?.Report_Type)}

                                {/* OT Report */}
                                {group?.Report_Type === "Ot" && (
                                  <div>
                                    <table className="report_table report_table_for_micro">
                                      <tbody className="print_body Selected-table-container">
                                        <tr>
                                          <td>
                                            <h3>{dpt.department}</h3>
                                            <div className="completed_report_1111">
                                              <div className="completed_report completed_report04948 gghbuy_o9">
                                                <div
                                                  style={{
                                                    display: "flex",
                                                    flexDirection: "column",
                                                    justifyContent: "center",
                                                    width: "100%",
                                                  }}
                                                  dangerouslySetInnerHTML={{
                                                    __html: group?.EditContent,
                                                  }}
                                                />
                                              </div>
                                            </div>
                                          </td>
                                        </tr>
                                      </tbody>
                                    </table>
                                    {group?.Report_Status !==
                                      "Preliminary Report" && (
                                      <div className="Add_items_Purchase_Master yydd_end_reprt">
                                        <span> - End of Report - </span>
                                      </div>
                                    )}
                                  </div>
                                )}

                                {/* NoGrowth Report */}
                                {group?.Report_Type === "NoGrowth" && (
                                  <div className="culturetest_div_head jgg_9i9kj Histo_new_css_div_head_po90">
                                    {dpt.department === "MICROBIOLOGY" && (
                                      <span className="mkdijcfisd_o99">
                                        Visit ID : {capturedatas.Visit_Id}{" "}
                                      </span>
                                    )}

                                    {group.Sample_Specimen !== "" && (
                                      <div className="culturetest_div Histo_new_css_div">
                                        <label className="headerculture">
                                          Nature of specimen<span>:</span>
                                        </label>
                                        {editMode ? (
                                          <textarea
                                            name={`Sample-${group.Test_Code}`}
                                            onChange={handleeditchange}
                                            defaultValue={
                                              group?.Sample_Specimen
                                            }
                                            onBeforeInput={autoResizeTextarea}
                                            onInput={autoResizeTextarea}
                                          />
                                        ) : (
                                          <p className="dataforprint">
                                            {group?.Sample_Specimen}
                                          </p>
                                        )}
                                      </div>
                                    )}

                                    <div className="culturetest_div Histo_new_css_div">
                                      <label className="headerculture">
                                        Test Requested<span>:</span>
                                      </label>
                                      <p className="dataforprint">
                                        {group?.DisplayText}
                                      </p>
                                    </div>
                                    <div className="culturetest_div Histo_new_css_div hewty_8j">
                                      <label className="headerculture">
                                        Report Status<span>:</span>
                                      </label>
                                      {editMode ? (
                                        <select
                                          className=""
                                          name={`reportstatus-${group.Test_Code}`}
                                          onChange={handleeditchange}
                                        >
                                          <option value="">Select</option>
                                          <option value="Final Report">
                                            Final Report
                                          </option>
                                          <option value="Preliminary Report">
                                            Preliminary Report
                                          </option>
                                        </select>
                                      ) : (
                                        <p className="dataforprint">
                                          {group?.Report_Status ||
                                            "Final Report"}
                                        </p>
                                      )}
                                    </div>
                                    {group.Microscopy_Data !== "" && (
                                      <div className="culturetest_div Histo_new_css_div">
                                        <label className="headerculture">
                                          Microscopy<span>:</span>
                                        </label>
                                        {editMode ? (
                                          <textarea
                                            name={`microscopy-${group.Test_Code}`}
                                            onChange={handleeditchange}
                                            defaultValue={
                                              group?.Microscopy_Data
                                            }
                                            onBeforeInput={autoResizeTextarea}
                                            onInput={autoResizeTextarea}
                                          />
                                        ) : (
                                          <p className="dataforprint">
                                            {group?.Microscopy_Data}
                                          </p>
                                        )}
                                      </div>
                                    )}
                                    {group.Culture_Report !== "" && (
                                      <div className="culturetest_div Histo_new_css_div">
                                        <label className="headerculture">
                                          Culture Report<span>:</span>
                                        </label>
                                        {editMode ? (
                                          <textarea
                                            name={`culturereport-${group.Test_Code}`}
                                            onChange={handleeditchange}
                                            defaultValue={group?.Culture_Report}
                                            onBeforeInput={autoResizeTextarea}
                                            onInput={autoResizeTextarea}
                                          />
                                        ) : (
                                          <p className="dataforprint">
                                            {group?.Culture_Report}
                                          </p>
                                        )}
                                      </div>
                                    )}
                                    {group?.Report_Status !==
                                      "Preliminary Report" && (
                                      <div className="Add_items_Purchase_Master yydd_end_reprt">
                                        <span> - End of Report - </span>
                                      </div>
                                    )}
                                  </div>
                                )}

                                {/* Isolated Report */}
                                {group?.Report_Type === "Isolated" && (
                                  <div className="culturetest_div_head jgg_9i9kj Histo_new_css_div_head_po90">
                                    {dpt.department === "MICROBIOLOGY" && (
                                      <span className="mkdijcfisd_o99">
                                        Visit ID : {capturedatas.Visit_Id}{" "}
                                      </span>
                                    )}
                                    {group.Sample_Specimen !== "" && (
                                      <div className="culturetest_div Histo_new_css_div">
                                        <label className="headerculture">
                                          Nature of specimen<span>:</span>
                                        </label>
                                        {editMode ? (
                                          <textarea
                                            name={`Sample-${group.Test_Code}`}
                                            onChange={handleeditchange}
                                            defaultValue={
                                              group?.Sample_Specimen
                                            }
                                            onBeforeInput={autoResizeTextarea}
                                            onInput={autoResizeTextarea}
                                          />
                                        ) : (
                                          <p className="dataforprint">
                                            {group?.Sample_Specimen}
                                          </p>
                                        )}
                                      </div>
                                    )}

                                    <div className="culturetest_div Histo_new_css_div">
                                      <label className="headerculture">
                                        Test Requested<span>:</span>
                                      </label>
                                      <p className="dataforprint">
                                        {group?.DisplayText}
                                      </p>
                                    </div>
                                    <div className="culturetest_div Histo_new_css_div hewty_8j">
                                      <label className="headerculture">
                                        Report Status<span>:</span>
                                      </label>
                                      {editMode ? (
                                        <select
                                          className=""
                                          name={`reportstatus-${group.Test_Code}`}
                                          onChange={handleeditchange}
                                        >
                                          <option value="">Select</option>
                                          <option value="Final Report">
                                            Final Report
                                          </option>
                                          <option value="Preliminary Report">
                                            Preliminary Report
                                          </option>
                                        </select>
                                      ) : (
                                        <p className="dataforprint">
                                          {group?.Report_Status ||
                                            "Final Report"}
                                        </p>
                                      )}
                                    </div>
                                    {group.Microscopy_Data !== "" && (
                                      <div className="culturetest_div Histo_new_css_div">
                                        <label className="headerculture">
                                          Microscopy<span>:</span>
                                        </label>
                                        {editMode ? (
                                          <textarea
                                            name={`microscopy-${group.Test_Code}`}
                                            onChange={handleeditchange}
                                            defaultValue={
                                              group?.Microscopy_Data
                                            }
                                            onBeforeInput={autoResizeTextarea}
                                            onInput={autoResizeTextarea}
                                          />
                                        ) : (
                                          <p className="dataforprint">
                                            {group?.Microscopy_Data}
                                          </p>
                                        )}
                                      </div>
                                    )}
                                    {group.Bacteria_Isolated !== "" && (
                                      <div className="culturetest_div Histo_new_css_div">
                                        <label className="headerculture">
                                          Bacteria Isolated<span>:</span>
                                        </label>
                                        {editMode ? (
                                          <textarea
                                            name={`bacteriaisolated-${group.Test_Code}`}
                                            onChange={handleeditchange}
                                            defaultValue={
                                              group?.Bacteria_Isolated
                                            }
                                            onBeforeInput={autoResizeTextarea}
                                            onInput={autoResizeTextarea}
                                          />
                                        ) : (
                                          <p className="dataforprint">
                                            {group?.Bacteria_Isolated}
                                          </p>
                                        )}
                                      </div>
                                    )}
                                    {group?.Report_Status !==
                                      "Preliminary Report" && (
                                      <div className="Add_items_Purchase_Master yydd_end_reprt">
                                        <span> - End of Report - </span>
                                      </div>
                                    )}
                                  </div>
                                )}

                                {/* Sensitivity Report */}
                                {group?.Report_Type === "Sensitivity" && (
                                  <div>
                                    <div className="culturetest_div_head jgg_9i9kj Histo_new_css_div_head_po90">
                                      {dpt.department === "MICROBIOLOGY" && (
                                        <span className="mkdijcfisd_o99">
                                          Visit ID : {capturedatas.Visit_Id}{" "}
                                        </span>
                                      )}
                                      {group.Sample_Specimen !== "" && (
                                        <div className="culturetest_div Histo_new_css_div">
                                          <label className="headerculture">
                                            Nature of specimen<span>:</span>
                                          </label>
                                          {editMode ? (
                                            <textarea
                                              name={`Sample-${group.Test_Code}`}
                                              onChange={handleeditchange}
                                              defaultValue={
                                                group?.Sample_Specimen
                                              }
                                              onBeforeInput={autoResizeTextarea}
                                              onInput={autoResizeTextarea}
                                            />
                                          ) : (
                                            <p className="dataforprint">
                                              {group?.Sample_Specimen}
                                            </p>
                                          )}
                                        </div>
                                      )}

                                      <div className="culturetest_div Histo_new_css_div">
                                        <label className="headerculture">
                                          Test Requested<span>:</span>
                                        </label>
                                        <p className="dataforprint">
                                          {group?.DisplayText}
                                        </p>
                                      </div>
                                      {group.Microscopy_Data !== "" && (
                                        <div className="culturetest_div Histo_new_css_div">
                                          <label className="headerculture">
                                            Microscopy<span>:</span>
                                          </label>
                                          {editMode ? (
                                            <textarea
                                              name={`microscopy-${group.Test_Code}`}
                                              onChange={handleeditchange}
                                              defaultValue={
                                                group?.Microscopy_Data
                                              }
                                              onBeforeInput={autoResizeTextarea}
                                              onInput={autoResizeTextarea}
                                            />
                                          ) : (
                                            <p className="dataforprint">
                                              {group?.Microscopy_Data}
                                            </p>
                                          )}
                                        </div>
                                      )}
                                    </div>
                                    <div className="culturetest_div Histo_new_css_div ergfregreg_64">
                                      <label className="headerculture">
                                        Organism Isolated<span>:</span>
                                      </label>
                                      <p className="dataforprint summaprintsummauuu">
                                        <ol
                                          style={{
                                            listStyleType: "upper-alpha",
                                            textAlign: "start",
                                            paddingLeft: "10px",
                                          }}
                                        >
                                          {group.OrganismDetails?.map(
                                            (item, index) =>
                                              Object.entries(item).map(
                                                ([organism], orgIndex) => (
                                                  <li key={orgIndex}>
                                                    <i
                                                      style={{
                                                        fontWeight: "600",
                                                      }}
                                                    >
                                                      {organism}
                                                    </i>{" "}
                                                    - <span>Colony Count</span>{" "}
                                                    - {group?.Colony_Count}{" "}
                                                    {group?.UOM}
                                                  </li>
                                                )
                                              )
                                          )}
                                        </ol>
                                      </p>
                                    </div>
                                    <br />
                                    <div className="new_billing_Report_details">
                                      <div className="table-container554 dsfgrh_fx">
                                        {/* First Table */}
                                        <table className="report_table report_table_for_micro">
                                          <thead>
                                            <tr>
                                              <th>Antibiotics</th>
                                              {console.log(
                                                "alphabetHeaders",
                                                alphabetHeaders
                                              )}
                                              {alphabetHeaders.map(
                                                (alpha, index) => (
                                                  <th key={index}>
                                                    {console.log(
                                                      "alpha",
                                                      alpha
                                                    )}
                                                    {alpha}
                                                  </th>
                                                )
                                              )}
                                            </tr>
                                          </thead>
                                          <tbody>
                                            {group?.OrganismDetails[0][
                                              Object.keys(
                                                group?.OrganismDetails[0]
                                              )[0]
                                            ]
                                              .slice(
                                                0,
                                                Math.ceil(
                                                  group?.OrganismDetails[0][
                                                    Object.keys(
                                                      group?.OrganismDetails[0]
                                                    )[0]
                                                  ].length / 3
                                                )
                                              )
                                              .map((item, index) => (
                                                <tr key={index}>
                                                  <td>{item.Antibiotic}</td>
                                                  {group?.OrganismDetails.map(
                                                    (orgDetail, orgIndex) =>
                                                      Object.entries(
                                                        orgDetail
                                                      ).map(
                                                        (
                                                          [
                                                            organism,
                                                            antibiotics,
                                                          ],
                                                          subIndex
                                                        ) => (
                                                          <td
                                                            key={`${orgIndex}-${subIndex}`}
                                                          >
                                                            <p
                                                              style={{
                                                                color:
                                                                  getSensitivityColor(
                                                                    antibiotics.find(
                                                                      (ant) =>
                                                                        ant.Antibiotic ===
                                                                        item.Antibiotic
                                                                    )
                                                                      ?.SensitivityType
                                                                  ),
                                                              }}
                                                            >
                                                              {(antibiotics.find(
                                                                (ant) =>
                                                                  ant.Antibiotic ===
                                                                  item.Antibiotic
                                                              )
                                                                ?.SensitivityType ===
                                                                "Sensitive" &&
                                                                "S") ||
                                                                (antibiotics.find(
                                                                  (ant) =>
                                                                    ant.Antibiotic ===
                                                                    item.Antibiotic
                                                                )
                                                                  ?.SensitivityType ===
                                                                  "Intermediate" &&
                                                                  "I") ||
                                                                (antibiotics.find(
                                                                  (ant) =>
                                                                    ant.Antibiotic ===
                                                                    item.Antibiotic
                                                                )
                                                                  ?.SensitivityType ===
                                                                  "Resistant" &&
                                                                  "R") ||
                                                                "-"}
                                                            </p>
                                                          </td>
                                                        )
                                                      )
                                                  )}
                                                </tr>
                                              ))}
                                          </tbody>
                                          <tfoot>
                                            <tr>
                                              <td
                                                colSpan={
                                                  group?.OrganismDetails
                                                    .length + 1
                                                }
                                              >
                                                <br />
                                                <div
                                                  style={{
                                                    display: "flex",
                                                    gap: "10px",
                                                  }}
                                                >
                                                  <p style={{ color: "green" }}>
                                                    S
                                                  </p>{" "}
                                                  ----
                                                  <p
                                                    style={{
                                                      fontWeight: "600",
                                                    }}
                                                  >
                                                    Sensitive
                                                  </p>
                                                </div>
                                              </td>
                                            </tr>
                                          </tfoot>
                                        </table>
                                        {/* Second Table */}
                                        <table className="report_table report_table_for_micro">
                                          <thead>
                                            <tr>
                                              <th>Antibiotics</th>
                                              {alphabetHeaders.map(
                                                (alpha, index) => (
                                                  <th key={index}>{alpha}</th>
                                                )
                                              )}
                                            </tr>
                                          </thead>
                                          <tbody>
                                            {group?.OrganismDetails[0][
                                              Object.keys(
                                                group?.OrganismDetails[0]
                                              )[0]
                                            ]
                                              .slice(
                                                Math.ceil(
                                                  group?.OrganismDetails[0][
                                                    Object.keys(
                                                      group?.OrganismDetails[0]
                                                    )[0]
                                                  ].length / 3
                                                ),
                                                2 *
                                                  Math.ceil(
                                                    group?.OrganismDetails[0][
                                                      Object.keys(
                                                        group
                                                          ?.OrganismDetails[0]
                                                      )[0]
                                                    ].length / 3
                                                  )
                                              )
                                              .map((item, index) => (
                                                <tr key={index}>
                                                  <td>{item.Antibiotic}</td>
                                                  {group?.OrganismDetails.map(
                                                    (orgDetail, orgIndex) =>
                                                      Object.entries(
                                                        orgDetail
                                                      ).map(
                                                        (
                                                          [
                                                            organism,
                                                            antibiotics,
                                                          ],
                                                          subIndex
                                                        ) => (
                                                          <td
                                                            key={`${orgIndex}-${subIndex}`}
                                                          >
                                                            <p
                                                              style={{
                                                                color:
                                                                  getSensitivityColor(
                                                                    antibiotics.find(
                                                                      (ant) =>
                                                                        ant.Antibiotic ===
                                                                        item.Antibiotic
                                                                    )
                                                                      ?.SensitivityType
                                                                  ),
                                                              }}
                                                            >
                                                              {(antibiotics.find(
                                                                (ant) =>
                                                                  ant.Antibiotic ===
                                                                  item.Antibiotic
                                                              )
                                                                ?.SensitivityType ===
                                                                "Sensitive" &&
                                                                "S") ||
                                                                (antibiotics.find(
                                                                  (ant) =>
                                                                    ant.Antibiotic ===
                                                                    item.Antibiotic
                                                                )
                                                                  ?.SensitivityType ===
                                                                  "Intermediate" &&
                                                                  "I") ||
                                                                (antibiotics.find(
                                                                  (ant) =>
                                                                    ant.Antibiotic ===
                                                                    item.Antibiotic
                                                                )
                                                                  ?.SensitivityType ===
                                                                  "Resistant" &&
                                                                  "R") ||
                                                                "-"}
                                                            </p>
                                                          </td>
                                                        )
                                                      )
                                                  )}
                                                </tr>
                                              ))}
                                          </tbody>
                                          <tfoot>
                                            <tr>
                                              <td
                                                colSpan={
                                                  group?.OrganismDetails
                                                    .length + 1
                                                }
                                              >
                                                <br />
                                                <div
                                                  style={{
                                                    display: "flex",
                                                    gap: "10px",
                                                  }}
                                                >
                                                  <p style={{ color: "blue" }}>
                                                    I
                                                  </p>{" "}
                                                  ----
                                                  <p
                                                    style={{
                                                      fontWeight: "600",
                                                    }}
                                                  >
                                                    Intermediate
                                                  </p>
                                                </div>
                                              </td>
                                            </tr>
                                          </tfoot>
                                        </table>
                                        {/* Third Table */}
                                        <table className="report_table report_table_for_micro">
                                          <thead>
                                            <tr>
                                              <th>Antibiotics</th>
                                              {alphabetHeaders.map(
                                                (alpha, index) => (
                                                  <th key={index}>{alpha}</th>
                                                )
                                              )}
                                            </tr>
                                          </thead>
                                          <tbody>
                                            {group?.OrganismDetails[0][
                                              Object.keys(
                                                group?.OrganismDetails[0]
                                              )[0]
                                            ]
                                              .slice(
                                                2 *
                                                  Math.ceil(
                                                    group?.OrganismDetails[0][
                                                      Object.keys(
                                                        group
                                                          ?.OrganismDetails[0]
                                                      )[0]
                                                    ].length / 3
                                                  )
                                              )
                                              .map((item, index) => (
                                                <tr key={index}>
                                                  <td>{item.Antibiotic}</td>
                                                  {group?.OrganismDetails.map(
                                                    (orgDetail, orgIndex) =>
                                                      Object.entries(
                                                        orgDetail
                                                      ).map(
                                                        (
                                                          [
                                                            organism,
                                                            antibiotics,
                                                          ],
                                                          subIndex
                                                        ) => (
                                                          <td
                                                            key={`${orgIndex}-${subIndex}`}
                                                          >
                                                            <p
                                                              style={{
                                                                color:
                                                                  getSensitivityColor(
                                                                    antibiotics.find(
                                                                      (ant) =>
                                                                        ant.Antibiotic ===
                                                                        item.Antibiotic
                                                                    )
                                                                      ?.SensitivityType
                                                                  ),
                                                              }}
                                                            >
                                                              {(antibiotics.find(
                                                                (ant) =>
                                                                  ant.Antibiotic ===
                                                                  item.Antibiotic
                                                              )
                                                                ?.SensitivityType ===
                                                                "Sensitive" &&
                                                                "S") ||
                                                                (antibiotics.find(
                                                                  (ant) =>
                                                                    ant.Antibiotic ===
                                                                    item.Antibiotic
                                                                )
                                                                  ?.SensitivityType ===
                                                                  "Intermediate" &&
                                                                  "I") ||
                                                                (antibiotics.find(
                                                                  (ant) =>
                                                                    ant.Antibiotic ===
                                                                    item.Antibiotic
                                                                )
                                                                  ?.SensitivityType ===
                                                                  "Resistant" &&
                                                                  "R") ||
                                                                "-"}
                                                            </p>
                                                          </td>
                                                        )
                                                      )
                                                  )}
                                                </tr>
                                              ))}
                                          </tbody>
                                          <tfoot>
                                            <tr>
                                              <td
                                                colSpan={
                                                  group?.OrganismDetails
                                                    .length + 1
                                                }
                                              >
                                                <br />
                                                <div
                                                  style={{
                                                    display: "flex",
                                                    gap: "10px",
                                                  }}
                                                >
                                                  <p style={{ color: "red" }}>
                                                    R
                                                  </p>{" "}
                                                  ----
                                                  <p
                                                    style={{
                                                      fontWeight: "600",
                                                    }}
                                                  >
                                                    Resistant
                                                  </p>
                                                </div>
                                              </td>
                                            </tr>
                                          </tfoot>
                                        </table>
                                      </div>
                                    </div>
                                    <br />
                                    {group?.Notes !== "" && (
                                      <div className="culturetest_div tffyfcgyt_o Histo_new_css_div micronotessiumam">
                                        <label className="headerculture">
                                          Notes<span>:</span>
                                        </label>
                                        {editMode ? (
                                          <textarea
                                            name={`notes-${group.Test_Code}`}
                                            onChange={handleeditchange}
                                            defaultValue={group?.Notes}
                                            onBeforeInput={autoResizeTextarea}
                                            onInput={autoResizeTextarea}
                                          />
                                        ) : (
                                          <p className="dataforprint">
                                            {group?.Notes}
                                          </p>
                                        )}
                                      </div>
                                    )}
                                    {group?.Report_Status !==
                                      "Preliminary Report" && (
                                      <div className="Add_items_Purchase_Master yydd_end_reprt">
                                        <span> - End of Report - </span>
                                      </div>
                                    )}
                                  </div>
                                )}
                              </div>
                            </div>
                          </tbody>

                          {/* Footer for each report type */}
                          <tfoot className="print_footerr">
                            <tr className="jjxcdsjjej_">
                              <td className="footer_fix_conten_fyft microejeo">
                                <div className="dcnnmjy0s66">
                                  <div className="Register_btn_con_QRcode_fix">
                                    <img
                                      src={patinetbillingQr}
                                      alt="qrcode"
                                      style={{
                                        width: "80px",
                                        height: "80px",
                                        objectFit: "fill",
                                      }}
                                    />
                                  </div>
                                  <div className="doctr_sign_fix7cc doctr_sign_fix7cc_secddg">
                                    {dpt.department === "MICROBIOLOGY" && (
                                      <>
                                        <img
                                          src={Microsign}
                                          alt=""
                                          className="docsign_fix"
                                        />
                                        <p
                                          style={{
                                            fontSize: "11px",
                                            width: "200px",
                                          }}
                                        >
                                          Dr. M. Suresh Ph.D.,
                                        </p>
                                        <p
                                          style={{
                                            fontSize: "11px",
                                            width: "200px",
                                          }}
                                        >
                                          Molecular Microbiologist
                                        </p>
                                        <br />
                                      </>
                                    )}
                                  </div>
                                </div>
                              </td>
                            </tr>
                            <tr className="ehdhe_9ikw">
                              <td className="shshxhxs_secfooter">
                                {!emailsent && (
                                  <div
                                    style={{ height: "150px", width: "100%" }}
                                  ></div>
                                )}
                                {emailsent && (
                                  <div className="doctr_sign_fix7ccdddd_head">
                                    <div className="sdfsdfsdf_xcvjds89">
                                      <h4>
                                        Emergency Care<span>:</span>04923225300
                                      </h4>
                                      <h4>
                                        Mob No<span>:</span>09965150000
                                      </h4>
                                    </div>
                                    {/* <div className="doctr_sign_fix7ccdddd">
                              <div className="edhwud_oo">
                                <p style={{ fontSize: "11px" }}>
                                  Dr.C. APARNA DEVI M.D., D.M.,
                                </p>
                                <p style={{ fontSize: "11px" }}>
                                  TN's 1st Dedicated DM Oncopathologist
                                </p>
                                <br />
                              </div>
                              <div className="edhwud_oo">
                                <p style={{ fontSize: "11px" }}>
                                  Dr.C. SURESH Ph.D.,
                                  <br />
                                  Diagnostic Molecular Microbiologist
                                </p>
                                <p style={{ fontSize: "11px" }}>
                                  <h6>
                                    Ranked as World's Top 2% scientist for the year
                                    <br />
                                    2022 & 2023 by Stanford University - USA{" "}
                                  </h6>{" "}
                                </p>
                                <br />
                              </div>
                              <div className="edhwud_oo">
                                <p style={{ fontSize: "11px" }}>
                                  Mr.P.R. SURESH BABU M.Sc.,
                                  <br />
                                  Sr. Medical Biochemist
                                </p>
                              </div>
                            </div> */}
                                  </div>
                                )}
                              </td>
                            </tr>
                          </tfoot>
                        </table>
                      ))}
                    </div>
                  );
                } else if (
                  dpt.testdetails.some((p) => p.Test_Code === "RD0098")
                ) {
                  {
                    console.log("poossijdijgoyijyyoykokfo");
                  }
                  return (
                    <>
                      {summa
                        .filter((p) => p.department === "HEMATOLOGY")
                        .map((group, index) => (
                          <table
                            className="report_table report_table_for_micro"
                            style={{ pageBreakAfter: "always" }}
                          >
                            <thead className="print_header">
                              {!summa.some(
                                (item) => item.Report_Type === "OT"
                              ) && (
                                <div className="wiioo900">
                                  <tr className="new_billing_address_2 ededfedf_9jui">
                                    <td className="Register_btn_con_barcode">
                                      <div id="get_imagecontent_1">
                                        <img
                                          src={
                                            patinetbillingbarcode
                                              ? generateBarcode(
                                                  patinetbillingbarcode
                                                )
                                              : ""
                                          }
                                          alt="barcodeimage"
                                          style={{
                                            width: "170px",
                                            height: "40px",
                                            objectFit: "fill",
                                          }}
                                        />
                                      </div>
                                    </td>
                                    <td className="new_billing_div_report">
                                      <label>
                                        Patient Name <p>:</p>
                                      </label>
                                      <span>
                                        {capturedatas.Title}.{" "}
                                        {capturedatas.Patient_Name}
                                      </span>
                                    </td>
                                    {microandhistonumber === "" && (
                                      <td className="new_billing_div_report">
                                        <label>
                                          Visit ID <p>:</p>
                                        </label>
                                        <span>{capturedatas.Visit_Id}</span>
                                      </td>
                                    )}
                                    <td className="new_billing_div_report">
                                      <label>
                                        Age/Gender <p>:</p>
                                      </label>
                                      <span>
                                        {capturedatas.Age}{" "}
                                        {capturedatas?.Time_Period}s/{" "}
                                        {capturedatas.Gender}
                                      </span>
                                    </td>

                                    <td className="new_billing_div_report">
                                      <label>
                                        Ref.Dr <p>:</p>
                                      </label>
                                      <span>
                                        {capturedatas.Refering_Doctor}
                                      </span>
                                    </td>

                                    {summa?.some(
                                      (p) => p.department === "HISTOPATHOLOGY"
                                    ) && (
                                      <td className="new_billing_div_report">
                                        <label>
                                          Histo.no <p>:</p>
                                        </label>
                                        <span>
                                          {microandhistonumber?.HistoNumber}
                                        </span>
                                      </td>
                                    )}

                                    <td className="new_billing_div_report">
                                      <label>
                                        Ref Hospital <p>:</p>
                                      </label>
                                      <span>
                                        {capturedatas.Refering_Hospital}
                                      </span>
                                    </td>
                                  </tr>

                                  <tr className="new_billing_address_2 ededfedf_9jui">
                                    <td className="Register_btn_con_barcode">
                                      <div id="get_imagecontent_2">
                                        <img
                                          src={
                                            capturedatas && capturedatas.Barcode
                                              ? generateBarcode(
                                                  capturedatas.Barcode
                                                )
                                              : ""
                                          }
                                          alt="barcodeimage"
                                          className="get_imagecontent_2_imhhhh"
                                        />
                                      </div>
                                    </td>
                                    <td className="new_billing_div_report ffddffn">
                                      <label>
                                        Invoice No <p>:</p>
                                      </label>
                                      <span>
                                        {capturedatas.Billing_Invoice}
                                      </span>
                                    </td>
                                    <td className="new_billing_div_report ffddffn">
                                      <label>
                                        Collected <p>:</p>
                                      </label>
                                      <span>
                                        {
                                          summa[0]?.invoicedetails
                                            ?.AnalyseInvestigationResult
                                        }
                                      </span>
                                    </td>
                                    <td className="new_billing_div_report ffddffn">
                                      <label>
                                        Received <p>:</p>
                                      </label>
                                      <span>
                                        {
                                          summa[0]?.invoicedetails
                                            ?.AnalyseInvestigationSenior
                                        }
                                      </span>
                                    </td>
                                    <td className="new_billing_div_report ffddffn">
                                      <label>
                                        Reported <p>:</p>
                                      </label>
                                      <span>
                                        {
                                          summa[0]?.invoicedetails
                                            ?.Approve_Test_Pathologist
                                        }
                                      </span>
                                    </td>
                                  </tr>
                                </div>
                              )}
                            </thead>
                            <div className="report_table_oju7 new_report_table_oju7">
                              {formatData.length > 0 &&
                              formatData[0]?.format ? (
                                <h3>{formatHeading(formatData[0].format)}</h3>
                              ) : (
                                <h3>Report Details</h3>
                              )}
                              {console.log("dssddssd", formatData)}
                              <br />

                              <table className="report_table_inner_p">
                                <tbody>
                                  {formatData.length > 0 ? (
                                    <>
                                      <div className="jdjd_8ji8">
                                        <div>
                                          {formatData
                                            .filter(
                                              (item) =>
                                                item.value !== null && // Ensure item.value is not null
                                                item.value !== undefined && // Ensure item.value is not undefined
                                                item.name // Ensure item.name exists
                                            )
                                            .sort((a, b) => {
                                              // Custom sort to place Notes and Disclaimer at the end
                                              const priority = [
                                                "Notes",
                                                "Note",
                                                "Disclaimer",
                                              ];
                                              const aIndex = priority.includes(
                                                a.name
                                              )
                                                ? priority.indexOf(a.name) + 1
                                                : 0;
                                              const bIndex = priority.includes(
                                                b.name
                                              )
                                                ? priority.indexOf(b.name) + 1
                                                : 0;
                                              return aIndex - bIndex;
                                            })
                                            .slice(0, 4) // Get the first four items
                                            .map((item, index) => (
                                              <tr key={index}>
                                                <h3>{item.format}</h3>
                                                <div className="ewhgdew_o">
                                                  <div>
                                                    <td>
                                                      <strong
                                                        style={{
                                                          fontSize:
                                                            item.name
                                                              .toLowerCase()
                                                              .includes(
                                                                "note"
                                                              ) &&
                                                            item.name
                                                              .toLowerCase()
                                                              .includes(
                                                                "disclaimer"
                                                              )
                                                              ? item.name
                                                                  .toLowerCase()
                                                                  .includes(
                                                                    "disclaimer"
                                                                  )
                                                                ? "10px" // Set font size to 10px for disclaimer
                                                                : "12px" // Set font size to 12px for note
                                                              : item.name.toLowerCase() ===
                                                                "note"
                                                              ? "12px"
                                                              : item.name.toLowerCase() ===
                                                                "disclaimer"
                                                              ? "10px" // Set font size to 10px for disclaimer
                                                              : "20px", // Default font size for other cases
                                                          color: "#333", // Optional: Apply consistent styling
                                                        }}
                                                      >
                                                        {formatName(item.name)}
                                                        <span>:</span>
                                                      </strong>
                                                    </td>
                                                  </div>
                                                  <div className="yudsd_4rdf dwexeh_i9">
                                                    <td>
                                                      {editMode ? (
                                                        <div
                                                          contentEditable
                                                          suppressContentEditableWarning
                                                          ref={(el) =>
                                                            (editableRef.current[
                                                              item.name
                                                            ] = el)
                                                          }
                                                          onInput={(e) =>
                                                            handleContentEditableInputChange(
                                                              e,
                                                              item.name
                                                            )
                                                          }
                                                          onMouseUp={() =>
                                                            handleMouseUp(
                                                              item.name
                                                            )
                                                          } // Capture mouse selection
                                                          style={{
                                                            border:
                                                              "1px solid #ccc",
                                                            padding: "5px",
                                                            whiteSpace:
                                                              "pre-wrap", // Allow natural wrapping and preserve manual line breaks
                                                            wordBreak:
                                                              "break-word", // Break long words to fit
                                                            margin: "0",
                                                            wordSpacing:
                                                              "normal",
                                                            maxWidth: "100%", // Ensure it fits within parent
                                                            fontSize: "20px",
                                                          }}
                                                        ></div>
                                                      ) : item.name
                                                          .toLowerCase()
                                                          .includes("note") &&
                                                        item.name
                                                          .toLowerCase()
                                                          .includes(
                                                            "disclaimer"
                                                          ) ? (
                                                        <p
                                                          style={{
                                                            fontSize: item.name
                                                              .toLowerCase()
                                                              .includes(
                                                                "disclaimer"
                                                              )
                                                              ? "10px"
                                                              : "12px",
                                                          }}
                                                          dangerouslySetInnerHTML={{
                                                            __html:
                                                              item.value || "",
                                                          }}
                                                        ></p>
                                                      ) : item.name.toLowerCase() ===
                                                        "note" ? (
                                                        <p
                                                          style={{
                                                            fontSize: "12px",
                                                          }}
                                                          dangerouslySetInnerHTML={{
                                                            __html:
                                                              item.value || "",
                                                          }}
                                                        ></p>
                                                      ) : item.name.toLowerCase() ===
                                                        "disclaimer" ? (
                                                        <p
                                                          style={{
                                                            fontSize: "10px",
                                                          }}
                                                          dangerouslySetInnerHTML={{
                                                            __html:
                                                              item.value || "",
                                                          }}
                                                        ></p>
                                                      ) : (
                                                        <p
                                                          dangerouslySetInnerHTML={{
                                                            __html:
                                                              item.value || "",
                                                          }}
                                                        ></p>
                                                      )}
                                                    </td>
                                                  </div>
                                                </div>
                                              </tr>
                                            ))}
                                        </div>

                                        <div className="klsakask">
                                          {formatData
                                            .filter(
                                              (item) =>
                                                item.name &&
                                                item.name
                                                  .toLowerCase()
                                                  .includes("imagedata") &&
                                                item.value !== null && // Ensure item.value is not null
                                                item.value !== undefined // Ensure item.value is not undefined
                                            )
                                            .sort((a, b) => {
                                              // Custom sort to place Notes and Disclaimer at the end
                                              const priority = [
                                                "Notes",
                                                "Note",
                                                "Disclaimer",
                                              ];
                                              const aIndex = priority.includes(
                                                a.name
                                              )
                                                ? priority.indexOf(a.name) + 1
                                                : 0;
                                              const bIndex = priority.includes(
                                                b.name
                                              )
                                                ? priority.indexOf(b.name) + 1
                                                : 0;
                                              return aIndex - bIndex;
                                            })
                                            .map((item, index) => (
                                              <tr key={index + 4}>
                                                <td>
                                                  <div>
                                                    {imagePreview ? (
                                                      <img
                                                        src={imagePreview} // Show the new image preview
                                                        alt="Preview"
                                                        accept="image/*"
                                                        style={{
                                                          width: "222px",
                                                          height: "180px",
                                                          objectFit: "contain",
                                                        }}
                                                      />
                                                    ) : item.value &&
                                                      item.value !==
                                                        "data:application/octet-stream;base64,null" ? (
                                                      <img
                                                        src={item.value} // Show the existing image from the table (backend)
                                                        alt="Existing"
                                                        accept="image/*"
                                                        style={{
                                                          width: "222px",
                                                          height: "370px",
                                                          objectFit: "contain",
                                                        }}
                                                      />
                                                    ) : null}
                                                  </div>
                                                </td>
                                              </tr>
                                            ))}
                                        </div>
                                      </div>

                                      {formatData
                                        .filter(
                                          (item) =>
                                            item.value !== null && // Ensure item.value is not null
                                            item.value !== undefined && // Ensure item.value is not undefined
                                            item.name &&
                                            !item.name
                                              .toLowerCase()
                                              .includes("imagedata") // Exclude imagedata items
                                        )
                                        .sort((a, b) => {
                                          // Custom sort to place Notes and Disclaimer at the end
                                          const priority = [
                                            "Notes",
                                            "Note",
                                            "Disclaimer",
                                          ];
                                          const aIndex = priority.includes(
                                            a.name
                                          )
                                            ? priority.indexOf(a.name) + 1
                                            : 0;
                                          const bIndex = priority.includes(
                                            b.name
                                          )
                                            ? priority.indexOf(b.name) + 1
                                            : 0;
                                          return aIndex - bIndex;
                                        })
                                        .slice(4) // Get the remaining items after the first four
                                        .map((item, index) => (
                                          <tr key={index + 4}>
                                            <div className="ewhgdew_o">
                                              <div>
                                                <td>
                                                  <strong
                                                    style={{
                                                      fontSize:
                                                        item.name
                                                          .toLowerCase()
                                                          .includes("note") &&
                                                        item.name
                                                          .toLowerCase()
                                                          .includes(
                                                            "disclaimer"
                                                          )
                                                          ? item.name
                                                              .toLowerCase()
                                                              .includes(
                                                                "disclaimer"
                                                              )
                                                            ? "10px" // Set font size to 10px for disclaimer
                                                            : "12px" // Set font size to 12px for note
                                                          : item.name.toLowerCase() ===
                                                            "note"
                                                          ? "12px"
                                                          : item.name.toLowerCase() ===
                                                            "disclaimer"
                                                          ? "10px" // Set font size to 10px for disclaimer
                                                          : "20px", // Default font size for other cases
                                                      color: "#333", // Optional: Apply consistent styling
                                                    }}
                                                  >
                                                    {formatName(item.name)}
                                                    <span>:</span>
                                                  </strong>
                                                </td>
                                              </div>
                                              <div className="yudsd_4rdf">
                                                <td>
                                                  {editMode ? (
                                                    <div
                                                      contentEditable
                                                      suppressContentEditableWarning
                                                      ref={(el) =>
                                                        (editableRef.current[
                                                          item.name
                                                        ] = el)
                                                      }
                                                      onInput={(e) =>
                                                        handleContentEditableInputChange(
                                                          e,
                                                          item.name
                                                        )
                                                      }
                                                      onMouseUp={() =>
                                                        handleMouseUp(item.name)
                                                      } // Capture mouse selection
                                                      style={{
                                                        border:
                                                          "1px solid #ccc",
                                                        padding: "5px",
                                                        whiteSpace: "pre-wrap", // Allow natural wrapping and preserve manual line breaks
                                                        wordBreak: "break-word", // Break long words to fit
                                                        margin: "0",
                                                        wordSpacing: "normal",
                                                        maxWidth: "100%", // Ensure it fits within parent
                                                        fontSize: "20px",
                                                      }}
                                                    ></div>
                                                  ) : item.name
                                                      .toLowerCase()
                                                      .includes("note") &&
                                                    item.name
                                                      .toLowerCase()
                                                      .includes(
                                                        "disclaimer"
                                                      ) ? (
                                                    <p
                                                      style={{
                                                        fontSize: item.name
                                                          .toLowerCase()
                                                          .includes(
                                                            "disclaimer"
                                                          )
                                                          ? "10px"
                                                          : "12px",
                                                      }}
                                                      dangerouslySetInnerHTML={{
                                                        __html:
                                                          item.value || "",
                                                      }}
                                                    ></p>
                                                  ) : item.name.toLowerCase() ===
                                                    "note" ? (
                                                    <p
                                                      style={{
                                                        fontSize: "12px",
                                                      }}
                                                      dangerouslySetInnerHTML={{
                                                        __html:
                                                          item.value || "",
                                                      }}
                                                    ></p>
                                                  ) : item.name.toLowerCase() ===
                                                    "disclaimer" ? (
                                                    <p
                                                      style={{
                                                        fontSize: "10px",
                                                      }}
                                                      dangerouslySetInnerHTML={{
                                                        __html:
                                                          item.value || "",
                                                      }}
                                                    ></p>
                                                  ) : (
                                                    <p
                                                      dangerouslySetInnerHTML={{
                                                        __html:
                                                          item.value || "",
                                                      }}
                                                    ></p>
                                                  )}
                                                </td>
                                              </div>
                                            </div>
                                          </tr>
                                        ))}
                                    </>
                                  ) : (
                                    <tr>
                                      <td colSpan="2">
                                        No report data available
                                      </td>
                                    </tr>
                                  )}
                                </tbody>
                                <div className="Add_items_Purchase_Master yydd_end_reprt">
                                  <span> - End of Report - </span>
                                </div>
                              </table>
                            </div>

                            <tfoot className="print_footerr">
                              <tr className="jjxcdsjjej_">
                                <td className="footer_fix_conten_fyft microejeo">
                                  <div className="dcnnmjy0s66">
                                    <div className="Register_btn_con_QRcode_fix">
                                      <img
                                        src={patinetbillingQr}
                                        alt="qrcode"
                                        style={{
                                          width: "80px",
                                          height: "80px",
                                          objectFit: "fill",
                                        }}
                                      />
                                    </div>

                                    <div className="doctr_sign_fix7cc">
                                      {dpt.Department !== "MICROBIOLOGY" && (
                                        <>
                                          <img
                                            src={Docsign}
                                            alt=""
                                            className="docsign_fix"
                                          />
                                          <p
                                            style={{
                                              fontSize: "11px",
                                              width: "200px",
                                            }}
                                          >
                                            Dr.Aparna Devi C MD DM
                                          </p>
                                          <p
                                            style={{
                                              fontSize: "11px",
                                              width: "200px",
                                            }}
                                          >
                                            ONCOPATHOLOGIST
                                          </p>
                                          <p
                                            style={{
                                              fontSize: "11px",
                                              width: "200px",
                                            }}
                                          >
                                            Reg no - 112494
                                          </p>
                                          <br />
                                        </>
                                      )}
                                    </div>
                                  </div>
                                </td>
                              </tr>

                              <tr className="ehdhe_9ikw">
                                <td className="shshxhxs_secfooter">
                                  {!emailsent && (
                                    <div
                                      style={{
                                        height: "150px",
                                        width: "100%",
                                      }}
                                    ></div>
                                  )}

                                  {emailsent && (
                                    <>
                                      <div className="doctr_sign_fix7ccdddd_head">
                                      <div className="sdfsdfsdf_xcvjds89">
                                      <h4>
                                        Emergency Care<span>:</span>04923225300
                                      </h4>
                                      <h4>
                                        Mob No<span>:</span>09965150000
                                      </h4>
                                    </div>

                                     
                                      </div>
                                    </>
                                  )}
                                </td>
                              </tr>
                            </tfoot>
                          </table>
                        ))}
                    </>
                  );
                } else if (dpt.department === "HISTOPATHOLOGY") {
                  console.log("summa1", summa1);
                  return (
                    <>
                      {summa
                        .filter((p) => p.department === "HISTOPATHOLOGY")
                        .map((group, index) => (
                          <table
                            className="report_table report_table_for_micro"
                            style={{ pageBreakAfter: "always" }}
                          >
                            <thead className="print_header">
                              {!summa.some(
                                (item) => item.Report_Type === "OT"
                              ) && (
                                <div className="wiioo900">
                                  <tr className="new_billing_address_2 ededfedf_9jui">
                                    <td className="Register_btn_con_barcode">
                                      <div id="get_imagecontent_1">
                                        <img
                                          src={
                                            patinetbillingbarcode
                                              ? generateBarcode(
                                                  patinetbillingbarcode
                                                )
                                              : ""
                                          }
                                          alt="barcodeimage"
                                          style={{
                                            width: "170px",
                                            height: "40px",
                                            objectFit: "fill",
                                          }}
                                        />
                                      </div>
                                    </td>
                                    <td className="new_billing_div_report">
                                      <label>
                                        Patient Name <p>:</p>
                                      </label>
                                      <span>
                                        {capturedatas.Title}.{" "}
                                        {capturedatas.Patient_Name}
                                      </span>
                                    </td>
                                    {microandhistonumber === "" && (
                                      <td className="new_billing_div_report">
                                        <label>
                                          Visit ID <p>:</p>
                                        </label>
                                        <span>{capturedatas.Visit_Id}</span>
                                      </td>
                                    )}
                                    <td className="new_billing_div_report">
                                      <label>
                                        Age/Gender <p>:</p>
                                      </label>
                                      <span>
                                        {capturedatas.Age}{" "}
                                        {capturedatas?.Time_Period}s/{" "}
                                        {capturedatas.Gender}
                                      </span>
                                    </td>

                                    <td className="new_billing_div_report">
                                      <label>
                                        Ref.Dr <p>:</p>
                                      </label>
                                      <span>
                                        {capturedatas.Refering_Doctor}
                                      </span>
                                    </td>

                                    {summa?.some(
                                      (p) => p.department === "HISTOPATHOLOGY"
                                    ) && (
                                      <td className="new_billing_div_report">
                                        <label>
                                          Histo.no <p>:</p>
                                        </label>
                                        <span>
                                          {microandhistonumber?.HistoNumber}
                                        </span>
                                      </td>
                                    )}

                                    <td className="new_billing_div_report">
                                      <label>
                                        Ref Hospital <p>:</p>
                                      </label>
                                      <span>
                                        {capturedatas.Refering_Hospital}
                                      </span>
                                    </td>
                                  </tr>

                                  <tr className="new_billing_address_2 ededfedf_9jui">
                                    <td className="Register_btn_con_barcode">
                                      <div id="get_imagecontent_2">
                                        <img
                                          src={
                                            capturedatas && capturedatas.Barcode
                                              ? generateBarcode(
                                                  capturedatas.Barcode
                                                )
                                              : ""
                                          }
                                          alt="barcodeimage"
                                          className="get_imagecontent_2_imhhhh"
                                        />
                                      </div>
                                    </td>
                                    <td className="new_billing_div_report ffddffn">
                                      <label>
                                        Invoice No <p>:</p>
                                      </label>
                                      <span>
                                        {capturedatas.Billing_Invoice}
                                      </span>
                                    </td>
                                    <td className="new_billing_div_report ffddffn">
                                      <label>
                                        Collected <p>:</p>
                                      </label>
                                      <span>
                                        {
                                          summa[0]?.invoicedetails
                                            ?.AnalyseInvestigationResult
                                        }
                                      </span>
                                    </td>
                                    <td className="new_billing_div_report ffddffn">
                                      <label>
                                        Received <p>:</p>
                                      </label>
                                      <span>
                                        {
                                          summa[0]?.invoicedetails
                                            ?.AnalyseInvestigationSenior
                                        }
                                      </span>
                                    </td>
                                    <td className="new_billing_div_report ffddffn">
                                      <label>
                                        Reported <p>:</p>
                                      </label>
                                      <span>
                                        {
                                          summa[0]?.invoicedetails
                                            ?.Approve_Test_Pathologist
                                        }
                                      </span>
                                    </td>
                                  </tr>
                                </div>
                              )}
                            </thead>

                            <div className="report_table_oju7 new_report_table_oju7">
                              {formatData.length > 0 &&
                              formatData[0]?.format ? (
                                <h3>{formatHeading(formatData[0].format)}</h3>
                              ) : (
                                <h3>Report Details</h3>
                              )}

                              <br />

                              <table className="report_table_inner_p">
                                <tbody>
                                  {formatData.length > 0 ? (
                                    <>
                                      <div className="jdjd_8ji8">
                                        <div>
                                          {formatData
                                            .filter(
                                              (item) =>
                                                item.value !== null && // Ensure item.value is not null
                                                item.value !== undefined && // Ensure item.value is not undefined
                                                item.name // Ensure item.name exists
                                            )
                                            .sort((a, b) => {
                                              // Custom sort to place Notes and Disclaimer at the end
                                              const priority = [
                                                "Notes",
                                                "Note",
                                                "Disclaimer",
                                              ];
                                              const aIndex = priority.includes(
                                                a.name
                                              )
                                                ? priority.indexOf(a.name) + 1
                                                : 0;
                                              const bIndex = priority.includes(
                                                b.name
                                              )
                                                ? priority.indexOf(b.name) + 1
                                                : 0;
                                              return aIndex - bIndex;
                                            })
                                            .slice(0, 4) // Get the first four items
                                            .map((item, index) => (
                                              <tr key={index}>
                                                <h3>{item.format}</h3>
                                                <div className="ewhgdew_o">
                                                  <div>
                                                    <td>
                                                      <strong
                                                        style={{
                                                          fontSize:
                                                            item.name
                                                              .toLowerCase()
                                                              .includes(
                                                                "note"
                                                              ) &&
                                                            item.name
                                                              .toLowerCase()
                                                              .includes(
                                                                "disclaimer"
                                                              )
                                                              ? item.name
                                                                  .toLowerCase()
                                                                  .includes(
                                                                    "disclaimer"
                                                                  )
                                                                ? "10px" // Set font size to 10px for disclaimer
                                                                : "12px" // Set font size to 12px for note
                                                              : item.name.toLowerCase() ===
                                                                "note"
                                                              ? "12px"
                                                              : item.name.toLowerCase() ===
                                                                "disclaimer"
                                                              ? "10px" // Set font size to 10px for disclaimer
                                                              : "20px", // Default font size for other cases
                                                          color: "#333", // Optional: Apply consistent styling
                                                        }}
                                                      >
                                                        {formatName(item.name)}
                                                        <span>:</span>
                                                      </strong>
                                                    </td>
                                                  </div>
                                                  <div className="yudsd_4rdf dwexeh_i9">
                                                    <td>
                                                      {editMode ? (
                                                        <div
                                                          contentEditable
                                                          suppressContentEditableWarning
                                                          ref={(el) =>
                                                            (editableRef.current[
                                                              item.name
                                                            ] = el)
                                                          }
                                                          onInput={(e) =>
                                                            handleContentEditableInputChange(
                                                              e,
                                                              item.name
                                                            )
                                                          }
                                                          onMouseUp={() =>
                                                            handleMouseUp(
                                                              item.name
                                                            )
                                                          } // Capture mouse selection
                                                          style={{
                                                            border:
                                                              "1px solid #ccc",
                                                            padding: "5px",
                                                            whiteSpace:
                                                              "pre-wrap", // Allow natural wrapping and preserve manual line breaks
                                                            wordBreak:
                                                              "break-word", // Break long words to fit
                                                            margin: "0",
                                                            wordSpacing:
                                                              "normal",
                                                            maxWidth: "100%", // Ensure it fits within parent
                                                            fontSize: "20px",
                                                          }}
                                                        ></div>
                                                      ) : item.name
                                                          .toLowerCase()
                                                          .includes("note") &&
                                                        item.name
                                                          .toLowerCase()
                                                          .includes(
                                                            "disclaimer"
                                                          ) ? (
                                                        <p
                                                          style={{
                                                            fontSize: item.name
                                                              .toLowerCase()
                                                              .includes(
                                                                "disclaimer"
                                                              )
                                                              ? "10px"
                                                              : "12px",
                                                          }}
                                                          dangerouslySetInnerHTML={{
                                                            __html:
                                                              item.value || "",
                                                          }}
                                                        ></p>
                                                      ) : item.name.toLowerCase() ===
                                                        "note" ? (
                                                        <p
                                                          style={{
                                                            fontSize: "12px",
                                                          }}
                                                          dangerouslySetInnerHTML={{
                                                            __html:
                                                              item.value || "",
                                                          }}
                                                        ></p>
                                                      ) : item.name.toLowerCase() ===
                                                        "disclaimer" ? (
                                                        <p
                                                          style={{
                                                            fontSize: "10px",
                                                          }}
                                                          dangerouslySetInnerHTML={{
                                                            __html:
                                                              item.value || "",
                                                          }}
                                                        ></p>
                                                      ) : (
                                                        <p
                                                          dangerouslySetInnerHTML={{
                                                            __html:
                                                              item.value || "",
                                                          }}
                                                        ></p>
                                                      )}
                                                    </td>
                                                  </div>
                                                </div>
                                              </tr>
                                            ))}
                                        </div>

                                        <div className="klsakask">
                                          {formatData
                                            .filter(
                                              (item) =>
                                                item.name &&
                                                item.name
                                                  .toLowerCase()
                                                  .includes("imagedata") &&
                                                item.value !== null && // Ensure item.value is not null
                                                item.value !== undefined // Ensure item.value is not undefined
                                            )
                                            .sort((a, b) => {
                                              // Custom sort to place Notes and Disclaimer at the end
                                              const priority = [
                                                "Notes",
                                                "Note",
                                                "Disclaimer",
                                              ];
                                              const aIndex = priority.includes(
                                                a.name
                                              )
                                                ? priority.indexOf(a.name) + 1
                                                : 0;
                                              const bIndex = priority.includes(
                                                b.name
                                              )
                                                ? priority.indexOf(b.name) + 1
                                                : 0;
                                              return aIndex - bIndex;
                                            })
                                            .map((item, index) => (
                                              <tr key={index + 4}>
                                                <td>
                                                  <div>
                                                    {imagePreview ? (
                                                      <img
                                                        src={imagePreview} // Show the new image preview
                                                        alt="Preview"
                                                        accept="image/*"
                                                        style={{
                                                          width: "222px",
                                                          height: "180px",
                                                          objectFit: "contain",
                                                        }}
                                                      />
                                                    ) : item.value ? (
                                                      <img
                                                        src={item.value} // Show the existing image from the table (backend)
                                                        alt="Existing"
                                                        accept="image/*"
                                                        style={{
                                                          width: "222px",
                                                          height: "180px",
                                                          objectFit: "contain",
                                                        }}
                                                      />
                                                    ) : null}
                                                  </div>
                                                </td>
                                              </tr>
                                            ))}
                                        </div>
                                      </div>

                                      {formatData
                                        .filter(
                                          (item) =>
                                            item.value !== null && // Ensure item.value is not null
                                            item.value !== undefined && // Ensure item.value is not undefined
                                            item.name &&
                                            !item.name
                                              .toLowerCase()
                                              .includes("imagedata") // Exclude imagedata items
                                        )
                                        .sort((a, b) => {
                                          // Custom sort to place Notes and Disclaimer at the end
                                          const priority = [
                                            "Notes",
                                            "Note",
                                            "Disclaimer",
                                          ];
                                          const aIndex = priority.includes(
                                            a.name
                                          )
                                            ? priority.indexOf(a.name) + 1
                                            : 0;
                                          const bIndex = priority.includes(
                                            b.name
                                          )
                                            ? priority.indexOf(b.name) + 1
                                            : 0;
                                          return aIndex - bIndex;
                                        })
                                        .slice(4) // Get the remaining items after the first four
                                        .map((item, index) => (
                                          <tr key={index + 4}>
                                            <div className="ewhgdew_o">
                                              <div>
                                                <td>
                                                  <strong
                                                    style={{
                                                      fontSize:
                                                        item.name
                                                          .toLowerCase()
                                                          .includes("note") &&
                                                        item.name
                                                          .toLowerCase()
                                                          .includes(
                                                            "disclaimer"
                                                          )
                                                          ? item.name
                                                              .toLowerCase()
                                                              .includes(
                                                                "disclaimer"
                                                              )
                                                            ? "10px" // Set font size to 10px for disclaimer
                                                            : "12px" // Set font size to 12px for note
                                                          : item.name.toLowerCase() ===
                                                            "note"
                                                          ? "12px"
                                                          : item.name.toLowerCase() ===
                                                            "disclaimer"
                                                          ? "10px" // Set font size to 10px for disclaimer
                                                          : "20px", // Default font size for other cases
                                                      color: "#333", // Optional: Apply consistent styling
                                                    }}
                                                  >
                                                    {formatName(item.name)}
                                                    <span>:</span>
                                                  </strong>
                                                </td>
                                              </div>
                                              <div className="yudsd_4rdf">
                                                <td>
                                                  {editMode ? (
                                                    <div
                                                      contentEditable
                                                      suppressContentEditableWarning
                                                      ref={(el) =>
                                                        (editableRef.current[
                                                          item.name
                                                        ] = el)
                                                      }
                                                      onInput={(e) =>
                                                        handleContentEditableInputChange(
                                                          e,
                                                          item.name
                                                        )
                                                      }
                                                      onMouseUp={() =>
                                                        handleMouseUp(item.name)
                                                      } // Capture mouse selection
                                                      style={{
                                                        border:
                                                          "1px solid #ccc",
                                                        padding: "5px",
                                                        whiteSpace: "pre-wrap", // Allow natural wrapping and preserve manual line breaks
                                                        wordBreak: "break-word", // Break long words to fit
                                                        margin: "0",
                                                        wordSpacing: "normal",
                                                        maxWidth: "100%", // Ensure it fits within parent
                                                        fontSize: "20px",
                                                      }}
                                                    ></div>
                                                  ) : item.name
                                                      .toLowerCase()
                                                      .includes("note") &&
                                                    item.name
                                                      .toLowerCase()
                                                      .includes(
                                                        "disclaimer"
                                                      ) ? (
                                                    <p
                                                      style={{
                                                        fontSize: item.name
                                                          .toLowerCase()
                                                          .includes(
                                                            "disclaimer"
                                                          )
                                                          ? "10px"
                                                          : "12px",
                                                      }}
                                                      dangerouslySetInnerHTML={{
                                                        __html:
                                                          item.value || "",
                                                      }}
                                                    ></p>
                                                  ) : item.name.toLowerCase() ===
                                                    "note" ? (
                                                    <p
                                                      style={{
                                                        fontSize: "12px",
                                                      }}
                                                      dangerouslySetInnerHTML={{
                                                        __html:
                                                          item.value || "",
                                                      }}
                                                    ></p>
                                                  ) : item.name.toLowerCase() ===
                                                    "disclaimer" ? (
                                                    <p
                                                      style={{
                                                        fontSize: "10px",
                                                      }}
                                                      dangerouslySetInnerHTML={{
                                                        __html:
                                                          item.value || "",
                                                      }}
                                                    ></p>
                                                  ) : (
                                                    <p
                                                      dangerouslySetInnerHTML={{
                                                        __html:
                                                          item.value || "",
                                                      }}
                                                    ></p>
                                                  )}
                                                </td>
                                              </div>
                                            </div>
                                          </tr>
                                        ))}
                                    </>
                                  ) : (
                                    <tr>
                                      <td colSpan="2">
                                        No report data available
                                      </td>
                                    </tr>
                                  )}
                                </tbody>

                                <div className="Add_items_Purchase_Master yydd_end_reprt">
                                  <span> - End of Report - </span>
                                </div>
                              </table>
                            </div>

                            <tfoot className="print_footerr">
                              <tr className="jjxcdsjjej_">
                                <td className="footer_fix_conten_fyft microejeo">
                                  <div className="dcnnmjy0s66">
                                    <div className="Register_btn_con_QRcode_fix dcvd_p63d">
                                      <img
                                        src={patinetbillingQr}
                                        alt="qrcode"
                                        style={{
                                          width: "80px",
                                          height: "80px",
                                          objectFit: "fill",
                                        }}
                                      />
                                      <div style={{ width: "310px" }}>
                                        Processed/Typed By:
                                        {group.createdby}
                                      </div>
                                    </div>

                                    <div className="doctr_sign_fix7cc">
                                      {dpt.department !== "MICROBIOLOGY" && (
                                        <>
                                          <img
                                            src={Docsign}
                                            alt=""
                                            className="docsign_fix"
                                          />
                                          <p
                                            style={{
                                              fontSize: "11px",
                                              width: "200px",
                                            }}
                                          >
                                            Dr.Aparna Devi C MD DM
                                          </p>
                                          <p
                                            style={{
                                              fontSize: "11px",
                                              width: "200px",
                                            }}
                                          >
                                            ONCOPATHOLOGIST
                                          </p>
                                          <p
                                            style={{
                                              fontSize: "11px",
                                              width: "200px",
                                            }}
                                          >
                                            Reg no - 112494
                                          </p>
                                          <br />
                                        </>
                                      )}
                                    </div>
                                  </div>
                                </td>
                              </tr>

                              <tr className="ehdhe_9ikw">
                                <td className="shshxhxs_secfooter">
                                  {!emailsent && (
                                    <div
                                      style={{
                                        height: "150px",
                                        width: "100%",
                                      }}
                                    ></div>
                                  )}

                                  {emailsent && (
                                    <>
                                      <div className="doctr_sign_fix7ccdddd_head">
                                      <div className="sdfsdfsdf_xcvjds89">
                                      <h4>
                                        Emergency Care<span>:</span>04923225300
                                      </h4>
                                      <h4>
                                        Mob No<span>:</span>09965150000
                                      </h4>
                                    </div>
                                      </div>
                                    </>
                                  )}
                                </td>
                              </tr>
                            </tfoot>
                          </table>
                        ))}
                    </>
                  );
                } else if (
                  dpt.department !== "MICROBIOLOGY" &&
                  dpt.department !== "HISTOPATHOLOGY"
                ) {
                  // Find the index of the first non-Microbiology/non-Histopathology department
                  const firstNonMicroNonHistoIndex = summa.findIndex(
                    (dept) =>
                      dept.department !== "MICROBIOLOGY" &&
                      dept.department !== "HISTOPATHOLOGY"
                  );

                  // Only render if this is the first matching department
                  if (undex === firstNonMicroNonHistoIndex) {
                    // Filter all non-Microbiology/non-Histopathology departments
                    const nonMicroNonHistoDepartments = summa.filter(
                      (dept) =>
                        dept.department !== "MICROBIOLOGY" &&
                        dept.department !== "HISTOPATHOLOGY"
                    );

                    return (
                      <table
                        key={undex}
                        className="biochemistry-report-group"
                        style={{
                          width: "90%",
                          position: "relative",
                          left: "41px",
                        }}
                      >
                        <thead className="print_header">
                          {!summa.some((item) => item.Report_Type === "OT") && (
                            <div className="wiioo900">
                              <tr className="new_billing_address_2 ededfedf_9jui">
                                <td className="Register_btn_con_barcode">
                                  <div id="get_imagecontent_1">
                                    <img
                                      src={
                                        patinetbillingbarcode
                                          ? generateBarcode(
                                              patinetbillingbarcode
                                            )
                                          : ""
                                      }
                                      alt="barcodeimage"
                                      style={{
                                        width: "170px",
                                        height: "40px",
                                        objectFit: "fill",
                                      }}
                                    />
                                  </div>
                                </td>
                                <td className="new_billing_div_report">
                                  <label>
                                    Patient Name <p>:</p>
                                  </label>
                                  {editMode ? (
                                    <span className="patient-input-group">
                                      <select
                                        name="title"
                                        value={patientdetails.title}
                                        onChange={handleInputChange}
                                        className="patient-titllles"
                                      >
                                        <option value="">Title</option>
                                        <option value="Mr">Mr.</option>
                                        <option value="Ms">Ms.</option>
                                        <option value="Mrs">Mrs.</option>
                                        <option value="Baby">Baby.</option>
                                        <option value="Dr">Dr.</option>
                                        <option value="BabyOf">Baby.of.</option>
                                        <option value="Child">Child.</option>
                                        <option value="Sister">Sister</option>
                                        <option value="Master">Master</option>
                                        <option value="Others">Others.</option>
                                      </select>
                                      <input
                                        type="text"
                                        name="patientname"
                                        value={patientdetails.patientname}
                                        onChange={handleInputChange}
                                        className="patient-name"
                                      />
                                    </span>
                                  ) : (
                                    <span>
                                      {capturedatas.Title}.{" "}
                                      {capturedatas.Patient_Name}
                                    </span>
                                  )}
                                </td>
                                {microandhistonumber === "" && (
                                  <td className="new_billing_div_report">
                                    <label>
                                      Visit ID <p>:</p>
                                    </label>
                                    <span>{capturedatas.Visit_Id}</span>
                                  </td>
                                )}
                                <td className="new_billing_div_report">
                                  <label>
                                    Age/Gender <p>:</p>
                                  </label>
                                  {editMode ? (
                                    <span className="patient-input-group">
                                      <input
                                        type="number"
                                        name="age"
                                        value={patientdetails.age}
                                        onChange={handleInputChange}
                                        className="patient-age"
                                      />
                                      <select
                                        name="timeperiod"
                                        value={patientdetails.timeperiod}
                                        onChange={handleInputChange}
                                        className="patient-year"
                                      >
                                        <option value="hour">Hours</option>
                                        <option value="day">Days</option>
                                        <option value="week">Weeks</option>
                                        <option value="month">Months</option>
                                        <option value="year">Years</option>
                                      </select>
                                      /
                                      <select
                                        name="gender"
                                        value={patientdetails.gender}
                                        onChange={handleInputChange}
                                        className="patient-gender"
                                      >
                                        <option value="Male">Male</option>
                                        <option value="Female">Female</option>
                                      </select>
                                    </span>
                                  ) : (
                                    <span>
                                      {capturedatas.Age}{" "}
                                      {capturedatas?.Time_Period}s /{" "}
                                      {capturedatas.Gender}
                                    </span>
                                  )}
                                </td>
                                <td className="new_billing_div_report">
                                  <label>
                                    Ref.Dr <p>:</p>
                                  </label>
                                  {editMode ? (
                                    <input
                                      type="text"
                                      name="Referingdoctor"
                                      list="referingdoc"
                                      value={patientdetails.Referingdoctor}
                                      onChange={handleInputChange}
                                      className="patient-referdoc"
                                    />
                                  ) : (
                                    <span>{capturedatas.Refering_Doctor}</span>
                                  )}
                                </td>
                                <td className="new_billing_div_report">
                                  <label>
                                    Ref Hospital <p>:</p>
                                  </label>
                                  {editMode ? (
                                    <input
                                      type="text"
                                      name="concernname"
                                      list="concernnamelist"
                                      value={patientdetails.concernname}
                                      onChange={handleInputChange}
                                      className="patient-referhos"
                                    />
                                  ) : (
                                    <span>
                                      {capturedatas.Refering_Hospital}
                                    </span>
                                  )}
                                </td>
                              </tr>

                              <tr className="new_billing_address_2 ededfedf_9jui">
                                <td className="Register_btn_con_barcode">
                                  <div id="get_imagecontent_2">
                                    <img
                                      src={
                                        capturedatas && capturedatas.Barcode
                                          ? generateBarcode(
                                              capturedatas.Barcode
                                            )
                                          : ""
                                      }
                                      alt="barcodeimage"
                                      className="get_imagecontent_2_imhhhh"
                                    />
                                  </div>
                                </td>
                                <td className="new_billing_div_report ffddffn">
                                  <label>
                                    Invoice No <p>:</p>
                                  </label>
                                  <span>{capturedatas.Billing_Invoice}</span>
                                </td>
                                <td className="new_billing_div_report ffddffn">
                                  <label>
                                    Collected <p>:</p>
                                  </label>
                                  <span>
                                    {
                                      nonMicroNonHistoDepartments[0]
                                        ?.invoicedetails
                                        ?.AnalyseInvestigationResult
                                    }
                                  </span>
                                </td>
                                <td className="new_billing_div_report ffddffn">
                                  <label>
                                    Received <p>:</p>
                                  </label>
                                  <span>
                                    {
                                      nonMicroNonHistoDepartments[0]
                                        ?.invoicedetails
                                        ?.AnalyseInvestigationSenior
                                    }
                                  </span>
                                </td>
                                <td className="new_billing_div_report ffddffn">
                                  <label>
                                    Reported <p>:</p>
                                  </label>
                                  <span>
                                    {
                                      nonMicroNonHistoDepartments[0]
                                        ?.invoicedetails
                                        ?.Approve_Test_Pathologist
                                    }
                                  </span>
                                </td>
                              </tr>
                            </div>
                          )}
                        </thead>

                        <div className="print-page3">
                          <div className="ewdwedcsdwe">
                            {/* Grouped Summary Section for All Abnormal Values */}
                            {(() => {
                              // Collect all tests with abnormal values across all departments
                              const allAbnormalTests = [];
                              nonMicroNonHistoDepartments.forEach((dpt) => {
                                dpt.testdetails.forEach((test, index) => {
                                  const { panicLevel } = getStatus(
                                    test.Capture_Value,
                                    test.ReferenceRange
                                  );
                                  if (panicLevel) {
                                    allAbnormalTests.push({
                                      ...test,
                                      department: dpt.department,
                                      groupCode: dpt.Group_Code,
                                    });
                                  }
                                });
                              });

                              // Render the Summary section if there are any abnormal values
                              return allAbnormalTests.length > 0 ? (
                                <>
                                  <div className="culture_test_header">
                                    <p>Summary of Abnormal Values</p>
                                  </div>
                                  <br />
                                  <div className="table-container554">
                                    <table className="report_table report_table_for_micro hesyyd_p_Bicochemis0">
                                      <thead className="report_table_p99c">
                                        <tr>
                                          <th>Test Name</th>
                                          <th>Result</th>
                                          <th>Unit</th>
                                          <th>Biological Reference</th>
                                          <th>Method</th>
                                        </tr>
                                      </thead>
                                      <tbody className="hesyyd_p0 report_table_p99c">
                                        {allAbnormalTests.map((test, index) => {
                                          const { valueStyle } = getStatus(
                                            test.Capture_Value,
                                            test.ReferenceRange
                                          );
                                          return (
                                            <tr key={index}>
                                              <td>
                                                <div className="uyhfgr_gf">
                                                  <p>
                                                    {test.Test_Name} (
                                                    {test.department})
                                                  </p>
                                                  <i
                                                    style={{
                                                      visibility:
                                                        test.groupCode ===
                                                        "GM0019"
                                                          ? "hidden"
                                                          : "visible",
                                                    }}
                                                  >
                                                    {test.Specimen_Name
                                                      ? `Sample- ${test.Specimen_Name}`
                                                      : "\u00A0"}
                                                  </i>
                                                </div>
                                              </td>
                                              <td style={valueStyle}>
                                                {test.Capture_Value}
                                              </td>
                                              <td>
                                                {[
                                                  "nil",
                                                  "negative",
                                                  "-",
                                                ].includes(
                                                  String(
                                                    test.Capture_Value
                                                  ).toLowerCase()
                                                )
                                                  ? ""
                                                  : test.UOM}
                                              </td>
                                              <td>{test.ReferenceRange}</td>
                                              <td>
                                                {formatMethodName(
                                                  test.Method_Name
                                                )}
                                              </td>
                                            </tr>
                                          );
                                        })}
                                      </tbody>
                                    </table>
                                  </div>
                                  <div style={{ marginBottom: "20px" }} />
                                </>
                              ) : null;
                            })()}

                            {/* Normal Values Section */}
                            {nonMicroNonHistoDepartments.length > 0 && (
                              <>
                                {/* Move Header Outside the Loop */}
                                <div className="culture_test_header">
                                  <p>Test Report</p>
                                </div>
                                <div className="table-container554">
                                  <table className="report_table report_table_for_micro hesyyd_p_Bicochemis0 hesyyd_p_Bicochemis0_normal">
                                    <thead className="report_table_p99c">
                                      <tr>
                                        <th>Test Name</th>
                                        <th>Result</th>
                                        <th>Unit</th>
                                        <th>Biological Reference</th>
                                        <th>Method</th>
                                      </tr>
                                    </thead>
                                    <tbody className="hesyyd_p0 report_table_p99c">
                                      {nonMicroNonHistoDepartments.map(
                                        (dpt, dptIndex) => (
                                          <React.Fragment key={dptIndex}>
                                            {/* Render Group Name Only Once Before Tests in the Group */}
                                            <tr>
                                              <td colSpan={5}>
                                                <p style={{ fontWeight: 600 }}>
                                                  {dpt.Test_Method === "Offers"
                                                    ? dpt.PackageName
                                                    : dpt.Test_Method ===
                                                      "Group"
                                                    ? `${dpt.groupname} (${dpt.department})`
                                                    : dpt.department}
                                                </p>
                                              </td>
                                            </tr>

                                            {/* Render Tests Under Group */}
                                            {dpt.testdetails.map(
                                              (test, testIndex) => {
                                                const testKey = `${test.Test_Code}_${test.Billing_Invoice}`;
                                                const isEditing = editMode;
                                                const edited =
                                                  editBioData[testKey] || {};
                                                const merged = {
                                                  ...test,
                                                  ...edited,
                                                };

                                                return (
                                                  <React.Fragment
                                                    key={testIndex}
                                                  >
                                                    <tr>
                                                      <td>
                                                        <div className="uyhfgr_gf">
                                                          <p>
                                                            {test.Test_Name}
                                                          </p>
                                                          <i
                                                            style={{
                                                              visibility:
                                                                dpt.Group_Code ===
                                                                "GM0019"
                                                                  ? "hidden"
                                                                  : "visible",
                                                            }}
                                                          >
                                                            {test.Specimen_Name
                                                              ? `Sample- ${test.Specimen_Name}`
                                                              : "\u00A0"}
                                                          </i>
                                                        </div>
                                                      </td>

                                                      {/* Result */}
                                                      <td
                                                        style={
                                                          getStatus(
                                                            merged.Capture_Value,
                                                            merged.ReferenceRange
                                                          ).valueStyle
                                                        }
                                                      >
                                                        {isEditing ? (
                                                          <input
                                                            type="text"
                                                            value={
                                                              merged.Capture_Value
                                                            }
                                                            onChange={(e) =>
                                                              handleBioChange(
                                                                test.Test_Code,
                                                                test.Billing_Invoice,
                                                                "Capture_Value",
                                                                e.target.value
                                                              )
                                                            }
                                                          />
                                                        ) : (
                                                          test.Capture_Value
                                                        )}
                                                      </td>

                                                      {/* Unit */}
                                                      <td>
                                                        {isEditing ? (
                                                          <input
                                                            type="text"
                                                            value={merged.UOM}
                                                            onChange={(e) =>
                                                              handleBioChange(
                                                                test.Test_Code,
                                                                test.Billing_Invoice,
                                                                "UOM",
                                                                e.target.value
                                                              )
                                                            }
                                                          />
                                                        ) : [
                                                            "nil",
                                                            "negative",
                                                            "-",
                                                          ].includes(
                                                            String(
                                                              test.Capture_Value
                                                            ).toLowerCase()
                                                          ) ? (
                                                          ""
                                                        ) : (
                                                          test.UOM
                                                        )}
                                                      </td>

                                                      {/* Reference Range */}
                                                      <td>
                                                        {isEditing ? (
                                                          <input
                                                            type="text"
                                                            value={
                                                              merged.ReferenceRange
                                                            }
                                                            onChange={(e) =>
                                                              handleBioChange(
                                                                test.Test_Code,
                                                                test.Billing_Invoice,
                                                                "ReferenceRange",
                                                                e.target.value
                                                              )
                                                            }
                                                          />
                                                        ) : (
                                                          test.ReferenceRange
                                                        )}
                                                      </td>

                                                      {/* Method */}
                                                      <td>
                                                        {isEditing ? (
                                                          <input
                                                            type="text"
                                                            value={
                                                              merged.Method_Name
                                                            }
                                                            onChange={(e) =>
                                                              handleBioChange(
                                                                test.Test_Code,
                                                                test.Billing_Invoice,
                                                                "Method_Name",
                                                                e.target.value
                                                              )
                                                            }
                                                          />
                                                        ) : (
                                                          formatMethodName(
                                                            test.Method_Name
                                                          )
                                                        )}
                                                      </td>
                                                    </tr>

                                                    {/* Comments */}
                                                    {test.Header_interpretation !==
                                                      null &&
                                                      test.Comments !==
                                                        null && (
                                                        <tr>
                                                          <td
                                                            colSpan={5}
                                                            style={{
                                                              textAlign:
                                                                "start",
                                                            }}
                                                          >
                                                            <h4>
                                                              {
                                                                test.Header_interpretation
                                                              }
                                                            </h4>
                                                            <p>
                                                              {test.Comments}
                                                            </p>
                                                          </td>
                                                        </tr>
                                                      )}
                                                  </React.Fragment>
                                                );
                                              }
                                            )}
                                          </React.Fragment>
                                        )
                                      )}
                                    </tbody>
                                  </table>
                                </div>
                              </>
                            )}

                            <div className="Add_items_Purchase_Master yydd_end_reprt">
                              <span> - End of Report - </span>
                            </div>
                          </div>
                        </div>

                        <tfoot className="print_footerr">
                          <tr className="jjxcdsjjej_ ewdwe3redvv">
                            <td className="footer_fix_conten_fyft microejeo">
                              <div className="dcnnmjy0s66 biachemist_clicll">
                                <div className="Register_btn_con_QRcode_fix">
                                  <img
                                    src={patinetbillingQr}
                                    alt="qrcode"
                                    style={{
                                      width: "80px",
                                      height: "80px",
                                      objectFit: "fill",
                                      borderBottom: "none",
                                    }}
                                  />
                                </div>

                                <div className="doctr_sign_fix7cc doctr_sign_fix7cc_secddg">
                                  {nonMicroNonHistoDepartments.some(
                                    (dpt) => dpt.department !== "MICROBIOLOGY"
                                  ) && (
                                    <>
                                      <img
                                        src={Docsign}
                                        alt=""
                                        className="docsign_fix"
                                      />
                                      <p
                                        style={{
                                          fontSize: "11px",
                                          width: "200px",
                                        }}
                                      >
                                        Dr.Aparna Devi C MD DM
                                      </p>
                                      <p
                                        style={{
                                          fontSize: "11px",
                                          width: "200px",
                                        }}
                                      >
                                        ONCOPATHOLOGIST
                                      </p>
                                      <p
                                        style={{
                                          fontSize: "11px",
                                          width: "200px",
                                        }}
                                      >
                                        Reg no - 112494
                                      </p>
                                      <br />
                                    </>
                                  )}
                                </div>
                              </div>
                            </td>
                          </tr>

                          <tr className="ehdhe_9ikw">
                            <td className="shshxhxs_secfooter">
                              {!emailsent && (
                                <div
                                  style={{ height: "150px", width: "100%" }}
                                ></div>
                              )}

                              {emailsent && (
                                <>
                                  <div className="doctr_sign_fix7ccdddd_head">
                                  <div className="sdfsdfsdf_xcvjds89">
                                      <h4>
                                        Emergency Care<span>:</span>04923225300
                                      </h4>
                                      <h4>
                                        Mob No<span>:</span>09965150000
                                      </h4>
                                    </div>

                                    {/* <div className="doctr_sign_fix7ccdddd">
                                      <div className="edhwud_oo">
                                        <p style={{ fontSize: "11px" }}>
                                          Dr.C. APARNA DEVI M.D., D.M.,
                                        </p>
                                        <p style={{ fontSize: "11px" }}>
                                          TN's 1st Dedicated DM Oncopathologist
                                        </p>
                                        <br />
                                      </div>
                
                                      <div className="edhwud_oo">
                                        <p style={{ fontSize: "11px" }}>
                                          Dr.C. SURESH Ph.D.,<br />
                                          Diagnostic Molecular Microbiologist
                                        </p>
                                        <p style={{ fontSize: "11px" }}>
                                          <h6>
                                            Ranked as World's Top 2% scientist for the year
                                            <br />
                                            2022 & 2023 by Stanford University - USA
                                          </h6>
                                        </p>
                                        <br />
                                      </div>
                
                                      <div className="edhwud_oo">
                                        <p style={{ fontSize: "11px" }}>
                                          Mr.P.R. SURESH BABU M.Sc.,<br />
                                          Sr. Medical Biochemist
                                        </p>
                                      </div>
                                    </div> */}
                                  </div>
                                </>
                              )}
                            </td>
                          </tr>
                        </tfoot>
                      </table>
                    );
                  }
                  return null; // Skip rendering for subsequent non-Microbiology/non-Histopathology departments
                }
              })}
            </tbody>
          </table>
        )}

        {openmodels && (
          <div
            className={
              isSidebarOpen
                ? "sideopen_showcamera_profile"
                : "showcamera_profile"
            }
            onClick={() => {
              setopenmodels(false);
            }}
          >
            <div
              className="newwProfiles newwPopupforreason"
              onClick={(e) => e.stopPropagation()}
            >
              <div ref={contentRef} className="editor_life">
                <CKEditor
                  editor={ClassicEditor}
                  config={{
                    extraPlugins: [uploadPlugin],
                  }}
                  data={content}
                  onChange={(event, editor) => {
                    const data = editor.getData();
                    setContent(data);
                  }}
                />
              </div>

              <div className="Register_btn_con regster_btn_contsai">
                <button
                  className="RegisterForm_1_btns"
                  onClick={() => setopenmodels(false)}
                >
                  Close
                </button>
                {/* <button className="RegisterForm_1_btns" onClick={handleSavedoc}>
                                Save
                            </button> */}
              </div>
            </div>
          </div>
        )}

        {showmodel && (
          <div
            className={
              isSidebarOpen
                ? "sideopen_showcamera_profile"
                : "showcamera_profile"
            }
            onClick={() => {
              setshowmodel(false);
            }}
          >
            <div
              className="newwProfiles newwPopupforreason"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="grid_1">
                <ThemeProvider theme={theme}>
                  <DataGrid
                    rows={culturevalue.slice(
                      page * pageSize,
                      (page + 1) * pageSize
                    )}
                    columns={dynamicColumns}
                    pageSize={pageSize}
                    pageSizeOptions={[pageSize]}
                    onPageChange={(newPage) => setPage(newPage)}
                    hideFooterPagination
                    hideFooterSelectedRowCount
                    className="data_grid"
                  />
                  {showdown > 0 && culturevalue.length > pageSize && (
                    <div className="grid_foot">
                      <button
                        onClick={() =>
                          setPage((prevPage) => Math.max(prevPage - 1, 0))
                        }
                        disabled={page === 0}
                      >
                        Previous
                      </button>
                      Page {page + 1} of {totalPages}
                      <button
                        onClick={() =>
                          setPage((prevPage) =>
                            Math.min(prevPage + 1, totalPages - 1)
                          )
                        }
                        disabled={page === totalPages - 1}
                      >
                        Next
                      </button>
                    </div>
                  )}
                </ThemeProvider>
                <br />

                {culturevalue.length === 0 && (
                  <div className="IP_norecords">
                    <span>No Records Found</span>
                  </div>
                )}
              </div>

              <div className="Register_btn_con regster_btn_contsai">
                <button
                  className="RegisterForm_1_btns"
                  onClick={() => setshowmodel(false)}
                >
                  Close
                </button>
                <button
                  className="RegisterForm_1_btns"
                  onClick={editMode ? handleupdatesencitivity : ""}
                >
                  {editMode ? "Update" : "Edit"}
                </button>
              </div>
            </div>
          </div>
        )}
        {summa.length === 0 && (
          <div
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              flexDirection: "column",
              gap: "10px",
              marginTop: "15px",
            }}
          >
            <p style={{ color: "red" }}> Your Report is not Ready Now</p>

            <button
              className="RegisterForm_1_btns  Rhugt_report"
              onClick={() => navigate("/Home/DispatchEntryList")}
            >
              Back
            </button>
          </div>
        )}
      </div>
    );
  }
);

function Reports() {
  const componentRef = useRef();

  const touppercasefun = (value) => {
    return value?.toUpperCase();
  };

  const userRecord = useSelector((state) => state.userRecord?.UserData);
  console.log(userRecord, "record");
  const urllink = useSelector((state) => state.userRecord?.UrlLink);
  const isSidebarOpen = useSelector((state) => state.userRecord?.isSidebarOpen);
  const SignPerson = useSelector((state) => state.userRecord?.SignPerson);
  const printpapaer = useSelector((state) => state.userRecord?.printpapaer);
  const [microandhistonumber, setmicroandhistonumber] = useState({});
  let isNoRendered = false;
  const [Dispatch, setdispatch] = useState("");
  const [summa, setsumma] = useState([]);
  const [summa1, setsumma1] = useState([]);
  const [formatData, setFormatData] = useState([]);
  const [content, setContent] = useState("");
  const [showmodel, setshowmodel] = useState(false);
  const [culturevalue, setculturevalue] = useState([]);
  const [editmicrodata, seteditmicrodata] = useState({
    notes: {},
    reportstatus: {},
    microscopy: {},
    culturereport: {},
    bacteriaisolated: {},
    Sample: {},
  });

  const [cancelReason, setCancelReason] = useState("");
  // const [selectedId, setselectedId] = useState(null);
  const [trues, settrues] = useState(false);
  const [openDialog, setOpenDialog] = useState(false);
  const [patinetbillingbarcode, setpatinetbillingbarcode] = useState();
  const capturedatas = useSelector((state) => state.userRecord?.Samplecapture);
  console.log("jhdahjadjadjjajhsdjhsd", capturedatas);
  const [editMode, setEditMode] = useState(false);
  const [selectedText, setSelectedText] = useState("");
  const [selectedField, setSelectedField] = useState("");
  const [page, setPage] = useState(0);
  const [show, setshow] = useState(false);

  const navigate = useNavigate();
  const pageSize = 10;
  const totalPages = Math.ceil(culturevalue.length / pageSize);
  const showdown = culturevalue.length;
  const [patinetbillingQr, setpatinetbillingQr] = useState("");

  const [emailsent, setemailsent] = useState(false);
  const [openmodels, setopenmodels] = useState(false);
  const [ClinicDetials, setClinicDetials] = useState({
    ClinicLogo: null,
    ClinicName: "",
    ClinicGST: "",
    ClinicAddress: "",
    ClinicCity: "",
    ClinicState: "",
    ClinicCode: "",
    ClinicMobileNo: "",
    ClinicLandLineNo: "",
    ClinicMailID: "",
    InvoiceNo: "",
  });
  const contentRef = useRef(null);
  const editableRef = useRef({});
  const [editBioData, setEditBioData] = useState({});
  const [report, setreport] = useState({
    Collected: "",
    Received: "",
    Reported: "",
    Head: "",
    Detail: "",
  });

  const [patientdetails, setPatientdetails] = useState({
    title: capturedatas.Title || "",
    patientname: capturedatas.Patient_Name || "",
    age: capturedatas.Age || "",
    timeperiod: capturedatas.Time_Period || "",
    gender: capturedatas.Gender || "",
    Referingdoctor: capturedatas.Refering_Doctor || "",
    concernname: capturedatas.Refering_Hospital || "",
  });

  const handleCheckboxChange = (e) => {
    setemailsent(e.target.value === "yes");
  };
  const formatHeading = (format) => {
    const formatMap = {
      histopathologySecondOpinion: "Histopathology (Second Opinion)",
      peripheralSmear: "PeripheralSmear (PS)",
      lbc: "LBC",
      biopsy: "Biopsy",
      fnac: "FNAC",
      pathologyReport: "Pathology Report",
    };

    return formatMap[format] || format; // Fallback to original format if not found
  };

  const handleBioChange = (testCode, invoice, field, value) => {
    setEditBioData((prev) => ({
      ...prev,
      [`${testCode}_${invoice}`]: {
        ...(prev[`${testCode}_${invoice}`] || {}),
        [field]: value,
      },
    }));
  };

  const handleshowculturetest = () => {
    axios
      .get(
        `${urllink}Lab/get_for_culture_report_completion?Billinginvoice=${capturedatas?.Billing_Invoice}&Visitid=${capturedatas?.Visit_Id}`
      )
      .then((response) => {
        console.log(response);
        const data = response.data.map((p, index) => ({
          id: index + 1,
          ...p,
        }));
        setculturevalue(data);
        setshowmodel(true);
      })
      .catch((error) => {
        console.log(error);
      });
  };

  useEffect(() => {
    axios
      .get(
        `${urllink}Lab/get_for_preview_examinations_dispatch?Visitid=${capturedatas?.Visit_Id}&patientid=${capturedatas.Patient_Id}&Billinginvoice=${capturedatas?.Billing_Invoice}`
      )
      .then((response) => {
        console.log(response, "1234567890");

        const groupsData = response.data;

        const reportsData = groupsData.map((group) => {
          return {
            method: group.Method,
            Department: group.Department,
            groupName: group.Group_Name,
            createdby: group.CreatedBy,
            Collected: group.Updated_At?.AnalyseInvestigationResult,
            Received: group.Updated_At?.AnalyseInvestigationSenior,
            Reported: group.Updated_At?.Approve_Test_Pathologist,
            Tests: group.Tests.map((test) => ({
              Test_Name: test.Test_Name || "",
              Method_Name: test.Method_Name || "",
              Department: test.Department || "",
              Sample: test.Specimen || "",
              Content: test.EditContent || "",
              Samplepicture: test.Samplepic
                ? `data:image/jpeg;base64,${test.Samplepic}`
                : null,
            })),
          };
        });

        setsumma1(reportsData);
      })
      .catch((error) => {
        console.error(
          "Error fetching data:",
          error.response || error.message || error
        );
      });
  }, [capturedatas, urllink, editmicrodata]);

  const autoResizeTextarea = (e) => {
    e.target.style.height = "auto"; // Reset the height to auto
    e.target.style.height = `${e.target.scrollHeight}px`; // Set it to the scroll height
  };

  useEffect(() => {
    axios
      .get(
        `${urllink}Lab/getMicro_and_HistoNumber?Invoice=${capturedatas?.Billing_Invoice}`
      )
      .then((res) => {
        console.log(res);
        setmicroandhistonumber(res.data);
      })
      .catch((err) => {
        console.error(err);
      });
  }, [urllink, capturedatas]);

  useEffect(() => {
    axios
      .get(
        `${urllink}Lab/get_for_dispatch_report_status?invoice=${capturedatas?.Billing_Invoice}`
      )
      .then((response) => {
        setdispatch(response.data);
      })
      .catch((error) => {
        console.log(error);
      });

    if (capturedatas) {
      const barval = `${urllink}Lab/get_report?inv=${capturedatas?.Barcode}`;
      axios
        .get(`${urllink}Lab/get_qrcode_image?qrValue=${barval}`)
        .then((res) => {
          const datass = res.data.qrImage;
          setpatinetbillingQr(datass);
        })
        .catch((err) => {
          console.log(err);
        });
    }
  }, [urllink, capturedatas, trues]);

  // const innerHeightOfPDF = getInnerHeightOfPDF();

  const getAllUniqueOrganisms = (groups) => {
    const organismSet = new Set();

    if (Array.isArray(groups)) {
      groups.forEach((group) => {
        if (group.testdetails && Array.isArray(group.testdetails)) {
          group.testdetails.forEach((test) => {
            if (test.OrganismDetails && Array.isArray(test.OrganismDetails)) {
              test.OrganismDetails.forEach((orgDetail) => {
                Object.keys(orgDetail).forEach((organism) => {
                  organismSet.add(organism);
                });
              });
            }
          });
        }
      });
    }

    return Array.from(organismSet);
  };

  const getSensitivityColor = (sensitivetype) => {
    switch (sensitivetype) {
      case "Sensitive":
        return "green";
      case "Intermediate":
        return "blue";
      case "Resistant":
        return "red";
      default:
        return "black";
    }
  };

  const uniqueOrganisms = getAllUniqueOrganisms(summa);

  const getAlphabetHeaders = (length) => {
    const alphabets = [];
    for (let i = 0; i < length; i++) {
      alphabets.push(String.fromCharCode(65 + i));
    }
    return alphabets;
  };

  const alphabetHeaders = getAlphabetHeaders(uniqueOrganisms.length);

  console.log("summa", summa);
  // const uniqueOrganisms = [...new Set(summa[0]?.Sensitive.map(item => item.oraganism))];
  console.log("uniqueOrganisms", uniqueOrganisms);

  console.log(show);

  const dynamicColumns = [
    { field: "id", headerName: "S.No", width: 150 },
    { field: "antibiotic", headerName: "Antibiotic Name", width: 150 },
    {
      field: "Sensitivetype",
      headerName: "Sensitive Type",
      width: 150,
      renderCell: (params) =>
        editMode ? (
          <Select
            value={params.row.Sensitivetype}
            onChange={(e) =>
              handleSensitivityChange(params.row.id, e.target.value)
            }
            fullWidth
          >
            <MenuItem value="Sensitive">Sensitive</MenuItem>
            <MenuItem value="Intermediate">Intermediate</MenuItem>
            <MenuItem value="Resistant">Resistant</MenuItem>
          </Select>
        ) : (
          params.row.Sensitivetype
        ),
    },
    { field: "Oraganism", headerName: "Organism", width: 150 },
  ];

  useEffect(() => {
    const fetchData = () => {
      axios
        .get(
          `${urllink}Lab/getdataforreport?Visitid=${capturedatas?.Visit_Id}&patientid=${capturedatas.Patient_Id}&Billinginvoice=${capturedatas?.Billing_Invoice}`
        )
        .then((response) => {
          const groupsData = response.data;
          console.log("groupsData", groupsData);
          setsumma(groupsData);
          fetchTemplateData(response.data); // Fetch the template data for histopatholoy test code
        })
        .catch((error) => {
          console.error("Error fetching data:", error);
        });
    };

    fetchData();
  }, [capturedatas, urllink, editMode]);

  const [PdfBlob, setPdfBlob] = useState(null);
  console.log(PdfBlob);
  useEffect(() => {
    if (Object.keys(capturedatas).length === 0) {
      navigate("/Home/DispatchEntryList");
    }
  }, [capturedatas, navigate]);

  const handleeditchange = (e) => {
    const { name, value } = e.target;

    // Extract the field name and Test_Code from the input name
    // For example, "reportstatus-TC001" -> field: "reportstatus", testCode: "TC001"
    const [field, testCode] = name.split("-");

    if (!testCode) {
      console.error("Test_Code not found in input name:", name);
      return;
    }

    seteditmicrodata((prevData) => ({
      ...prevData,
      [field]: {
        ...prevData[field],
        [testCode]: value,
      },
    }));
  };

  useEffect(() => {
    axios
      .get(`${urllink}Masters/Hospital_Detials_link`)
      .then((res) => {
        const ress = res.data;
        console.log("hospitalllll", ress);
        setClinicDetials((prev) => ({
          ...prev,
          ClinicName: ress.hospitalName,
          ClinicLogo: ress.hospitalLogo,
        }));
      })
      .catch((e) => console.log(e));
    // axios
    //   .get(`${urllink}usercontrol/getClinic?location=${userRecord?.location}`)
    //   .then((response) => {
    //     const data = response.data[0];
    //     if (data) {
    //       setClinicDetials((prev) => ({
    //         ...prev,
    //         ClinicAddress: data.doorNo + "," + data.area + "," + data.street,
    //         ClinicGST: data.gstno,
    //         ClinicCity: data.city,
    //         ClinicState: data.state,
    //         ClinicCode: data.pincode,
    //         ClinicMobileNo: data.phoneNo,
    //         ClinicLandLineNo: data.landline,
    //         ClinicMailID: data.email,
    //       }));
    //     }
    //   })
    //   .catch((error) => {
    //     console.log(error);
    //   });
    // axios
    //   .get(`${urllink}usercontrol/getAccountsetting`)
    //   .then((response) => {
    //     const data = response.data;
    //     console.log(data, "uiiieueeieiei");
    //     if (data) {
    //       setClinicDetials((prev) => ({
    //         ...prev,
    //         ClinicName: data.clinicName,
    //         ClinicLogo: `data:image/png;base64,${data.clinicLogo}`,
    //       }));
    //     }
    //   })
    //   .catch((error) => {
    //     console.log(error);
    //   });
    axios
      .get(
        `${urllink}Lab/get_billing_patient_barcode?Patientid=${capturedatas?.Patient_Id}&Patientname=${capturedatas.Patient_Name}`
      )
      .then((response) => {
        console.log(response);
        setpatinetbillingbarcode(response.data.Patient_Barcode);
      })
      .catch((error) => {
        console.log(error);
      });
  }, [capturedatas, urllink]);

  const handlebeforereprint = () => {
    // setselectedId(capturedatas?.Billing_Invoice);
    setOpenDialog(true);
  };

  const handleupdatesencitivity = () => {
    const postdata = {
      ...culturevalue,
      invoice: capturedatas?.Billing_Invoice,
      visitid: capturedatas?.Visit_Id,
    };
    console.log("postdata", postdata);
    axios
      .post(`${urllink}Lab/culture_sencitivity_type_update`, postdata)
      .then((response) => {
        console.log(response);
        // setEditMode(!editMode);
      })
      .catch((error) => {
        console.log(error);
      });
  };

  const formatMethodName = (methodName) => {
    if (!methodName) return ""; // Handle empty or undefined method names
    return (
      methodName.charAt(0).toUpperCase() + methodName.slice(1).toLowerCase()
    );
  };

  const fetchTemplateData = useCallback(
    (data) => {
      const histopathologyTestCode = summa
        .filter(
          (item) =>
            item.department === "HISTOPATHOLOGY" ||
            item.department === "HEMATOLOGY"
        )
        .flatMap((item) => item.testdetails.map((test) => test.Test_Code))[0];

      console.log("Test Code for HISTOPATHOLOGY:", histopathologyTestCode);

      if (histopathologyTestCode) {
        axios
          .get(
            `${urllink}Lab/Get_Template?Billing_Invoice=${capturedatas.Billing_Invoice}&patient_id=${capturedatas?.Patient_Id}&visitid=${capturedatas?.Visit_Id}&Test_Code=${histopathologyTestCode}`
          )
          .then((res) => {
            console.log(res);
            // Assuming res.data.format contains the format array
            setFormatData(res.data.format);
          })
          .catch((err) => {
            console.error(err);
          });
      }
    },
    [urllink, summa, capturedatas, setFormatData]
  );

  useEffect(() => {
    fetchTemplateData();
  }, [fetchTemplateData]);

  const [imagePreview, setImagePreview] = useState(null);

  console.log(summa1, "uhjfijfiijfijfiijfijfofoifoofjifji");

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setPatientdetails((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

  const handleUpdate = () => {
    console.log("Current formatData:", formatData);
    console.log("Current editmicrodata:", editmicrodata);
    console.log("Current editBioData:", editBioData);

    const isHistoOrHema = summa.some(
      (p) =>
        p.department === "HISTOPATHOLOGY" ||
        (p.department === "HEMATOLOGY" &&
          p.testdetails.some((test) => test.Test_Code === "RD0098"))
    );

    const isMicroWithOt = summa.some(
      (department) =>
        department.department === "MICROBIOLOGY" &&
        department.testdetails.some((test) => test.Report_Type === "Ot")
    );

    const isMicroNotOt = summa.some(
      (department) =>
        department.department === "MICROBIOLOGY" &&
        department.testdetails.some((test) => test.Report_Type !== "Ot")
    );

    const isOtherDepartment = summa.some(
      (department) =>
        department.department !== "MICROBIOLOGY" &&
        department.department !== "HISTOPATHOLOGY"
    );

    if (!editMode) {
      setEditMode(true);

      if (isMicroWithOt) {
        setopenmodels(true);

        const microbiologyContent = summa
          .filter((p) => p.department === "MICROBIOLOGY")
          .flatMap((item) => item.testdetails.map((test) => test.Content))[0];

        setContent(microbiologyContent);
      }
      return;
    }

    //  HISTOPATHOLOGY or HEMATOLOGY
    if (isHistoOrHema && editMode) {
      const formData1 = new FormData();
      const histoTestCode = summa
        .filter(
          (item) =>
            item.department === "HISTOPATHOLOGY" ||
            item.department === "HEMATOLOGY"
        )
        .flatMap((item) => item.testdetails.map((test) => test.Test_Code))[0];

      if (!histoTestCode) {
        alert("Cannot update: Test code missing.");
        return;
      }

      formData1.append("Billing_Invoice", capturedatas.Billing_Invoice);
      formData1.append("Visit_Id", capturedatas.Visit_Id);
      formData1.append("Patient_Id", capturedatas.Patient_Id);

      formatData.forEach((item) => {
        if (item.name === "imageData" && item.value instanceof File) {
          formData1.append(`${histoTestCode}_imageData`, item.value);
        } else if (item.format) {
          formData1.append(`${histoTestCode}_format`, item.format);
        } else if (item.name !== "format") {
          formData1.append(`${histoTestCode}_${item.name}`, item.value || "");
        }
      });

      axios
        .post(`${urllink}Lab/insert_Histo_Template`, formData1, {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        })
        .then((response) => {
          alert("Histo/Hema data updated successfully!");
          setEditMode(false);
        })
        .catch((error) => {
          console.error("Histo/Hema update failed:", error);
        });
    }

    //  MICROBIOLOGY (Ot and Not Ot)
    if ((isMicroWithOt || isMicroNotOt) && editMode) {
      const microDepartments = summa.filter(
        (item) => item.department === "MICROBIOLOGY"
      );

      const updatePromises = microDepartments.flatMap((department) =>
        department.testdetails.map((testDetail) => {
          const microTestCode = testDetail.Test_Code;
          const key = microTestCode;

          const postdata = {
            notes: editmicrodata.notes[microTestCode] || testDetail.Notes || "",
            reportstatus:
              editmicrodata.reportstatus[microTestCode] ||
              testDetail.Report_Status ||
              "Final Report",
            microscopy:
              editmicrodata.microscopy[microTestCode] ||
              testDetail.Microscopy_Data ||
              "",
            culturereport:
              editmicrodata.culturereport[microTestCode] ||
              testDetail.Culture_Report ||
              "",
            bacteriaisolated:
              editmicrodata.bacteriaisolated[microTestCode] ||
              testDetail.Bacteria_Isolated ||
              "",
            Sample:
              editmicrodata.Sample[microTestCode] ||
              testDetail.Sample_Specimen ||
              "",
            patientname: capturedatas.Patient_Name,
            patient_Id: capturedatas.Patient_Id,
            Visit_Id: capturedatas.Visit_Id,
            invoice: capturedatas.Billing_Invoice,
            testcode: microTestCode,
            content:
              testDetail.Report_Type === "Ot"
                ? content
                : testDetail.Content || "",
          };

          return axios
            .post(`${urllink}Lab/update_microafter_flow_completed`, postdata)
            .then((response) => {
              console.log(
                `Microbiology update successful for ${microTestCode}`
              );
              return { success: true, testCode: microTestCode };
            })
            .catch((error) => {
              console.error(
                `Microbiology update failed for ${microTestCode}`,
                error
              );
              return { success: false, testCode: microTestCode, error };
            });
        })
      );

      Promise.all(updatePromises)
        .then((results) => {
          const allSuccessful = results.every((r) => r.success);
          if (allSuccessful) {
            alert("All Microbiology data updated successfully!");
          } else {
            alert("Some Microbiology updates failed. Check console.");
          }

          setEditMode(false);
          if (isMicroWithOt) setopenmodels(false);
          seteditmicrodata({
            notes: {},
            reportstatus: {},
            microscopy: {},
            culturereport: {},
            bacteriaisolated: {},
            Sample: {},
          });
        })
        .catch((err) => {
          console.error("Error updating Microbiology:", err);
        });
    }

    if (editMode && isOtherDepartment) {
      alert("Updating other departments...");
      const otherDepartments = summa.filter(
        (item) =>
          item.department !== "MICROBIOLOGY" &&
          item.department !== "HISTOPATHOLOGY"
      );

      otherDepartments.forEach((dept) => {
        dept.testdetails.forEach((test) => {
          const testCode = test.Test_Code;
          const invoice = test.Billing_Invoice;
          const key = `${testCode}_${invoice}`;
          const updated = editBioData[key];

          if (updated) {
            const mergedData = { ...test, ...updated };
            const postData = {
              invoice: mergedData.Billing_Invoice,
              testcode: mergedData.Test_Code,
              Capture_Value: mergedData.Capture_Value,
              ReferenceRange: mergedData.ReferenceRange,
              Method_Name: mergedData.Method_Name,
              UOM: mergedData.UOM,
              Patient_Id: capturedatas.Patient_Id,
              Visit_Id: capturedatas.Visit_Id,
            };

            console.log("Post Data for Biochemistry", postData);

            axios
              .post(`${urllink}Lab/update_biochemistry`, postData)
              .then((res) => {
                console.log("Biochemistry updated:", res.data);
              })
              .catch((err) => {
                console.error("Biochemistry update failed:", err);
              });
          }
        });
      });

      setEditMode(false);
    }

    if (
      editMode &&
      !isHistoOrHema &&
      !isMicroWithOt &&
      !isMicroNotOt &&
      !isOtherDepartment
    ) {
      console.log("No valid department in edit mode to update.");
      setEditMode(false);
    }
  };

  useEffect(() => {
    if (editMode) {
      formatData.forEach((item) => {
        const div = editableRef.current[item.name];
        if (div && div.innerHTML.trim() === "") {
          div.innerHTML = (item.value || "").trim();
        }
      });
    }
  }, [editMode, formatData]);

  const handleSensitivityChange = (id, value) => {
    const updatedRows = culturevalue.map((row) =>
      row.id === id ? { ...row, Sensitivetype: value } : row
    );
    setculturevalue(updatedRows);
  };

  const parseReferenceData = (referenceData) => {
    if (!referenceData || referenceData === "-") return [];
    return referenceData
      .split(/,|\n/)
      .map((item) => {
        let label,
          minValue = null,
          maxValue = null,
          value = null;

        // Check if it's a range (e.g., "70-140")
        if (item.includes(":")) {
          [label, value] = item.split(":").map((str) => str.trim());
        } else {
          label = "Unknown";
          value = item.trim();
        }

        if (value.includes("-")) {
          [minValue, maxValue] = value
            .split("-")
            .map((str) => parseFloat(str.trim()));
        } else if (value.includes(">=") || value.includes(">")) {
          minValue = parseFloat(value.replace(">=", "").replace(">", ""));
          maxValue = Infinity;
        } else if (value.includes("<=") || value.includes("<")) {
          minValue = -Infinity;
          maxValue = parseFloat(value.replace("<=", "").replace("<", ""));
        }

        return { label, minValue, maxValue };
      })
      .filter((range) => range.label);
  };

  const hasAbnormalValues = summa?.some((group) =>
    group.testdetails.some((test) => {
      const CaptureValue = parseFloat(test.Capture_Value);
      const ranges = parseReferenceData(test.ReferenceRange);

      return ranges.some(
        (range) =>
          !isNaN(CaptureValue) &&
          ((range.minValue !== null && CaptureValue < range.minValue) ||
            (range.maxValue !== null && CaptureValue > range.maxValue))
      );
    })
  );

  const getStatus = (captureValue, referenceRange) => {
    let valueStyle = {};
    let panicLevel = null;

    if (!referenceRange || referenceRange === "-") {
      return { valueStyle, panicLevel };
    }

    const ranges = parseReferenceData(referenceRange);
    const numericValue = parseFloat(captureValue);

    if (isNaN(numericValue)) {
      return { valueStyle, panicLevel };
    }

    let isNormal = false;
    let isAbnormal = false;

    for (let ref of ranges) {
      if (ref.minValue !== null && ref.maxValue !== null) {
        if (numericValue >= ref.minValue && numericValue <= ref.maxValue) {
          isNormal = true;
        } else {
          isAbnormal = true;
        }
      }
    }

    if (isAbnormal && !isNormal) {
      valueStyle = { fontWeight: "bold", fontSize: "15px", color: "red" };
      panicLevel = (
        <span className="indicator">
          <TiArrowUpThick />
        </span>
      );
    }

    return { valueStyle, panicLevel };
  };

  // const handlePrint = useReactToPrint({
  //   content: () => componentRef.current,

  //   onBeforePrint: () => {
  //     setshow(true);
  //   },
  //   onAfterPrint: async () => {
  //     setPdfBlob(null);
  //     const printdata = componentRef.current;

  //     try {
  //       if (printdata) {
  //         const contentWidth = printdata.offsetWidth;
  //         // const contentHeight = printdata.offsetHeight;
  //         const pdfWidth = contentWidth + 2 * 3;
  //         // const pdfHeight = contentHeight + 2 * 10;
  //         const pdf = new jsPDF({
  //           orientation: "portrait",
  //           unit: "px",
  //           format: [pdfWidth, 1120],
  //         });

  //         const barcodeImagecon1 = await toPng(
  //           printdata.querySelector("#get_imagecontent_1")
  //         );
  //         const barcodeImagecon2 = await toPng(
  //           printdata.querySelector("#get_imagecontent_2")
  //         );

  //         const barcodeImage1 = await new Promise((resolve, reject) => {
  //           const barcodeImg1 = new Image();
  //           barcodeImg1.onload = () => resolve(barcodeImg1);
  //           barcodeImg1.onerror = reject;
  //           barcodeImg1.src = barcodeImagecon1;
  //         });

  //         const barcodeImage2 = await new Promise((resolve, reject) => {
  //           const barcodeImg2 = new Image();
  //           barcodeImg2.onload = () => resolve(barcodeImg2);
  //           barcodeImg2.onerror = reject;
  //           barcodeImg2.src = barcodeImagecon2;
  //         });

  //         // Append barcode images to their respective containers
  //         const barcodeContainer1 = printdata.querySelector(
  //           "#get_imagecontent_1"
  //         );
  //         barcodeContainer1.innerHTML = ""; // Clear previous content
  //         barcodeContainer1.appendChild(barcodeImage1);

  //         const barcodeContainer2 = printdata.querySelector(
  //           "#get_imagecontent_2"
  //         );
  //         barcodeContainer2.innerHTML = ""; // Clear previous content
  //         barcodeContainer2.appendChild(barcodeImage2);

  //         pdf.html(printdata, {
  //           x: 5, // Set x-coordinate for content
  //           y: 5, // Set y-coordinate for content
  //           callback: () => {
  //             const generatedPdfBlob = pdf.output("blob");
  //             setPdfBlob(generatedPdfBlob);
  //             // pdf.save(`${capturedatas.Patient_Name}_labReport.pdf`);
  //             setshow(false);

  //             const formdata = new FormData();
  //             const postdata = {
  //               patientname: capturedatas.Patient_Name,
  //               patient_Id: capturedatas.Patient_Id,
  //               Visit_Id: capturedatas.Visit_Id,
  //               refering_doc: capturedatas.Refering_Doctor,
  //               invoice: capturedatas.Billing_Invoice,
  //               patinetbillingbarcode: patinetbillingbarcode,
  //               samplecode: capturedatas.Barcode,
  //               location: userRecord?.location,
  //               createdby: userRecord?.username,
  //             };

  //             // Append each field in postdata to the formdata
  //             for (const key in postdata) {
  //               if (postdata.hasOwnProperty(key)) {
  //                 formdata.append(key, postdata[key]);
  //               }
  //             }

  //             // Append the PDF blob to the formdata
  //             formdata.append("report", generatedPdfBlob);

  //             axios
  //               .post(`${urllink}Phelobotomist/insert_reort_table`, formdata, {
  //                 headers: {
  //                   "Content-Type": "multipart/form-data",
  //                 },
  //               })
  //               .then((response) => {
  //                 console.log(response);
  //                 settrues(!trues);
  //               })
  //               .catch((error) => {
  //                 console.log(error);
  //               });
  //             if (capturedatas.Refering_Hospital === "RMC") {
  //               axios
  //                 .post(
  //                   `${urllink}Phelobotomist/update_report_for_external_request`,
  //                   formdata,
  //                   {
  //                     headers: {
  //                       "Content-Type": "multipart/form-data",
  //                     },
  //                   }
  //                 )
  //                 .then((response) => {
  //                   console.log(response);
  //                   settrues(!trues);
  //                 })
  //                 .catch((error) => {
  //                   console.log(error);
  //                 });
  //             }
  //             // pdf.save(`${capturedatas.Patient_Name}_labReport.pdf`);
  //           },
  //         });

  //       } else {
  //         throw new Error("Unable to get the target element");
  //       }
  //     } catch (error) {}
  //   },
  // });

  const handlePrint = useReactToPrint({
    content: () => componentRef.current,
    onBeforePrint: () => {
      setshow(true);
    },
    onAfterPrint: async () => {
      setshow(false);
    },
  });

  // const handleSave = async () => {
  //   const printdata = componentRef.current;

  //   try {
  //     if (printdata) {
  //       // Create a clone of the original content to manipulate
  //       const clonedContent = printdata.cloneNode(true);

  //       // Add aggressive styling to reduce content size and adjust positioning
  //       const scalingStyle = document.createElement('style');
  //       scalingStyle.textContent = `

  //         .pdf-scaled-content {
  //           transform: scale(0.65);
  //           transform-origin: top left;
  //           width: 60% !important;
  //           margin: -1% 0 0 -5% !important; /* Further move content to the left */
  //           position:relative !important;
  //           left:-40px;
  //           padding: 0 !important;
  //           font-size: 8px !important;
  //         }
  //         .pdf-scaled-content * {
  //           font-size: 8px !important;
  //           line-height: 1 !important;
  //           margin: 2px 0 !important;
  //           padding: 0 !important;
  //         }
  //         .pdf-scaled-content table {
  //           width: 70% !important;
  //            position:relative !important;

  //           border-collapse: collapse !important;
  //         }
  //         .pdf-scaled-content th,
  //         .pdf-scaled-content td {
  //           padding: 2px !important;
  //           font-size: 7px !important;
  //         }

  //       `;

  //       // Apply scaling classes and styles
  //       clonedContent.appendChild(scalingStyle);
  //       clonedContent.classList.add('pdf-scaled-content');

  //       // Create PDF with adjusted settings
  //       const pdf = new jsPDF('portrait', 'px', 'A4', false);

  //       await new Promise((resolve) => {
  //         pdf.html(clonedContent, {
  //           x: 0, // Minimal left padding
  //           y: 0, // Kept vertical padding same
  //           width: 590, // Slightly increased width
  //           html2canvas: {
  //             scale: 1.2, // Adjusted scaling
  //             width: 590,
  //             useCORS: true,
  //             logging: false, // Disable logging
  //           },
  //           callback: function() {
  //             resolve();
  //           }
  //         });
  //       });

  //       // Generate and save PDF
  //       const generatedPdfBlob = pdf.output("blob");
  //       setPdfBlob(generatedPdfBlob);
  //       // const pdfUrl = URL.createObjectURL(generatedPdfBlob);
  //       // setPdfUrl(pdfUrl);

  //       // Existing backend saving logic remains the same
  //       const formdata = new FormData();
  //       const postdata = {
  //         patientname: capturedatas.Patient_Name,
  //         patient_Id: capturedatas.Patient_Id,
  //         Visit_Id: capturedatas.Visit_Id,
  //         refering_doc: capturedatas.Refering_Doctor,
  //         invoice: capturedatas.Billing_Invoice,
  //         patinetbillingbarcode: patinetbillingbarcode,
  //         samplecode: capturedatas.Barcode,
  //         location: userRecord?.location,
  //         createdby: userRecord?.username,
  //       };

  //       for (const key in postdata) {
  //         if (postdata.hasOwnProperty(key)) {
  //           formdata.append(key, postdata[key]);
  //         }
  //       }

  //       formdata.append("report", generatedPdfBlob);

  //       try {
  //         const response = await axios.post(
  //           `${urllink}Phelobotomist/insert_reort_table`,
  //           formdata,
  //           { headers: { "Content-Type": "multipart/form-data" } }
  //         );
  //         console.log(response);
  //         settrues(!trues);
  //       } catch (error) {
  //         console.error("Error saving the report:", error);
  //       }

  //       if (capturedatas.Refering_Hospital === "RMC") {
  //         try {
  //           const response = await axios.post(
  //             `${urllink}Phelobotomist/update_report_for_external_request`,
  //             formdata,
  //             { headers: { "Content-Type": "multipart/form-data" } }
  //           );
  //           console.log(response);
  //           settrues(!trues);
  //         } catch (error) {
  //           console.error("Error updating external request:", error);
  //         }
  //       }

  //       pdf.save(`${capturedatas.Patient_Name}_labReport.pdf`);

  //     } else {
  //       throw new Error("Unable to get the target element");
  //     }
  //   } catch (error) {
  //     console.error("Error generating PDF:", error);
  //   }
  // };

  const printStylesA4 = `
  @page {
    size: A4 !important;
    border: 1px solid black !important;
  }
`;

  // const handleSave = async () => {
  //   try {
  //     // Remove existing A4 styles if present
  //     const existingStyleElement = document.getElementById("printStylesA4");
  //     if (existingStyleElement) {
  //       document.head.removeChild(existingStyleElement);
  //     }

  //     // Add A4-specific styles
  //     const styleElement = document.createElement("style");
  //     styleElement.id = "printStylesA4";
  //     styleElement.innerHTML = printStylesA4;
  //     document.head.appendChild(styleElement);

  //     const printdata = componentRef.current;

  //     if (!printdata) {
  //       console.error("Unable to get the target element");
  //       return;
  //     }

  //     // Clone the target content
  //     const clonedContent = printdata.cloneNode(true);

  //     // Define padding and dimensions for A4
  //     const padding = 20;
  //     const contentWidth = printdata.offsetWidth;
  //     const pdfWidth = contentWidth + 2 * padding;
  //     const pdfHeight = (pdfWidth * 297) / 210; // Maintain A4 aspect ratio

  //     // Initialize jsPDF for A4 size
  //     const pdf = new jsPDF({
  //       unit: "px",
  //       format: [pdfWidth, pdfHeight],
  //       orientation: "portrait",
  //     });

  //     // Render the HTML content into the PDF
  //     await pdf.html(clonedContent, {
  //       x: padding,
  //       y: padding,
  //       callback: async () => {
  //         try {
  //           // Generate PDF Blob
  //           const generatedPdfBlob = pdf.output("blob");
  //           setPdfBlob(generatedPdfBlob);

  //           const formdata = new FormData();
  //           const postdata = {
  //             patientname: capturedatas.Patient_Name,
  //             patient_Id: capturedatas.Patient_Id,
  //             Visit_Id: capturedatas.Visit_Id,
  //             refering_doc: capturedatas.Refering_Doctor,
  //             invoice: capturedatas.Billing_Invoice,
  //             patinetbillingbarcode: patinetbillingbarcode,
  //             samplecode: capturedatas.Barcode,
  //             location: userRecord?.location,
  //             createdby: userRecord?.username,
  //           };

  //           for (const key in postdata) {
  //             if (postdata.hasOwnProperty(key)) {
  //               formdata.append(key, postdata[key]);
  //             }
  //           }

  //           formdata.append("report", generatedPdfBlob);

  //           // Save to backend
  //           try {
  //             const response = await axios.post(
  //               `${urllink}Phelobotomist/insert_reort_table`,
  //               formdata,
  //               { headers: { "Content-Type": "multipart/form-data" } }
  //             );
  //             console.log(response);
  //             settrues(!trues);
  //           } catch (error) {
  //             console.error("Error saving the report:", error);
  //           }

  //           // Conditional external update
  //           if (capturedatas.Refering_Hospital === "RMC") {
  //             try {
  //               const response = await axios.post(
  //                 `${urllink}Phelobotomist/update_report_for_external_request`,
  //                 formdata,
  //                 { headers: { "Content-Type": "multipart/form-data" } }
  //               );
  //               console.log(response);
  //               settrues(!trues);
  //             } catch (error) {
  //               console.error("Error updating external request:", error);
  //             }
  //           }
  //         } catch (error) {
  //           console.error("Error during PDF generation or saving:", error);
  //         }
  //         pdf.save(`${capturedatas.Patient_Name}_labReport.pdf`);
  //       },
  //     });
  //   } catch (error) {
  //     console.error("Error generating PDF:", error);
  //   } finally {
  //     // Cleanup: Remove A4 styles
  //     const styleElementAfter = document.getElementById("printStylesA4");
  //     if (styleElementAfter) {
  //       document.head.removeChild(styleElementAfter);
  //     }
  //   }
  // };

  const handleSave = async () => {
    const element = componentRef.current;
    if (!element) {
      return;
    }

    try {
      const canvas = await html2canvas(element, {
        scale: 2, // Higher scale for better quality
      });
      const data = canvas.toDataURL("image/png");

      const pdf = new jsPDF({
        orientation: "portrait",
        unit: "px",
        format: "a4",
      });

      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = pdf.internal.pageSize.getHeight();

      const imgProperties = pdf.getImageProperties(data);
      const imgWidth = pdfWidth;
      const imgHeight = (imgProperties.height * pdfWidth) / imgProperties.width;

      let heightLeft = imgHeight;
      let position = 0;

      // Add the first page
      pdf.addImage(data, "PNG", 0, position, imgWidth, imgHeight);
      heightLeft -= pdfHeight;

      // Add more pages if content overflows
      while (heightLeft > 0) {
        position -= pdfHeight; // Move to the next page
        pdf.addPage();
        pdf.addImage(data, "PNG", 0, position, imgWidth, imgHeight);
        heightLeft -= pdfHeight;
      }

      const generatedPdfBlob = pdf.output("blob");
      setPdfBlob(generatedPdfBlob);

      const formdata = new FormData();
      const postdata = {
        patientname: capturedatas.Patient_Name,
        patient_Id: capturedatas.Patient_Id,
        Visit_Id: capturedatas.Visit_Id,
        refering_doc: capturedatas.Refering_Doctor,
        invoice: capturedatas.Billing_Invoice,
        patinetbillingbarcode: patinetbillingbarcode,
        samplecode: capturedatas.Barcode,
        location: userRecord?.location,
        createdby: userRecord?.username,
      };

      for (const key in postdata) {
        if (postdata.hasOwnProperty(key)) {
          formdata.append(key, postdata[key]);
        }
      }

      formdata.append("report", generatedPdfBlob);

      // Save to backend
      try {
        const response = await axios.post(
          `${urllink}Phelobotomist/insert_reort_table`,
          formdata,
          { headers: { "Content-Type": "multipart/form-data" } }
        );
        console.log(response);
        settrues(!trues);
      } catch (error) {
        console.error("Error saving the report:", error);
      }

      // Conditional external update for "RMC"
      if (capturedatas.Refering_Hospital === "RMC") {
        try {
          const response = await axios.post(
            `${urllink}Phelobotomist/update_report_for_external_request`,
            formdata,
            { headers: { "Content-Type": "multipart/form-data" } }
          );
          console.log(response);
          settrues(!trues);
        } catch (error) {
          console.error("Error updating external request:", error);
        }
      }

      // Save the PDF file locally
      pdf.save(`${capturedatas.Patient_Name}_labReport.pdf`);
    } catch (error) {
      console.error("Error generating PDF or during the process:", error);
    }
  };

  const [loader, setloader] = useState(false);

  const handleDownloadPDF = async () => {
    setemailsent(true);

    const printData = componentRef.current;

    if (!printData) {
      console.error("Unable to get the target element");
      return;
    }

    setshow(true);

    try {
      const contentWidth = printData.offsetWidth;
      const contentHeight = printData.offsetHeight;
      // const pdfWidth = contentWidth + 2 * 5;
      // const pdfHeight = contentHeight + 2 * 5;

      const a4WidthPx = 794; // A4 width in pixels
      const a4HeightPx = 1123; // A4 height in pixels

      const pdf = new jsPDF({
        orientation: "portrait",
        unit: "px",
        format: [a4WidthPx, a4HeightPx],
      });

      const marginX = (a4WidthPx - contentWidth) / 2;
      const marginY = (a4HeightPx - contentHeight) / 2;

      pdf.html(printData, {
        x: marginX > 0 ? marginX : 5,
        y: marginY > 0 ? marginY : 5,
        callback: async () => {
          const generatedPdfBlob = pdf.output("blob");
          setPdfBlob(generatedPdfBlob);

          const formData = new FormData();
          const postData = {
            patientname: capturedatas.Patient_Name,
            Patient_Id: capturedatas.Patient_Id,
          };

          for (const key in postData) {
            if (postData.hasOwnProperty(key)) {
              formData.append(key, postData[key]);
            }
          }

          formData.append("report", generatedPdfBlob);
          setloader(true);
          try {
            const response = await axios.post(
              `${urllink}Phelobotomist/sendEmail`,
              formData,
              {
                headers: {
                  "Content-Type": "multipart/form-data",
                },
              }
            );
            setemailsent(false);
            setPdfBlob(null);
            setloader(false);
            console.log(response);
          } catch (error) {
            console.error(error);
          } finally {
            setshow(false);
          }
        },
      });
    } catch (error) {
      console.error("Error generating PDF:", error);
      setshow(false);
    }
  };

  const uploadAdapter = (loader) => {
    return {
      upload: () => {
        return new Promise((resolve, reject) => {
          loader.file.then((file) => {
            const reader = new FileReader();

            reader.onloadend = () => {
              // Convert image file to base64
              const base64String = reader.result.split(",")[1];
              resolve({ default: `data:${file.type};base64,${base64String}` });
            };

            reader.onerror = (error) => {
              reject(error);
            };

            reader.readAsDataURL(file);
          });
        });
      },
    };
  };

  function uploadPlugin(editor) {
    editor.plugins.get("FileRepository").createUploadAdapter = (loader) => {
      return uploadAdapter(loader);
    };
  }

  const formatName = (name) => {
    return name
      .split("_")
      .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
      .join(" ");
  };

  // const loadImage = (src) => {
  //   return new Promise((resolve, reject) => {
  //     const img = new Image();
  //     img.onload = () => resolve(img);
  //     img.onerror = reject;
  //     img.src = src;
  //   });
  // };

  // const appendImageToContainer = (container, image) => {
  //   container.innerHTML = ""; // Clear previous content
  //   container.appendChild(image);
  // };

  // const PdfViewer = ({ pdfBlob }) => {
  //   // Check if pdfBlob is a Blob object
  //   if (pdfBlob instanceof Blob) {
  //     // Convert Blob object to data URL
  //     const url = URL.createObjectURL(pdfBlob);

  //     // Render the PDF using iframe
  //     return (
  //       <iframe
  //         title="PDF Viewer"
  //         src={url}
  //         style={{
  //           width: "100%",
  //           height: "435px",
  //           border: "1px solid rgba(0, 0, 0, 0.5)", // Black border with reduced opacity
  //         }}
  //       />
  //     );
  //   }

  //   // If pdfBlob is not a Blob object, assume it's already a valid data URL and render it directly
  //   return (
  //     <img
  //       src={pdfBlob}
  //       alt="Concern Form"
  //       style={{
  //         width: "100%",
  //         height: "100%",
  //         marginTop: "20px",
  //       }}
  //     />
  //   );
  // };

  // function getInnerHeightOfPDF() {
  //   const pdfget = new jsPDF({
  //     orientation: "portrait", // or 'landscape'
  //     unit: "px", // pixels
  //     format: [595, 842], // A4 size in pixels (width, height)
  //   });
  //   const innerHeightInPoints = pdfget.internal.pageSize.getHeight();
  //   pdfget.deletePage();
  //   const innerHeightInPixels = innerHeightInPoints * (1 / 72) * 96;
  //   return innerHeightInPixels - 10;
  // }

  const handleContentEditableInputChange = (e, name) => {
    const div = editableRef.current[name];
    let updatedContent = div.innerHTML.trim();

    // Remove unintended <br> or extra spaces
    updatedContent = updatedContent
      .replace(/<br\s*\/?>/g, "")
      .replace(/\s+/g, " ");

    // Update formatData
    setFormatData((prev) =>
      prev.map((item) =>
        item.name === name ? { ...item, value: updatedContent } : item
      )
    );
  };

  const handleMouseUp = (name) => {
    setTimeout(() => {
      // Ensure the state updates correctly after selection
      const selection = window.getSelection();
      if (selection && selection.toString().trim() !== "") {
        setSelectedField(name);
        setSelectedText(selection.toString().trim());
        console.log(
          `Selected text for ${name}: "${selection.toString().trim()}"`
        );
      }
    }, 10);
  };

  const makeTextBold = () => {
    if (!selectedText || !selectedField) return;

    const updatedData = [...formatData];
    const itemIndex = updatedData.findIndex((p) => p.name === selectedField);

    if (itemIndex !== -1) {
      const value = updatedData[itemIndex].value;

      // Escape special characters in the selected text for regex
      const escapedText = selectedText.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

      // Replace selected text with bolded text
      const boldedValue = value.replace(
        new RegExp(`(${escapedText})`, "g"),
        `<b>$1</b>`
      );

      updatedData[itemIndex] = {
        ...updatedData[itemIndex],
        value: boldedValue,
      };

      setFormatData(updatedData);

      // Manually update the contentEditable div
      if (editableRef.current[selectedField]) {
        editableRef.current[selectedField].innerHTML = boldedValue;
      }
    }
  };

  const makeTextNormal = () => {
    if (!selectedText || !selectedField) return;

    const updatedData = [...formatData];
    const itemIndex = updatedData.findIndex((p) => p.name === selectedField);

    if (itemIndex !== -1) {
      let value = updatedData[itemIndex].value;

      // Escape special characters in the selected text for regex
      const escapedText = selectedText.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

      // Create a regex to find the selected text wrapped in <b> tags
      const regex = new RegExp(`<b>${escapedText}</b>`, "g");

      // Replace the bold text with normal text
      const updatedValue = value.replace(regex, selectedText);

      // Update formatData state
      updatedData[itemIndex] = {
        ...updatedData[itemIndex],
        value: updatedValue,
      };

      setFormatData(updatedData);

      // Manually update the contentEditable div
      if (editableRef.current[selectedField]) {
        editableRef.current[selectedField].innerHTML = updatedValue;
      }
    }
  };

  const handleImageChange = (e) => {
    const file = e.target.files[0]; // Get the selected file
    if (file) {
      const previewUrl = URL.createObjectURL(file); // Create a preview URL

      setImagePreview(previewUrl); // Set the preview URL for immediate display

      // Update the `formatData` array
      setFormatData((prev) =>
        prev?.map(
          (field) =>
            field.name === "imageData"
              ? { ...field, value: file } // Store the actual file in `value`
              : field // Keep other fields unchanged
        )
      );
    }
  };

  return (
    <>
      {loader ? (
        <>
          <div class="loader"></div>
        </>
      ) : (
        <div>
          <TableComponent
            ref={componentRef}
            patinetbillingbarcode={patinetbillingbarcode}
            patinetbillingQr={patinetbillingQr}
            capturedatas={capturedatas}
            report={report}
            summa={summa}
            userRecord={userRecord}
            navigate={navigate}
            ClinicDetials={ClinicDetials}
            urllink={urllink}
            uniqueOrganisms={uniqueOrganisms}
            getSensitivityColor={getSensitivityColor}
            alphabetHeaders={alphabetHeaders}
            // index = {index}
            summa1={summa1}
            formatData={formatData}
            emailsent={emailsent}
            SignPerson={SignPerson}
            printpapaer={printpapaer}
            isNoRendered={isNoRendered}
            formatHeading={formatHeading}
            microandhistonumber={microandhistonumber}
            editMode={editMode}
            setEditMode={setEditMode}
            autoResizeTextarea={autoResizeTextarea}
            handleeditchange={handleeditchange}
            openmodels={openmodels}
            setFormatData={setFormatData}
            formatMethodName={formatMethodName}
            // otreporttype = {otreporttype}
            setopenmodels={setopenmodels}
            contentRef={contentRef}
            uploadPlugin={uploadPlugin}
            isSidebarOpen={isSidebarOpen}
            content={content}
            setContent={setContent}
            editmicrodata={editmicrodata}
            formatName={formatName}
            touppercasefun={touppercasefun}
            setSelectedText={setSelectedText}
            setSelectedField={setSelectedField}
            handleContentEditableInputChange={handleContentEditableInputChange}
            showmodel={showmodel}
            setshowmodel={setshowmodel}
            culturevalue={culturevalue}
            page={page}
            pageSize={pageSize}
            dynamicColumns={dynamicColumns}
            setPage={setPage}
            showdown={showdown}
            totalPages={totalPages}
            handleupdatesencitivity={handleupdatesencitivity}
            handleSensitivityChange={handleSensitivityChange}
            imagePreview={imagePreview}
            handleImageChange={handleImageChange}
            getStatus={getStatus}
            hasAbnormalValues={hasAbnormalValues}
            handleMouseUp={handleMouseUp}
            editableRef={editableRef}
            handleBioChange={handleBioChange}
            editBioData={editBioData}
            handleInputChange={handleInputChange}
            patientdetails={patientdetails}
          />

          <br />

          <div className="sdcyysc_uxcds67">
            <label>
              <h3 style={{ color: "black" }}>Do you want Header and Footer?</h3>
            </label>
            <div className="dhchche_oici8">
              <h3>
                {" "}
                <label>
                  <input
                    type="checkbox"
                    name="headerFooterOption"
                    value="yes"
                    checked={emailsent === true}
                    onChange={handleCheckboxChange}
                  />
                  Yes
                </label>
              </h3>
              <h3>
                <label>
                  <input
                    type="checkbox"
                    name="headerFooterOption"
                    value="no"
                    checked={emailsent === false}
                    onChange={handleCheckboxChange}
                  />
                  No
                </label>
              </h3>
            </div>
          </div>
          <br />

          <div className="Register_btn_con">
            {summa?.some(
              (p) =>
                p.department === "HISTOPATHOLOGY" ||
                (p.department === "HEMATOLOGY" &&
                  p.testdetails.some((test) => test.Test_Code === "RD0098")) ||
                summa?.some(
                  (department) => department.department === "MICROBIOLOGY"
                ) ||
                summa?.some(
                  (department) =>
                    department.department !== "MICROBIOLOGY" &&
                    department.department !== "HISTOPATHOLOGY"
                )
            ) && (
              <>
                <button
                  className="RegisterForm_1_btns Rhugt_report"
                  onClick={handleUpdate}
                >
                  {editMode ? "Update" : "Edit"}
                </button>

                {/* Show these buttons only for HISTOPATHOLOGY */}
                {editMode &&
                  summa?.some((p) => p.department === "HISTOPATHOLOGY") && (
                    <div className="popupbtn">
                      <label className="toolbar-button">
                        <input
                          type="file"
                          className="hidden-input"
                          onChange={handleImageChange}
                        />
                        <i className="icon-file"></i> Choose File
                      </label>
                      <button className="toolbar-button" onClick={makeTextBold}>
                        <i className="icon-bold"></i> Bold
                      </button>
                      <button
                        className="toolbar-button"
                        onClick={makeTextNormal}
                      >
                        <i className="icon-normal"></i> Normal
                      </button>
                    </div>
                  )}
              </>
            )}

            <button
              onClick={handleSave} // Save button for saving the PDF
              className="RegisterForm_1_btns Rhugt_report"
            >
              Save
            </button>

            <button
              onClick={
                Dispatch === "Dispatched" ? handlebeforereprint : handlePrint
              }
              className="RegisterForm_1_btns  Rhugt_report"
            >
              {Dispatch === "Dispatched" ? "Reprint" : "Print"}
            </button>

            <div>
              {summa?.length > 0 && (
                <div className="Register_btn_con">
                  <button
                    onClick={handleDownloadPDF}
                    className="RegisterForm_1_btns  Rhugt_report"
                  >
                    Send Email
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* )}
              content={() => componentRef.current}
            /> */}

          <CancelAppointmentDialog
            open={openDialog}
            onClose={() => setOpenDialog(false)}
            setCancelReason={setCancelReason}
            cancelReason={cancelReason}
          />
        </div>
      )}
    </>
  );
}
export default Reports;
