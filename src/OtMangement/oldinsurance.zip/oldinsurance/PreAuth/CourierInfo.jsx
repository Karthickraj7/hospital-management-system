import React, { useState, useEffect } from "react";
import axios from "axios";
import { useSelector, useDispatch } from "react-redux";
import ReactGrid from "../../OtherComponent/ReactGrid/ReactGrid";

export default function CourierInfo() {
  const dispatch = useDispatch();
  const InsurancePatientDetailes = useSelector(
    (state) => state.Insurancedata?.InsurancePatientDetailes
  );
  const userRecord = useSelector((state) => state.userRecord?.UserData);
  const UrlLink = useSelector((state) => state.userRecord?.UrlLink);

  const [CourierInfoList, setCourierInfoList] = useState([]);
  const [CourierInfoData, setCourierInfoData] = useState({
    CourierName: "",
    TrackingNumber: "",
    DateSent: "",
    DateReceived: "",
  });

  const CourierInfoColumn = [
    { key: "Id", name: "Id" },
    { key: "CourierName", name: "Courier Name" },
    { key: "TrackingNumber", name: "Tracking Number" },
    { key: "DateSent", name: "Date Sent" },
    { key: "DateReceived", name: "Date Received" },
  ];

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setCourierInfoData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const CourierInfoDataSave = async (e) => {
    e.preventDefault();
    const formData = {
      InsurancePatientId: InsurancePatientDetailes?.id,
      createAt: userRecord.username,
      ...CourierInfoData,
    };

    try {
      const response = await axios.post(
        `${UrlLink}Insurance/CourierInfo_Data`,
        formData,
        {
          headers: {
            "Content-Type": "application/json",
          },
        }
      );
      console.log("CourierInfo_Data Post Response:", response.data);
      dispatch({
        type: "toast",
        value: {
          message: "Courier details saved successfully",
          type: "success",
        },
      });
      setCourierInfoData({
        CourierName: "",
        TrackingNumber: "",
        DateSent: "",
        DateReceived: "",
      });
      fetchCourierInfo();
    } catch (error) {
      console.error("Error:", error.response?.data || error.message);
      const errorMessage =
        error.response?.data?.error || "Failed to save courier details";
      dispatch({
        type: "toast",
        value: { message: errorMessage, type: "error" },
      });
    }
  };

  const fetchCourierInfo = async () => {
    if (InsurancePatientDetailes?.id) {
      try {
        const response = await axios.get(
          `${UrlLink}Insurance/CourierInfo_Data`,
          {
            params: { InsurancePatientId: InsurancePatientDetailes?.id },
          }
        );
        const data = response.data;
        console.log("get CourierInfo_Data:",data);
        
        if (Array.isArray(data) && data.length > 0) {
          setCourierInfoList(data);
        } else {
          setCourierInfoList([]);
        }
      } catch (error) {
        console.error("Error fetching courier data:", error);
        dispatch({
          type: "toast",
          value: {
            message: "Failed to fetch courier details",
            type: "error",
          },
        });
      }
    }
  };

  useEffect(() => {
    fetchCourierInfo();
  }, [InsurancePatientDetailes]);

  return (
    <div className="Main_container_app">
      <div className="RegisFormcon_1">
        <div className="RegisForm_1">
          <label>
            Courier Name <span>:</span>
          </label>
          <input
            type="text"
            name="CourierName"
            value={CourierInfoData.CourierName}
            onChange={handleInputChange}
            placeholder="Enter Courier Name"
            required
          />
        </div>
        <div className="RegisForm_1">
          <label>
            Tracking Number <span>:</span>
          </label>
          <input
            type="text"
            name="TrackingNumber"
            value={CourierInfoData.TrackingNumber}
            onChange={handleInputChange}
            placeholder="Enter Tracking Number"
            required
          />
        </div>
        <div className="RegisForm_1">
          <label>
            Date Sent <span>:</span>
          </label>
          <input
            type="date"
            name="DateSent"
            value={CourierInfoData.DateSent}
            onChange={handleInputChange}
            required
          />
        </div>
        <div className="RegisForm_1">
          <label>
            Date Received <span>:</span>
          </label>
          <input
            type="date"
            name="DateReceived"
            value={CourierInfoData.DateReceived}
            onChange={handleInputChange}
            required
          />
        </div>
      </div>
      <div className="Main_container_Btn">
        <button onClick={CourierInfoDataSave}>Save</button>
      </div>
      <ReactGrid columns={CourierInfoColumn} RowData={CourierInfoList} />
    </div>
  );
}