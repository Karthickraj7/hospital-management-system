import * as React from 'react';
import PropTypes from 'prop-types';
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import Box from '@mui/material/Box';

import PreAuthStepper from './PreAuth/PreAuthStepper';
import PreAuthDocumentStepper from './PreAuth/PreAuthDocumentStepper';
import CourierInfo from './PreAuth/CourierInfo';


function CustomTabPanel(props) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}
    >
      {value === index && <Box>
        <br/>
        {children}</Box>}
    </div>
  );
}

CustomTabPanel.propTypes = {
  children: PropTypes.node,
  index: PropTypes.number.isRequired,
  value: PropTypes.number.isRequired,
};

function a11yProps(index) {
  return {
    id: `simple-tab-${index}`,
    'aria-controls': `simple-tabpanel-${index}`,
  };
}

export default function BasicTabs() {
  const [value, setValue] = React.useState(0);

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  return (
    <Box sx={{ width: '100%' }}>
      <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
        <Tabs value={value} onChange={handleChange} aria-label="basic tabs example">
          <Tab sx={{width:'30%'}} label="Pre Auth Form" {...a11yProps(0)} />
          <Tab sx={{width:'30%'}} label="Documents" {...a11yProps(1)} />
          <Tab sx={{width:'30%'}} label="Courier Info" {...a11yProps(2)} />
        </Tabs>
      </Box>
      <CustomTabPanel value={value} index={0}>
        <PreAuthStepper/>        
      </CustomTabPanel>
      <CustomTabPanel value={value} index={1}>
        <PreAuthDocumentStepper/>
      </CustomTabPanel>
      <CustomTabPanel value={value} index={2}>
        <CourierInfo/>
      </CustomTabPanel>
    </Box>
  );
}
