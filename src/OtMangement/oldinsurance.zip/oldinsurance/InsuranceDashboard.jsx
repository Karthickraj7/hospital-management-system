import axios from 'axios';
import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import './Insurance.css';
import { useNavigate, useLocation } from 'react-router-dom';
import ReactGrid from '../OtherComponent/ReactGrid/ReactGrid';
import { Button } from '@mui/material';
import EditIcon from '@mui/icons-material/Edit';
import ToastAlert from '../OtherComponent/ToastContainer/ToastAlert';
import CheckCircleOutlineIcon from '@mui/icons-material/CheckCircleOutline';
import CancelPresentationIcon from '@mui/icons-material/CancelPresentation';

const InsuranceDashboard = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const dispatchvalue = useDispatch();

  const [ServiceS, setServiceS] = useState([]);
  const toast = useSelector((state) => state.userRecord?.toast);
  const UrlLink = useSelector((state) => state.userRecord?.UrlLink);
  const [RackMasterPage, setRackMasterPage] = useState('Dashboard')


  const [isRejectionPopupOpen, setIsRejectionPopupOpen] = useState(false);
  const [rejectionReason, setRejectionReason] = useState('');
  const [selectedRow, setSelectedRow] = useState(null);

  const [InsurancePatientlist, setInsurancePatientlist] = useState([]);
  const [SerchOptions, setSerchOptions] = useState({
    ServiceType: '',
    PatientId: '',
    PatientName: '',
    CLNumber: '',
    PayerId: '',
    Filterby: 'Pending',
  });

  const [StatusCount, setStatusCount] = useState({
    PENDINGCount: 0,
    DraftCount: 0,
    SubmittedCount: 0,
    ApprovedCount: 0,
    RejectedCount: 0,
    DischargeCount: 0,
  });

  useEffect(() => {
    axios
      .get(`${UrlLink}Insurance/Get_StatusCount`)
      .then((res) => {
        let data = res.data;
        if (data && Object.values(data).length !== 0) {
          setStatusCount(data);
        }
      })
      .catch((err) => {
        console.log(err);
      });
  }, [UrlLink]);

  const HandelEditedata = (row) => {
    navigate('/Home/InsuranceMainpage');
    dispatchvalue({ type: 'HrFolder', value: 'InsuranceMainpage' });
    dispatchvalue({ type: 'InsurancePatientDetailes', value: row });
  };

  useEffect(() => {
    fetchDepartmentList();
  }, []);

  const fetchDepartmentList = async () => {
    try {
      const res = await axios.get(`${UrlLink}Masters/Department_Detials_link`);
      setServiceS(res.data);
    } catch (err) {
      console.log('Error fetching departments:', err);
    }
  };

  const Dashboardcolumn = useMemo(() => {
    const baseColumns = [
      {
        key: 'id',
        name: 'S.No',
        frozen: true,
      },
      {
        key: 'PatientId',
        name: 'Patient Id',
        frozen: true,
      },
      {
        key: 'PatientName',
        name: 'Patient Name',
        frozen: true,
      },
      {
        key: 'RegistrationId',
        name: 'MRN',
        frozen: true,
        width: '150px',
      },
      {
        key: 'ALNumber',
        name: 'ALNumber',
      },
      {
        key: 'InsuranceName',
        name: 'Payer/TPA',
      },
      {
        key: 'PayerTPAMemberID',
        name: 'Payer/TPA Member ID',
      },
      {
        key: 'Papersstatustype',
        name: 'Request Type',
      },
      {
        key: 'CreatedAt',
        name: 'Created Date',
      },
      {
        key: 'Papersstatus',
        name: 'Status',
      },
    ];

    const rejectionReasonColumn = {
      key: 'RejectedReason',
      name: 'Rejection Reason',
      renderCell: ({ row }) =>
        row.Papersstatus.trim().toUpperCase() === 'REJECTED' ? row.RejectedReason || 'No reason provided' : '-',
    };

    const renderActionCell = ({ row }) => (
      <>
        {row.Papersstatus === 'APPROVED' ? (
          <Button className="cell_btn" onClick={() => HandelEditedata(row)}>
            <EditIcon className="check_box_clrr_cancell" />
          </Button>
        ) : row.Papersstatus === 'DRAFT' ? (
          <Button className="cell_btn" onClick={() => HandelEditedata(row)}>
            <EditIcon className="check_box_clrr_cancell" />
          </Button>
        ) : row.Papersstatus === 'PENDING' ? (
          <>
            <Button className="cell_btn">
              <CheckCircleOutlineIcon
                className="check_box_clrr_cancell"
                onClick={() => UpdateStatusFun(row, 'DRAFT')}
              />
            </Button>
            <Button
              className="cell_btn"
              onClick={() => {
                setSelectedRow(row);
                setIsRejectionPopupOpen(true);
              }}
            >
              <CancelPresentationIcon className="check_box_clrr_cancell" />
            </Button>
          </>
        ) : row.Papersstatus === 'SUBMITTED' ? (
          <>
            <Button className="cell_btn" onClick={() => HandelEditedata(row)}>
              <EditIcon className="check_box_clrr_cancell" />
            </Button>
            <Button className="cell_btn">
              <CheckCircleOutlineIcon
                className="check_box_clrr_cancell"
                onClick={() => UpdateStatusFun(row, 'APPROVED')}
              />
            </Button>
            <Button
              className="cell_btn"
              onClick={() => {
                setSelectedRow(row);
                setIsRejectionPopupOpen(true);
              }}
            >
              <CancelPresentationIcon className="check_box_clrr_cancell" />
            </Button>
          </>
        ) : row.Papersstatus === 'REJECTED' ? (
          <>
            <Button className="cell_btn" onClick={() => HandelEditedata(row)}>
              <EditIcon className="check_box_clrr_cancell" />
            </Button>
          </>

        ) : row.Papersstatus === 'DISCHARGED' ? (
          <>
            <Button className="cell_btn" onClick={() => HandelEditedata(row)}>
              <EditIcon className="check_box_clrr_cancell" />
            </Button>
            {/* <Button className="cell_btn">
              <CheckCircleOutlineIcon
                className="check_box_clrr_cancell"
                onClick={() => UpdateStatusFun(row, 'DRAFT')}
              />
            </Button> */}
          </>
        ) : (
          <>No Action</>
        )}
      </>
    );

    if (SerchOptions.Filterby === 'ALL') {
      return baseColumns;
    } else if (SerchOptions.Filterby === 'REJECTED') {
      return [
        ...baseColumns,
        rejectionReasonColumn,
        { key: 'Action', name: 'Action', renderCell: renderActionCell },
      ];
    } else {
      return [
        ...baseColumns,
        { key: 'Action', name: 'Action', renderCell: renderActionCell },
      ];
    }
  }, [SerchOptions.Filterby]);


  const Handeleonchange = (e) => {
    const { name, value } = e.target;
    setSerchOptions((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const GetSetCountNumbers = useCallback(() => {
    axios
      .get(`${UrlLink}Insurance/Get_StatusCount`)
      .then((res) => {
        let data = res.data;
        if (data && Object.values(data).length !== 0) {
          setStatusCount(data);
        }
      })
      .catch((err) => {
        console.log(err);
      });
  }, [UrlLink]);

  useEffect(() => {
    GetSetCountNumbers();
  }, [GetSetCountNumbers]);

  const GetInsurance_detailes = useCallback(() => {
    const selectedService = ServiceS.find(
      (service) => service.id === parseInt(SerchOptions.ServiceType)
    );
    const serviceTypeValue = selectedService ? selectedService.DepartmentName : '';

    const updatedSearchOptions = {
      ...SerchOptions,
      ServiceType: serviceTypeValue,
    };

    axios
      .get(`${UrlLink}Insurance/Signal_PatientEntry_Get_Details`, {
        params: updatedSearchOptions,
      })
      .then((res) => {
        let data = res.data;
        console.log(data, "Dataaaaaaa");

        if (data && Array.isArray(data) && data.length !== 0) {
          setInsurancePatientlist(data);
        } else {
          setInsurancePatientlist([]);
        }
      })
      .catch((err) => {
        console.log(err);
      });
  }, [UrlLink, SerchOptions, ServiceS]);

  useEffect(() => {
    GetInsurance_detailes();
  }, [GetInsurance_detailes]);

  const UpdateStatusFun = (row, Status, rejectionReason = '') => {
    let confirmMessage =
      Status === 'REJECTED'
        ? 'Are you sure you want to reject this record?'
        : `Are you sure you want to change status to ${Status}?`;

    if (window.confirm(confirmMessage)) {
      let params = {
        InstId: row.id,
        Status: Status,
        RejectionReason: Status === 'REJECTED' ? rejectionReason : '',
      };

      axios
        .post(
          `${UrlLink}Insurance/Update_StatusFor_Insurance_Patient_Detailes`,
          params
        )
        .then((res) => {
          let resdata = res.data;
          console.log('API Response:', resdata);

          let type = Object.keys(resdata)[0];
          let mess = Object.values(resdata)[0];
          const tdata = {
            message: mess,
            type: type === 'success' ? 'success' : 'error',
          };
          dispatchvalue({ type: 'toast', value: tdata });

          setInsurancePatientlist((prev) => {
            const updatedList = prev.map((item) =>
              item.id === row.id
                ? {
                  ...item,
                  Papersstatus: resdata.data.Papersstatus || item.Papersstatus,
                  Papersstatustype: resdata.data.Papersstatustype || item.Papersstatustype,
                  RejectedReason: resdata.data.RejectionReason || rejectionReason,
                }
                : item
            );
            console.log('Updated InsurancePatientlist:', updatedList);
            return updatedList;
          });

          GetInsurance_detailes();
          GetSetCountNumbers();
        })
        .catch((err) => {
          console.error('Error updating status:', err);
          dispatchvalue({
            type: 'toast',
            value: { message: 'Failed to update status', type: 'error' },
          });
        });
    }
  };


  const handleRejectionSubmit = (reason) => {
    if (!reason.trim()) {
      dispatchvalue({
        type: 'toast',
        value: { message: 'Please enter a rejection reason', type: 'warn' },
      });
      return;
    }
    if (selectedRow) {
      UpdateStatusFun(selectedRow, 'REJECTED', reason);
    }
    setIsRejectionPopupOpen(false);
    setRejectionReason('');
    setSelectedRow(null);
  };

  const RejectionPopup = ({ isOpen, onClose, onSubmit }) => {
    const [reason, setReason] = useState('');

    const handleSubmit = () => {
      if (!reason.trim()) {
        dispatchvalue({
          type: 'toast',
          value: { message: 'Please enter a rejection reason', type: 'warn' },
        });
        return;
      }
      onSubmit(reason);
      setReason('');
    };

    if (!isOpen) return null;

    return (
      <div className="loader" onClick={onClose}>
        <div className="cardModel" onClick={(e) => e.stopPropagation()}>
          <h3>Enter Rejection Reason</h3>
          <textarea
            value={reason}
            onChange={(e) => setReason(e.target.value)}
            placeholder="Enter reason for rejection..."
            style={{
              width: '100%',
              minHeight: '100px',
              margin: '10px 0',
              padding: '8px',
              border: '1px solid #ccc',
              borderRadius: '4px',
            }}
          />
          <div className="modal-buttons" style={{ display: 'flex', gap: '10px' }}>
            <Button
              onClick={handleSubmit}
              style={{
                backgroundColor: '#bf2e26',
                color: 'white',
                padding: '8px 16px',
              }}
            >
              Submit
            </Button>
            <Button
              onClick={onClose}
              style={{
                backgroundColor: '#ccc',
                color: 'black',
                padding: '8px 16px',
              }}
            >
              Cancel
            </Button>
          </div>
        </div>
      </div>
    );
  };

  useEffect(() => {
    if (location.state?.Filterby) {
      setSerchOptions((prev) => ({
        ...prev,
        Filterby: location.state.Filterby,
      }));
    }
  }, [location.state]);


  // -----------------------------------------------------------------------------------------------------
  // -----------------------------------------------Claime--------------------------------------------------------
  // -------------------------------------------------------------------------------------------------------




  // -----------------------------------------------------------------------------------------------------
  // -------------------------------------------------Claime------------------------------------------------------
  // -------------------------------------------------------------------------------------------------------

  return (
    <>
      <div className="Main_container_app">
        <h3>Insurance Dashboard</h3>
        <br />
        <div className="RegisterTypecon">
          <div className="RegisterType">

            {["Dashboard", "Claime"].map((p, ind) => (

              <div className="registertypeval" key={ind}>
                <input
                  type="radio"
                  id={p}
                  name="appointment_type"
                  checked={RackMasterPage === p}
                  onChange={(e) => {
                    setRackMasterPage(e.target.value)
                  }}
                  value={p}
                />
                <label htmlFor={p}>
                  {p}
                </label>
              </div>
            ))}

          </div>
        </div>
        <br />
        {RackMasterPage === 'Dashboard' && <>
          <div className="RegisFormcon_1">
            <div className="RegisForm_1">
              <label>
                Service Type<span>:</span>
              </label>
              <select
                name="ServiceType"
                value={SerchOptions.ServiceType}
                onChange={Handeleonchange}
              >
                <option value="">Select</option>
                {ServiceS.map((Service, ind) => (
                  <option key={ind} value={Service.id}>
                    {Service.DepartmentName}
                  </option>
                ))}
              </select>
            </div>

            <div className="RegisForm_1">
              <label>
                Patient Id<span>:</span>
              </label>
              <input
                type="text"
                name="PatientId"
                value={SerchOptions.PatientId}
                onChange={Handeleonchange}
                autoComplete="off"
              />
            </div>

            <div className="RegisForm_1">
              <label>
                Patient First Name<span>:</span>
              </label>
              <input
                type="text"
                name="PatientName"
                value={SerchOptions.PatientName}
                onChange={Handeleonchange}
                autoComplete="off"
              />
            </div>

            <div className="RegisForm_1">
              <label>
                CL Number<span>:</span>
              </label>
              <input
                type="text"
                name="CLNumber"
                value={SerchOptions.CLNumber}
                onChange={Handeleonchange}
              />
            </div>

            <div className="RegisForm_1">
              <label>
                Payer/TPA Member Id<span>:</span>
              </label>
              <input
                type="text"
                name="PayerId"
                value={SerchOptions.PayerId}
                onChange={Handeleonchange}
              />
            </div>
          </div>

          <div className="new-patient-registration-form1">
            <div className="Insurancenew-navigation">
              <h2>
                <div
                  className="insur_box_chnge6"
                  style={{
                    backgroundColor: 'transparent',
                    transition: 'background-color 0.3s',
                  }}
                  onClick={() =>
                    setSerchOptions((prev) => ({
                      ...prev,
                      Filterby: 'PENDING',
                    }))
                  }
                >
                  <button
                    style={{
                      backgroundColor: '#bf2e26',
                      width: '100%',
                      padding: '20px',
                    }}
                  >
                    Pending
                  </button>
                  <p
                    style={{
                      backgroundColor:
                        SerchOptions.Filterby === 'PENDING' ? '#bf2e26' : 'transparent',
                    }}
                  >
                    {StatusCount.PENDINGCount}
                  </p>
                </div>

                <div
                  className="insur_box_chnge6"
                  style={{
                    backgroundColor: 'transparent',
                    transition: 'background-color 0.3s',
                  }}
                  onClick={() =>
                    setSerchOptions((prev) => ({
                      ...prev,
                      Filterby: 'DRAFT',
                    }))
                  }
                >
                  <button
                    style={{
                      backgroundColor: '#ffd966',
                      width: '100%',
                      padding: '20px',
                    }}
                  >
                    Draft
                  </button>
                  <p
                    style={{
                      backgroundColor:
                        SerchOptions.Filterby === 'DRAFT' ? '#ffd966' : 'transparent',
                    }}
                  >
                    {StatusCount.DraftCount}
                  </p>
                </div>

                <div
                  className="insur_box_chnge6"
                  style={{
                    backgroundColor: 'transparent',
                    transition: 'background-color 0.3s',
                  }}
                  onClick={() =>
                    setSerchOptions((prev) => ({
                      ...prev,
                      Filterby: 'SUBMITTED',
                    }))
                  }
                >
                  <button
                    style={{
                      backgroundColor: '#b3e0ff',
                      width: '100%',
                      padding: '20px',
                    }}
                  >
                    Submitted
                  </button>
                  <p
                    style={{
                      backgroundColor:
                        SerchOptions.Filterby === 'SUBMITTED' ? '#b3e0ff' : 'transparent',
                    }}
                  >
                    {StatusCount.SubmittedCount}
                  </p>
                </div>

                <div
                  className="insur_box_chnge6"
                  style={{
                    backgroundColor: 'transparent',
                    transition: 'background-color 0.3s',
                  }}
                  onClick={() =>
                    setSerchOptions((prev) => ({
                      ...prev,
                      Filterby: 'APPROVED',
                    }))
                  }
                >
                  <button
                    style={{
                      backgroundColor: '#b3ffb3',
                      width: '100%',
                      padding: '20px',
                    }}
                  >
                    Approved
                  </button>
                  <p
                    style={{
                      backgroundColor:
                        SerchOptions.Filterby === 'APPROVED' ? '#b3ffb3' : 'transparent',
                    }}
                  >
                    {StatusCount.ApprovedCount}
                  </p>
                </div>

                <div
                  className="insur_box_chnge6"
                  style={{
                    backgroundColor: 'transparent',
                    transition: 'background-color 0.3s',
                  }}
                  onClick={() =>
                    setSerchOptions((prev) => ({
                      ...prev,
                      Filterby: 'REJECTED',
                    }))
                  }
                >
                  <button
                    style={{
                      backgroundColor: '#ffcc99',
                      width: '100%',
                      padding: '20px',
                    }}
                  >
                    Rejected
                  </button>
                  <p
                    style={{
                      backgroundColor:
                        SerchOptions.Filterby === 'REJECTED' ? '#ffcc99' : 'transparent',
                    }}
                  >
                    {StatusCount.RejectedCount}
                  </p>
                </div>

                <div
                  className="insur_box_chnge6"
                  style={{
                    backgroundColor: 'transparent',
                    transition: 'background-color 0.3s',
                  }}
                  onClick={() =>
                    setSerchOptions((prev) => ({
                      ...prev,
                      Filterby: 'DISCHARGED',
                    }))
                  }
                >
                  <button
                    style={{
                      backgroundColor: '#ffcccc',
                      width: '100%',
                      padding: '20px',
                    }}
                  >
                    Discharge Approved
                  </button>
                  <p
                    style={{
                      backgroundColor:
                        SerchOptions.Filterby === 'DISCHARGED' ? '#ffcccc' : 'transparent',
                    }}
                  >
                    {StatusCount.DischargeCount}
                  </p>
                </div>
              </h2>
            </div>
          </div>
          <ReactGrid columns={Dashboardcolumn} RowData={InsurancePatientlist} />
          <RejectionPopup
            isOpen={isRejectionPopupOpen}
            onClose={() => {
              setIsRejectionPopupOpen(false);
              setSelectedRow(null);
            }}
            onSubmit={handleRejectionSubmit}
          />
        </>}

        {RackMasterPage === 'Claime' && <>
          <h3>Insurance Claime</h3>
          <br />

          <div className="RegisFormcon_1">
            <div className="RegisForm_1">
              <label>
                Service Type<span>:</span>
              </label>
              <select
                name="ServiceType"
                value={SerchOptions.ServiceType}
                onChange={Handeleonchange}
              >
                <option value="">Select</option>
                {ServiceS.map((Service, ind) => (
                  <option key={ind} value={Service.id}>
                    {Service.DepartmentName}
                  </option>
                ))}
              </select>
            </div>

            <div className="RegisForm_1">
              <label>
                Patient Id<span>:</span>
              </label>
              <input
                type="text"
                name="PatientId"
                value={SerchOptions.PatientId}
                onChange={Handeleonchange}
                autoComplete="off"
              />
            </div>

            <div className="RegisForm_1">
              <label>
                Patient First Name<span>:</span>
              </label>
              <input
                type="text"
                name="PatientName"
                value={SerchOptions.PatientName}
                onChange={Handeleonchange}
                autoComplete="off"
              />
            </div>

            <div className="RegisForm_1">
              <label>
                CL Number<span>:</span>
              </label>
              <input
                type="text"
                name="CLNumber"
                value={SerchOptions.CLNumber}
                onChange={Handeleonchange}
              />
            </div>

            <div className="RegisForm_1">
              <label>
                Payer/TPA Member Id<span>:</span>
              </label>
              <input
                type="text"
                name="PayerId"
                value={SerchOptions.PayerId}
                onChange={Handeleonchange}
              />
            </div>
          </div>
          

        </>}
      </div>
      <ToastAlert Message={toast.message} Type={toast.type} />

    </>
  );
};

export default InsuranceDashboard;

