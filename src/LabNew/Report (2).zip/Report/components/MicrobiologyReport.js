import React from "react";
import { generateBarcode } from "../utils/barcodeUtils";

const MicrobiologyReport = ({
  group,
  dpt,
  capturedatas,
  summa,
  emailsent,
  patinetbillingbarcode,
  patinetbillingQr,
  SignPerson,
  editMode,
  autoResizeTextarea,
  handleeditchange,
  groupedData,
  newEntry,
  handlecultureChange,
  organismdetails,
  antibioticorg,
  handleAddAntibiotic,
  handleDeleteOrganism,
  handleDeleteAntibiotic,
  handleCaptureValueChange,
  handleColonyCountChange,
  handleSensitivityChange,
  hasSensitive,
  hasIntermediate,
  hasResistant
}) => {
  return (
    <div>
      {/* OT Report */}
      {group?.Report_Type === "Ot" && (
        <div>
          <table className="report_table report_table_for_micro">
            <tbody className="print_body Selected-table-container">
              <tr>
                <td>
                  <h3>{dpt.department}</h3>
                  <div className="completed_report_1111">
                    <div className="completed_report completed_report04948 gghbuy_o9">
                      <div
                        style={{
                          display: "flex",
                          flexDirection: "column",
                          justifyContent: "center",
                          width: "100%",
                        }}
                        dangerouslySetInnerHTML={{
                          __html: group?.EditContent,
                        }}
                      />
                    </div>
                  </div>
                </td>
              </tr>
            </tbody>
          </table>
          {group?.Report_Status !== "Preliminary Report" && (
            <div className="Add_items_Purchase_Master yydd_end_reprt">
              <span> - End of Report - </span>
            </div>
          )}
        </div>
      )}

      {/* NoGrowth Report */}
      {group?.Report_Type === "NoGrowth" && (
        <div className="culture_comment" style={{height:"300px",}}>

          {group.Sample_Specimen !== "" && (
            <div className="culture_row">
              <label className="culture_lable">
                Nature of specimen
              </label><span>:</span>
              {editMode ? (
                <textarea
                  name={`Sample-${group.Test_Code}`}
                  onChange={handleeditchange}
                  defaultValue={group?.Sample_Specimen}
                  onBeforeInput={autoResizeTextarea}
                  onInput={autoResizeTextarea}
                />
              ) : (
                <p className="culture_p">{group?.Sample_Specimen}</p>
              )}
            </div>
          )}

          <div className="culture_row">
            <label className="culture_lable">
              Test Requested
            </label><span>:</span>
            <p className="culture_p">{group?.DisplayText}</p>
          </div>
          <div className="culture_row">
            <label className="culture_lable">
              Report Status
            </label><span>:</span>
            {editMode ? (
              <select
                className=""
                name={`reportstatus-${group.Test_Code}`}
                onChange={handleeditchange}
              >
                <option value="">Select</option>
                <option value="Final Report">Final Report</option>
                <option value="Preliminary Report">Preliminary Report</option>
              </select>
            ) : (
              <p className="culture_p">
                {group?.Report_Status || "Final Report"}
              </p>
            )}
          </div>
          {group.Microscopy_Data !== "" && (
            <div className="culture_row">
              <label className="culture_lable">
                Microscopy
              </label><span>:</span>
              {editMode ? (
                <textarea
                  name={`microscopy-${group.Test_Code}`}
                  onChange={handleeditchange}
                  defaultValue={group?.Microscopy_Data}
                  onBeforeInput={autoResizeTextarea}
                  onInput={autoResizeTextarea}
                />
              ) : (
                <p className="culture_p">{group?.Microscopy_Data}</p>
              )}
            </div>
          )}
          {group.Culture_Report !== "" && (
            <div className="culture_row">
              <label className="culture_lable">
                Culture Report
              </label><span>:</span>
              {editMode ? (
                <textarea
                  name={`culturereport-${group.Test_Code}`}
                  onChange={handleeditchange}
                  defaultValue={group?.Culture_Report}
                  onBeforeInput={autoResizeTextarea}
                  onInput={autoResizeTextarea}
                />
              ) : (
                <p className="culture_p">{group?.Culture_Report}</p>
              )}
            </div>
          )}
          {group?.Report_Status !== "Preliminary Report" && (
            <tr>
              <div className="report_end">- End of Report -</div>
            </tr>
          )}
        </div>
      )}

      {/* Isolated Report */}
      {group?.Report_Type === "Isolated" && (
        <div  className="culture_comment">
         
          {group.Sample_Specimen !== "" && (
            <div className="culture_row">
              <label className="culture_lable">
                Nature of specimen<span>:</span>
              </label>
              {editMode ? (
                <textarea
                  name={`Sample-${group.Test_Code}`}
                  onChange={handleeditchange}
                  defaultValue={group?.Sample_Specimen}
                  onBeforeInput={autoResizeTextarea}
                  onInput={autoResizeTextarea}
                />
              ) : (
                <p className="culture_p">{group?.Sample_Specimen}</p>
              )}
            </div>
          )}

          <div className="culture_row">
            <label className="culture_lable">
              Test Requested<span>:</span>
            </label>
            <p className="culture_p">{group?.DisplayText}</p>
          </div>
          <div className="culturetest_div Histo_new_css_div hewty_8j">
            <label className="culture_lable">
              Report Status<span>:</span>
            </label>
            {editMode ? (
              <select
                className=""
                name={`reportstatus-${group.Test_Code}`}
                onChange={handleeditchange}
              >
                <option value="">Select</option>
                <option value="Final Report">Final Report</option>
                <option value="Preliminary Report">Preliminary Report</option>
              </select>
            ) : (
              <p className="culture_p">
                {group?.Report_Status || "Final Report"}
              </p>
            )}
          </div>
          {group.Microscopy_Data !== "" && (
            <div className="culture_row">
              <label className="culture_lable">
                Microscopy<span>:</span>
              </label>
              {editMode ? (
                <textarea
                  name={`microscopy-${group.Test_Code}`}
                  onChange={handleeditchange}
                  defaultValue={group?.Microscopy_Data}
                  onBeforeInput={autoResizeTextarea}
                  onInput={autoResizeTextarea}
                />
              ) : (
                <p className="culture_p">{group?.Microscopy_Data}</p>
              )}
            </div>
          )}
          {group.Bacteria_Isolated !== "" && (
            <div className="culture_row">
              <label className="culture_lable">
                Bacteria Isolated<span>:</span>
              </label>
              {editMode ? (
                <textarea
                  name={`bacteriaisolated-${group.Test_Code}`}
                  onChange={handleeditchange}
                  defaultValue={group?.Bacteria_Isolated}
                  onBeforeInput={autoResizeTextarea}
                  onInput={autoResizeTextarea}
                />
              ) : (
                <p className="culture_p">{group?.Bacteria_Isolated}</p>
              )}
            </div>
          )}
          {group?.Report_Status !== "Preliminary Report" && (
            <div className="Add_items_Purchase_Master yydd_end_reprt">
              <span> - End of Report - </span>
            </div>
          )}
        </div>
      )}

      {/* Sensitivity Report */}
      {group?.Report_Type === "Sensitivity" && (
        <div className="culture_div">
          <div className="culture_comment">

            {group.Sample_Specimen !== "" && group.Sample_Specimen !== null && (
              <div className="culture_row">
                <label className="culture_lable">
                  Specimen
                </label><span>:</span>
                {editMode ? (
                  <textarea
                    name={`Sample-${group.Test_Code}`}
                    onChange={handleeditchange}
                    defaultValue={group?.Sample_Specimen}
                    onBeforeInput={autoResizeTextarea}
                    onInput={autoResizeTextarea}
                  />
                ) : (
                  <p className="culture_p">{group?.Sample_Specimen}</p>
                )}
              </div>
            )}

            {group.site !== "" && group.site !== null && (
              <div className="culture_row">
                <label className="culture_lable">
                  site
                </label><span>:</span>
                {editMode ? (
                  <textarea
                    name={`site-${group.Test_Code}`}
                    onChange={handleeditchange}
                    defaultValue={group?.site}
                    onBeforeInput={autoResizeTextarea}
                    onInput={autoResizeTextarea}
                  />
                ) : (
                  <p className="culture_p">{group?.site}</p>
                )}
              </div>
            )}

            <div className="culture_row">
              <label className="culture_lable">
                Test Requested
              </label><span>:</span>
              <p className="culture_p">{group?.DisplayText}</p>
            </div>
            {group.macroscopy !== "" && (
              <div className="culture_row">
                <label className="culture_lable">
                  Macroscopy
                </label><span>:</span>
                {editMode ? (
                  <textarea
                    name={`microscopy-${group.Test_Code}`}
                    onChange={handleeditchange}
                    defaultValue={group?.macroscopy}
                    onBeforeInput={autoResizeTextarea}
                    onInput={autoResizeTextarea}
                  />
                ) : (
                  <p className="culture_p">{group?.macroscopy}</p>
                )}
              </div>
            )}
            {group.Microscopy_Data !== "" && (
              <div className="culture_row">
                <label className="culture_lable">
                  Microscopy
                </label><span>:</span>
                {editMode ? (
                  <textarea
                    name={`microscopy-${group.Test_Code}`}
                    onChange={handleeditchange}
                    defaultValue={group?.Microscopy_Data}
                    onBeforeInput={autoResizeTextarea}
                    onInput={autoResizeTextarea}
                  />
                ) : (
                  <p className="culture_p">{group?.Microscopy_Data}</p>
                )}
              </div>
            )}

            <div className="culture_row">
              <label className="culture_lable">
                Organism Isolated
              </label><span>:</span>
              <div className="culture_p">
                <ol
                  style={{
                    listStyleType: "upper-alpha",
                    textAlign: "start",
                    paddingLeft: "10px",
                  }}
                >
                  {Object.entries(groupedData).map(([organism], index) => (
                    <li key={index}>
                      <i style={{ fontWeight: "600", fontStyle: "italic", fontFamily: "'Times New Roman', serif" }}>
                        {organism}
                      </i>
                    </li>
                  ))}
                </ol>
              </div>
            </div>

            {group?.Notes !== "" && (
              <div className="culture_row">
                <label className="culture_lable">
                  Comments
                </label><span>:</span>
                {editMode ? (
                  <textarea
                    name={`notes-${group.Test_Code}`}
                    onChange={handleeditchange}
                    defaultValue={group?.Notes}
                    onBeforeInput={autoResizeTextarea}
                    onInput={autoResizeTextarea}
                  />
                ) : (
                  <p className="culture_p">{group?.Notes}</p>
                )}
              </div>
            )}
          </div>
          <br />
          {/* for adding new antibiotic */}
          {editMode && (
            <div className="add-antibiotic-section">
              <h3>Add New Antibiotic</h3>
              <div className="input-row">
                <div className="input-container">
                  <input
                    list="organismList"
                    name="newOrganism"
                    value={newEntry.newOrganism}
                    onChange={handlecultureChange}
                    placeholder="Select Organism"
                    autoCapitalize="off"
                  />
                  <datalist id="organismList">
                    {organismdetails?.map((organism, index) => (
                      <option key={index} value={organism.Organism_Name} />
                    ))}
                  </datalist>
                </div>
                <div className="input-container">
                  <input
                    list="antibioticList"
                    name="Antibiotic"
                    value={newEntry.Antibiotic}
                    onChange={handlecultureChange}
                    placeholder="Select Antibiotic"
                    autoComplete="off"
                  />
                  <datalist id="antibioticList">
                    {antibioticorg?.map((antibiotic, index) => (
                      <option key={index} value={antibiotic.anti_biotic} />
                    ))}
                  </datalist>
                </div>
                <div className="input-container">
                  <select
                    name="Sensitivity"
                    value={newEntry.Sensitivity}
                    onChange={handlecultureChange}
                  >
                    <option value="Sensitive">Sensitive</option>
                    <option value="Intermediate">Intermediate</option>
                    <option value="Resistant">Resistant</option>
                  </select>
                </div>
              </div>
              <div className="input-row">
                <div className="input-container">
                  <input
                    type="text"
                    name="Value"
                    value={newEntry.Value}
                    onChange={handlecultureChange}
                    placeholder="Antibiotic Value"
                    autoComplete="off"
                  />
                </div>
                <div className="input-container">
                  <input
                    type="text"
                    name="ColonyCount"
                    value={newEntry.ColonyCount}
                    onChange={handlecultureChange}
                    placeholder="Colony count"
                    autoComplete="off"
                  />
                </div>
              </div>
              <div className="Register_btn_con">
                <button className="RegisterForm_1_btns" onClick={handleAddAntibiotic}>
                  Add
                </button>
              </div>
            </div>
          )}
          <div className="culture_table_div">
            <table className="culture_table">
              <thead className="culture_head">
                <tr>
                    <th className="culture_th anti">ANTIBIOTICS</th>
                    {(editMode || hasSensitive) && <th className="culture_th values">SENSITIVE</th>}
                    {(editMode || hasIntermediate) && <th className="culture_th values">INTERMEDIATE</th>}
                    {(editMode || hasResistant) && <th className="culture_th values">RESISTANT</th>}
                    <th className="culture_th values">SENSITIVE VALUES</th>
                    <th className="culture_th values">CAPTURE VALUE</th>
                    {editMode && <th className="culture_th values">Action</th>}
                </tr>
              </thead>
              <tbody className="culture_body">
                {Object.entries(groupedData).map(([organism, antibiotics], index) => {
                  return (
                    <>
                      <tr>
                        <td colSpan="6" className="organisam_td">
                          {editMode ? (
                            <div style={{ display: "flex", alignItems: "center", gap: "10px", marginBottom: "15px" }}>
                              <strong>{organism} - </strong>
                              <input
                                type="text"
                                value={antibiotics[0]?.ColonyCount || "-"}
                                onChange={(e) => handleColonyCountChange(organism, e.target.value)}
                              />
                              <button onClick={() => handleDeleteOrganism(organism)}>Delete Organism</button>
                            </div>
                          ) : (
                            <strong className="organisam_name">
                              {organism}-{antibiotics[0]?.ColonyCount || "-"}
                            </strong>
                          )}
                        </td>
                      </tr>
                      {antibiotics?.map((item, idx) => (
                        <tr key={idx}>
                          <div className="antibiotic_div">
                            <td className="anti antibiotic_td">{item.antibiotic || "-"}</td>
                            {(editMode || hasSensitive) && (
                              <td className="antibiotic_td values">
                                {editMode ? (
                                  <input
                                   className="culture_input"
                                    type="text"
                                    value={item.Sensitive || ""}
                                    onChange={(e) =>
                                      handleCaptureValueChange(organism, idx, "Sensitive", e.target.value)
                                    }
                                  />
                                ) : (
                                  item.Sensitive || "-"
                                )}
                              </td>
                            )}

                            {(editMode || hasIntermediate) && (
                              <td className="antibiotic_td values">
                                {editMode ? (
                                  <input
                                  className="culture_input"
                                    type="text"
                                    value={item.Intermediate || ""}
                                    onChange={(e) =>
                                      handleCaptureValueChange(organism, idx, "Intermediate", e.target.value)
                                    }
                                  />
                                ) : (
                                  item.Intermediate || "-"
                                )}
                              </td>
                            )}

                            {(editMode || hasResistant) && (
                              <td className="antibiotic_td values">
                                {editMode ? (
                                  <input
                                   className="culture_input"
                                    type="text"
                                    value={item.Resistant || ""}
                                    onChange={(e) =>
                                      handleCaptureValueChange(organism, idx, "Resistant", e.target.value)
                                    }
                                  />
                                ) : (
                                  item.Resistant || "-"
                                )}
                              </td>
                            )}

                            <td className="antibiotic_td values">
                              {editMode ? (
                                <select
                                 className="culture_input"
                                  value={item.Sensitivetype}
                                  onChange={(e) =>
                                    handleSensitivityChange(organism, idx, e.target.value)
                                  }
                                >
                                  <option value="Sensitive">Sensitive</option>
                                  <option value="Intermediate">Intermediate</option>
                                  <option value="Resistant">Resistant</option>
                                </select>
                              ) : (
                                item.Sensitivetype || "-"
                              )}
                            </td>

                            <td className="antibiotic_td values">
                              {editMode ? (
                                <input
                                 className="culture_input"
                                  type="text"
                                  value={item.Antibiotic_Value || ""}
                                  onChange={(e) =>
                                    handleCaptureValueChange(organism, idx, "Antibiotic_Value", e.target.value)
                                  }
                                />
                              ) : (
                                item.Antibiotic_Value || "-"
                              )}
                            </td>

                            {editMode && (
                              <td className="antibiotic_td values">
                                <button
                                  className="delete-button"
                                  onClick={() => handleDeleteAntibiotic(item.Culture_Id)}
                                >
                                  Delete
                                </button>
                              </td>
                            )}
                          </div>
                        </tr>
                      ))}
                    </>
                  );
                })}
              </tbody>
            </table>
          </div>

          <br />

          {group?.Report_Status !== "Preliminary Report" && (
            <tr>
              <div className="report_end">- End of Report -</div>
            </tr>
          )}
        </div>
      )}
    </div>
  );
};

export default MicrobiologyReport;
