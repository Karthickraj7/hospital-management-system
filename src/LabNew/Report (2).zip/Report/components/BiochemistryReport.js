import React from "react";
import { generateBarcode } from "../utils/barcodeUtils";
import KMCHlogo from "../../../Assets/KMCHlogo.png";
import sdalogo from "../../../Assets/sdalogo.jpeg";
import isologo from "../../../Assets/isologo.jpeg";

const BiochemistryReport = ({
  dpt,
  capturedatas,
  summa,
  emailsent,
  patinetbillingbarcode,
  patinetbillingQr,
  SignPerson,
  editMode,
  editBioData,
  handleBioChange,
  patientdetails,
  handleInputChange,
  getStatus,
  formatMethodName,
  testBold,
  provision
}) => {
  // Filter Microbiology tests with Iscutoffvalue === "Yes" for SEROLOGY
  const cutoffTests =
    dpt.department === "SEROLOGY" &&
      !dpt.testdetails.some((p) => p.Test_Code === "LTC1116")
      ? dpt.testdetails.filter((test) => test.Iscutoffvalue === "Yes")
      : [];
  const hasCutoffReport = cutoffTests.length > 0;

  if (!hasCutoffReport) {
    // Separate logic for Offers
    const isOffer = dpt.testdetails.some(
      (test) => test.Test_Method === "Offers"
    );

    // Step 1: Flatten tests from Packagegroup and testdetails
    const flattenedTests = [];
    dpt.testdetails.forEach((item) => {
      if (item.Packagegroup) {
        item.Packagegroup.forEach((group) => {
          group.testdetails.forEach((test) => {
            flattenedTests.push({
              ...test,
              _groupName: group.groupname,
              _packageName: group.PackageName,
              _packageCode: test.PackageCode,
              _isGroupTest: true,
            });
          });
        });
      } else {
        flattenedTests.push({
          ...item,
          _groupName: item.Group_Name || "",
          _packageName: item.PackageName || "",
          _packageCode: item.PackageCode || "",
          _isGroupTest: false,
        });
      }
    });

    // Step 2: Filter tests based on Test_Method === "Offers"
    const filteredTests = isOffer
      ? flattenedTests.filter((test) => test.Test_Method === "Offers")
      : flattenedTests;

    // Step 3: Group tests by PackageCode
    const groupedByPackage = filteredTests.reduce((acc, test) => {
      const packageKey = test._packageCode || "no_package";
      if (!acc[packageKey]) {
        acc[packageKey] = {
          packageName: test._packageName,
          groups: {},
        };
      }
      const groupKey = test._groupName || "no_group";
      if (!acc[packageKey].groups[groupKey]) {
        acc[packageKey].groups[groupKey] = [];
      }
      acc[packageKey].groups[groupKey].push(test);
      return acc;
    }, {});

    console.log("Bio------------REportsss");

    // Step 4: Render each package as a separate table for Offers
    return (
      <div className="page_a4">
        {Object.entries(groupedByPackage).map(
          ([packageKey, packageData], pkgIndex) => {
            const isSemenAnalysisPackage =
              packageData?.packageName === "SEMEN ANALYSIS";
            return (
              <table key={`package_table_${packageKey}`} className="main_table">
                {/* Header Section for Each Package */}
                <thead className="main_header">
                  <tr>
                    
                      {emailsent && (
                        <div className="head">
                        <div className="letter_head">
                          <tr >
                            <div className="header_row_one">
                              <img src={sdalogo} alt="logo" className="header_logo" />
                            </div>
                            <div className="header_row_two">
                              <div className="header_logo">
                                <img src={KMCHlogo} alt="logo" className="header_logo" />
                              </div>

                              <div>

                                <div className="header_word">
                                  <h2>KARUNA MEDICAL COLLEGE HOSPITAL</h2>{" "}
                                </div>


                                <div className="header_word">
                                  <h3>
                                    VILAYODI - CHITTUR - PALAKKAD - KERALA - 678103
                                  </h3>
                                </div>
                              </div>

                              <div className="header_logo">
                                <img src={isologo} alt="logo" className="header_logo" />
                              </div>

                            </div>
                          </tr>
                        </div>
                        </div>
                      )}
                    
                  </tr>
                  <div className="main_head">
                    {!summa.some((item) => item.Report_Type === "OT") &&

                      <>
                        <tr className="one_line_tr">
                          <div className="barcodes">
                            <td className="one_line_td">
                              <div className="line_one">
                                <img
                                  className="bar_code_1"
                                  src={
                                    patinetbillingbarcode
                                      ? generateBarcode(patinetbillingbarcode)
                                      : ""
                                  }
                                  alt="barcodeimage"
                                />
                              </div>
                            </td>
                            <td className="one_line_td">
                              <div className="line_one">
                                <img
                                  className="bar_code_1"
                                  src={
                                    capturedatas && capturedatas.Barcode
                                      ? generateBarcode(capturedatas.Barcode)
                                      : ""
                                  }
                                  alt="barcodeimage"
                                />
                              </div>
                            </td>
                          </div>
                        </tr>
                        <tr className="two_line_tr">
                          <td className="two_line_td">
                            <div className="div_box">
                              <label className="header_lable">
                                Patient Name
                              </label><p>:</p>
                              {editMode ? (
                                <span className="header_span">
                                  <select
                                    name="title"
                                    value={patientdetails.title}
                                    onChange={handleInputChange}
                                    className="patient-titllles"
                                  >
                                    <option value="">Title</option>
                                    <option value="Mr">Mr.</option>
                                    <option value="Ms">Ms.</option>
                                    <option value="Mrs">Mrs.</option>
                                    <option value="Baby">Baby.</option>
                                    <option value="Dr">Dr.</option>
                                    <option value="BabyOf">Baby.of.</option>
                                    <option value="Child">Child.</option>
                                    <option value="Sister">Sister</option>
                                    <option value="Master">Master</option>
                                    <option value="Others">Others</option>
                                  </select>
                                  <input
                                    type="text"
                                    name="patientname"
                                    value={patientdetails.patientname}
                                    onChange={handleInputChange}
                                    className="patient-name"
                                  />
                                </span>
                              ) : (
                                <span className="header_span">
                                  {capturedatas.Title}.{" "}
                                  {capturedatas.Patient_Name}
                                </span>
                              )}
                            </div>
                          </td>
                          <td className="two_line_td_right">
                            <div className="div_box">
                              <label className="header_lable">
                                OP/IP No
                              </label><p>:</p>
                              <span className="header_span">
                                {capturedatas.Billing_Invoice}
                              </span>
                            </div>
                          </td>
                        </tr>
                        <tr className="two_line_tr">
                          <td className="two_line_td">
                            <div className="div_box">
                              <label className="header_lable">
                                Age/Gender
                              </label><p>:</p>
                              {editMode ? (
                                <span className="patient-input-group">
                                  <input
                                    type="number"
                                    name="age"
                                    value={patientdetails.age}
                                    onChange={handleInputChange}
                                    className="patient-age"
                                  />
                                  <select
                                    name="timeperiod"
                                    value={patientdetails.timeperiod}
                                    onChange={handleInputChange}
                                    className="patient-year"
                                  >
                                    <option value="hour">Hours</option>
                                    <option value="day">Days</option>
                                    <option value="week">Weeks</option>
                                    <option value="month">Months</option>
                                    <option value="year">Years</option>
                                  </select>
                                  /
                                  <select
                                    name="gender"
                                    value={patientdetails.gender}
                                    onChange={handleInputChange}
                                    className="patient-gender"
                                  >
                                    <option value="Male">Male</option>
                                    <option value="Female">Female</option>
                                  </select>
                                </span>
                              ) : (
                                <span className="header_span">
                                  {capturedatas.Age}{" "}
                                  {capturedatas?.Time_Period}s /{" "}
                                  {capturedatas.Gender}
                                </span>
                              )}
                            </div>
                          </td>
                          <td className="two_line_td_right">
                            <div className="div_box">
                              <label className="header_lable">
                                Sample
                              </label><p>:</p>
                              <span className="header_span">
                                {dpt.testdetails?.[0]?.Packagegroup
                                  ? dpt.testdetails[0].Packagegroup[0]
                                    ?.testdetails[0]?.Sample_Specimen || "-"
                                  : dpt.testdetails[0]?.Sample_Specimen ||
                                  "-"}
                              </span>
                            </div>
                          </td>
                        </tr>
                        <tr className="two_line_tr">
                          <td className="two_line_td">
                            <div className="div_box">
                              <label className="header_lable">
                                UHID
                              </label><p>:</p>
                              <span className="header_span">
                                {capturedatas.Patient_Id}
                              </span>
                            </div>
                          </td>
                          <td className="two_line_td_right">
                            <div className="div_box">
                              <label className="header_lable">
                                Collected Date/Time
                              </label><p>:</p>
                              <span className="header_span">
                                {(() => {
                                  const invoiceDetailsFromPackagegroup =
                                    dpt?.testdetails
                                      ?.flatMap((td) => td.Packagegroup || [])
                                      ?.find(
                                        (pg) => pg.invoicedetails
                                      )?.invoicedetails;
                                  const invoiceDetails =
                                    invoiceDetailsFromPackagegroup ||
                                    dpt?.invoicedetails;
                                  return (
                                    invoiceDetails?.AnalyseInvestigationResult ||
                                    "-"
                                  );
                                })()}
                              </span>
                            </div>
                          </td>
                        </tr>
                        <tr className="two_line_tr">
                          <td className="two_line_td">
                            <div className="div_box">
                              <label className="header_lable">
                                Ref.Dr
                              </label> <p>:</p>
                              <span className="header_span">
                                Dr.{" "}
                                {capturedatas.Refering_Doctor?.split(
                                  "/"
                                )?.[0] || ""}
                              </span>
                            </div>
                          </td>
                          <td className="two_line_td_right">
                            <div className="div_box">
                              <label className="header_lable">
                                Received Date/Time
                              </label><p>:</p>
                              <span className="header_span">
                                {dpt.department !== "SEROLOGY" &&
                                  dpt.department !== "MICROBIOLOGY"
                                  ? (() => {
                                    const invoiceDetailsFromPackagegroup =
                                      dpt?.testdetails
                                        ?.flatMap(
                                          (td) => td.Packagegroup || []
                                        )
                                        ?.find(
                                          (pg) => pg.invoicedetails
                                        )?.invoicedetails;
                                    const invoiceDetails =
                                      invoiceDetailsFromPackagegroup ||
                                      dpt?.invoicedetails;
                                    return (
                                      invoiceDetails?.AnalyseInvestigationSenior ||
                                      "-"
                                    );
                                  })()
                                  : " "}
                              </span>
                            </div>
                          </td>
                        </tr>
                        <tr className="two_line_tr">
                          <td className="two_line_td">
                            <div className="div_box">
                              <label className="header_lable">
                                Department
                              </label><p>:</p>
                              <span className="header_span">
                                {
                                  capturedatas.Refering_Doctor?.split(
                                    "/"
                                  )?.[1]
                                }
                              </span>
                            </div>
                          </td>
                          <td className="two_line_td_right">
                            <div className="div_box">
                              <label className="header_lable">
                                Reported Date/Time
                              </label><p>:</p>
                              <span className="header_span">
                                {(() => {
                                  const invoiceDetailsFromPackagegroup =
                                    dpt?.testdetails
                                      ?.flatMap((td) => td.Packagegroup || [])
                                      ?.find(
                                        (pg) => pg.invoicedetails
                                      )?.invoicedetails;
                                  const invoiceDetails =
                                    invoiceDetailsFromPackagegroup ||
                                    dpt?.invoicedetails;
                                  return (
                                    invoiceDetails?.Approve_Test_Pathologist ||
                                    "-"
                                  );
                                })()}
                              </span>
                            </div>
                          </td>
                        </tr>
                      </>
                    }
                  </div>

                  <tr>
                    <div className="department_row">
                      {`${provision ? "Provisional Report": "The Report"}  - ${dpt.testdetails?.[0]?.Packagegroup
                        ? dpt.testdetails[0].Packagegroup[0]
                          ?.testdetails[0]?.SubDepartment_Name || "-"
                        : dpt.testdetails[0]?.SubDepartment_Name || "-"
                        }`}
                    </div>
                  </tr>
                  {!isSemenAnalysisPackage && (
                    <tr>
                      <div className="test_header">
                        <th className="test_name">Test Name</th>
                        <th className="result">Result</th>
                        {!isSemenAnalysisPackage &&
                          dpt.department !== "SEROLOGY" && (
                            <th className="unit">Units</th>
                          )}
                        {dpt.department !== "SEROLOGY" && (
                          <th className="reference">Reference</th>
                        )}
                        <th className="method">Methods</th>
                      </div>
                    </tr>
                  )}


                  <img src={KMCHlogo} class="watermark" />

                  {emailsent && (
                    <div className="letter_footer">
                      <div className="footer_word">
                        <h3>
                          Emergency Care<span>:</span>04923225300
                        </h3>
                        <he>|</he>
                        <h3>
                          Mob No<span>:</span>09965150000
                        </h3>
                      </div>
                    </div>
                  )}
                </thead>
                <tbody className="main_body">

                  {packageData?.packageName &&
                    <div className="package_name">
                      <tr>
                        <td className="package_name_td">{packageData?.packageName}</td> - <td><i className="specimen_name_td">{dpt.testdetails?.[0]?.Packagegroup
                          ? dpt.testdetails[0].Packagegroup[0]
                            ?.testdetails[0]?.Sample_Specimen || "-"
                          : dpt.testdetails[0]?.Sample_Specimen ||
                          "-"}</i></td>
                      </tr>
                    </div>
                  }
                  {Object.entries(packageData.groups).map(
                    ([groupKey, tests], groupIndex) => {
                      const groupRows = [];

                      // Add group header if applicable
                      if (groupKey !== "no_group") {
                        if (groupKey === "Sperm Count") {
                          groupRows.push(
                            <tr
                              key={`microscopic_header_${packageKey}_${groupKey}`}
                            >
                              <td
                                colSpan={4}
                                style={{
                                  textAlign: "left",
                                  fontWeight: "bold",
                                  padding: "8px",
                                  backgroundColor: "#f5f5f5",
                                  borderBottom: "1px solid #ddd",
                                }}
                              >
                                Microscopic Examination
                              </td>
                            </tr>
                          );
                        }
                        groupRows.push(
                          <div className="package_name">
                            <tr key={`group_${packageKey}_${groupKey}`}>
                               <td className="package_name_td">{groupKey}</td>  {!packageData?.packageName && <td> - <i className="specimen_name_td">{dpt.testdetails?.[0]?.Packagegroup
                                ? dpt.testdetails[0].Packagegroup[0]
                                  ?.testdetails[0]?.Sample_Specimen || "-"
                                : dpt.testdetails[0]?.Sample_Specimen ||
                                "-"}</i></td>}

                            </tr>
                          </div>
                        );
                      }

                      // Add table header for each group in Semen Analysis
                      if (isSemenAnalysisPackage) {
                        groupRows.push(
                          // <tr
                          //   key={`header_${packageKey}_${groupKey}`}
                          //   style={{
                          //     borderBottom: "1px solid black",
                          //     backgroundColor: "#f5f5f5",
                          //   }}
                          // >
                          //   <th
                          //     style={{
                          //       padding: "8px",
                          //       textAlign: "left",
                          //       border: "1px solid black",
                          //     }}
                          //   >
                          //     Test Name
                          //   </th>
                          //   <th
                          //     style={{
                          //       padding: "8px",
                          //       textAlign: "center",
                          //       border: "1px solid black",
                          //     }}
                          //   >
                          //     Result
                          //   </th>
                          //   <th
                          //     style={{
                          //       padding: "8px",
                          //       textAlign: "center",
                          //       border: "1px solid black",
                          //     }}
                          //   >
                          //     Reference Range (WHO 6th Ed.)
                          //   </th>
                          // </tr>
                          <tr>
                            <div className="test_header">
                              <th className="test_name">Test Name</th>
                              <th className="test_name">Result</th>
                              <th className="range">Reference Range (WHO 6th Ed.)</th>
                            </div>
                          </tr>
                        );
                      }

                      // Sort tests within the group
                      const sortedTests = isOffer
                        ? tests.sort((a, b) =>
                          (a.Test_Name || "").localeCompare(b.Test_Name || "")
                        )
                        : tests;

                      // Render each test
                      sortedTests.forEach((test, testIndex) => {
                        const testKey = `${test.Test_Code}_${test.Billing_Invoice}`;
                        const isEditing = editMode;
                        const edited = editBioData[testKey] || {};
                        const merged = { ...test, ...edited };

                        if (isSemenAnalysisPackage) {
                          // Custom table-like structure for Semen Analysis
                          groupRows.push(
                            <div className="report_div">
                              <tr key={`${packageKey}_${groupKey}_${testIndex}`}>
                                <td className="test_name_td">
                                  <div className="test_name_div">
                                    {test.DisplayText ===
                                      "Progressive Motility(PR) (A-Rapidlyprogressive+ B- Slow progressive)" ? (
                                      <>
                                        <p
                                          style={{
                                            margin: "0 0 5px 0",
                                            fontWeight: "bold",
                                          }}
                                        >
                                          Progressive Motility(PR)
                                        </p>
                                        <p
                                          style={{
                                            margin: "0",
                                            fontSize: "12px",
                                          }}
                                        >
                                          (A-Rapidly progressive+ B- Slow
                                          progressive)
                                        </p>
                                      </>
                                    ) : (
                                      <p
                                        style={{
                                          margin: "0",
                                          fontWeight: "bold",
                                        }}
                                      >
                                        {test.DisplayText}
                                      </p>
                                    )}

                                    {test.Method_Name &&
                                      test.Group_Code !== "GM0019" && (
                                        <p
                                          style={{
                                            fontSize: "12px",
                                            margin: "5px 0 0 0",
                                            color: "#666",
                                            fontStyle: "italic",
                                          }}
                                        >
                                          Method: {test.Method_Name}
                                        </p>
                                      )}
                                  </div>
                                </td>
                                <td className="test_name_td">
                                  {isEditing ? (
                                    <input
                                      type="text"
                                      value={merged.Capture_Value}
                                      onChange={(e) =>
                                        handleBioChange(
                                          test.Test_Code,
                                          test.Billing_Invoice,
                                          "Capture_Value",
                                          e.target.value
                                        )
                                      }
                                      style={{
                                        width: "100%",
                                        padding: "4px",
                                        border: "1px solid #ccc",
                                        borderRadius: "3px",
                                      }}
                                    />
                                  ) : (
                                    test.Capture_Value || ""
                                  )}
                                </td>
                                <td className="test_name_td">
                                  {isEditing ? (
                                    <input
                                      type="text"
                                      value={merged.ReferenceRange}
                                      onChange={(e) =>
                                        handleBioChange(
                                          test.Test_Code,
                                          test.Billing_Invoice,
                                          "ReferenceRange",
                                          e.target.value
                                        )
                                      }
                                      style={{
                                        width: "100%",
                                        padding: "4px",
                                        border: "1px solid #ccc",
                                        borderRadius: "3px",
                                      }}
                                    />
                                  ) : (
                                    test.ReferenceRange || ""
                                  )}
                                </td>
                              </tr>
                            </div>
                          );
                        } else {
                          groupRows.push(
                            <>
                              <div className="report_div">
                                <tr
                                  key={`${packageKey}_${groupKey}_${testIndex}`}
                                >
                                  <div className="test_name_div"  >
                                    <td className="test_name_td">
                                      <p style={{ ...testBold(test.Test_Code) }}>
                                        {test.DisplayText ===
                                          "BLOOD GROUP &RH TYPING"
                                          ? "BLOOD GROUP &RH TYPING"
                                          : test.DisplayText}
                                      </p>
                                      {/* {test.Sample_Specimen} */}
                                    </td>
                                  </div>

                                  <td
                                    className="result_td"
                                    style={{
                                      ...getStatus(
                                        merged.Capture_Value,
                                        merged.ReferenceRange
                                      ).valueStyle,
                                    }}
                                  >
                                    {isEditing ? (
                                      <input
                                        type="text"
                                        value={merged.Capture_Value}
                                        onChange={(e) =>
                                          handleBioChange(
                                            test.Test_Code,
                                            test.Billing_Invoice,
                                            "Capture_Value",
                                            e.target.value
                                          )
                                        }
                                        style={{
                                          width: "100%",
                                          padding: "4px",
                                          border: "1px solid #ccc",
                                          borderRadius: "3px",
                                        }}
                                      />
                                    ) : (
                                      test.Capture_Value
                                    )}
                                  </td>

                                  {!isSemenAnalysisPackage && dpt.department !== "SEROLOGY" && (
                                    <td className="unit_td">
                                      {isEditing ? (
                                        <input
                                          type="text"
                                          value={merged.Unit_Name}
                                          onChange={(e) =>
                                            handleBioChange(
                                              test.Test_Code,
                                              test.Billing_Invoice,
                                              "UOM",
                                              e.target.value
                                            )
                                          }
                                          style={{
                                            width: "100%",
                                            padding: "4px",
                                            border: "1px solid #ccc",
                                            borderRadius: "3px",
                                          }}
                                        />
                                      ) : ["nil", "negative", "-"].includes(
                                        String(test.Capture_Value).toLowerCase()
                                      ) ? (
                                        ""
                                      ) : (
                                        test.Unit_Name
                                      )}
                                    </td>
                                  )}
                                  {dpt.department !== "SEROLOGY" &&
                                    <td className="reference_td">
                                      {isEditing ? (
                                        <input
                                          type="text"
                                          value={merged.ReferenceRange}
                                          onChange={(e) =>
                                            handleBioChange(
                                              test.Test_Code,
                                              test.Billing_Invoice,
                                              "ReferenceRange",
                                              e.target.value
                                            )
                                          }
                                          style={{
                                            width: "100%",
                                            padding: "4px",
                                            border: "1px solid #ccc",
                                            borderRadius: "3px",
                                          }}
                                        />
                                      ) : (
                                        test.ReferenceRange
                                      )}
                                    </td>
                                  }

                                  <td className="method_td">
                                    {test.Method_Name || ""}
                                  </td>
                                </tr>
                              </div>
                              {test.Test_Code === "LTC0495" && test.Group_Code === "LGM0029" &&
                                (
                                  <>
                                    <div className="package_name">
                                      <tr>
                                        <td className="package_name_td">DIFFERENTIAL LEUCOCYTIC COUNT (DLC)</td>
                                      </tr>
                                    </div>
                                  </>
                                )
                              }
                            </>
                          );
                        }

                        // Add interpretation row if testinterpreatation exists
                        if (test.testinterpreatation?.length > 0) {
                          test.testinterpreatation.forEach((item, index) => {
                            if (item.Header_interpretation || item.Comments) {
                              groupRows.push(
                                <tr
                                  key={`${packageKey}_${groupKey}_${testIndex}_interpretation_${index}`}
                                >
                                  <td
                                    colSpan={4}
                                    style={{
                                      textAlign: "start",
                                      padding: "13px",
                                    }}
                                  >
                                    <div
                                      style={{
                                        display: "flex",
                                        alignItems: "center",
                                        gap: "10px",
                                      }}
                                    >
                                      {item.Header_interpretation && (
                                        <label
                                          style={{
                                            fontWeight: "bold",
                                            fontSize: "14px",
                                          }}
                                        >
                                          {item.Header_interpretation}:
                                        </label>
                                      )}
                                      {item.Comments &&
                                        item.Comments !== "null" &&
                                        typeof item.Comments === "string" &&
                                        (() => {
                                          try {
                                            const decoded = atob(
                                              item.Comments
                                            ).trim();
                                            return decoded !== "" ? (
                                              <div
                                                style={{
                                                  fontSize: "13px",
                                                  lineHeight: "1.5",
                                                  flex: "1",
                                                }}
                                                dangerouslySetInnerHTML={{
                                                  __html: decoded,
                                                }}
                                              />
                                            ) : null;
                                          } catch (e) {
                                            console.warn(
                                              "Invalid base64:",
                                              item.Comments
                                            );
                                            return null;
                                          }
                                        })()}
                                    </div>
                                  </td>
                                </tr>
                              );
                            }
                          });
                        }

                        // Add guidelines row if guidelines_interpretation exists
                        if (test.guidelines_interpretation?.length > 0) {
                          test.guidelines_interpretation.forEach(
                            (item, index) => {
                              if (item.Header_interpretation || item.Comments) {
                                groupRows.push(
                                  <tr
                                    key={`${packageKey}_${groupKey}_${testIndex}_guidelines_${index}`}
                                  >
                                    <td
                                      colSpan={4}
                                      style={{
                                        textAlign: "start",
                                        padding: "13px",
                                      }}
                                    >
                                      <div style={{ marginBottom: "10px" }}>
                                        {item.Header_interpretation && (
                                          <h4
                                            style={{
                                              fontWeight: "bold",
                                              margin: "0 0 8px 0",
                                              textAlign: "center",
                                              fontSize: "16px",
                                            }}
                                          >
                                            {item.Header_interpretation}
                                          </h4>
                                        )}
                                        {item.Comments && (
                                          <ol
                                            style={{
                                              margin: "0 0 0 20px",
                                              padding: "0",
                                            }}
                                          >
                                            {item.Comments.split("\n").map(
                                              (point, i) => {
                                                const trimmedPoint = point
                                                  .replace(/^\d+\.\t/, "")
                                                  .trim();
                                                return trimmedPoint ? (
                                                  <li
                                                    key={i}
                                                    style={{
                                                      marginBottom: "4px",
                                                      lineHeight: "1.5",
                                                      fontSize: "14px",
                                                    }}
                                                  >
                                                    {trimmedPoint}
                                                  </li>
                                                ) : null;
                                              }
                                            )}
                                          </ol>
                                        )}
                                      </div>
                                    </td>
                                  </tr>
                                );
                              }
                            }
                          );
                        }
                      });

                      return groupRows;
                    }
                  )}
                  <tr>
                    <div className="report_end">- End of Report -</div>
                  </tr>
                </tbody>

                <tfoot className="main_footer">
                  <div className="main_foot_div">

                    <tr>
                      <td colSpan="3">
                        <div className="foot_inner">
                          <div className="foot_left">
                            {SignPerson.tech_sign ? (
                              <img
                                className="foot_sign"
                                src={SignPerson?.tech_sign}
                                alt=""
                              />
                            ) : (
                              <div style={{ height: "50px" }}></div>
                            )}

                            <div className="foot_checked">
                              Checked By:
                              {SignPerson.tech_name ? (
                                <span>{SignPerson.tech_name}</span>
                              ) : dpt.testdetails?.[0]?.Packagegroup ? (
                                dpt.testdetails[0].Packagegroup[0]
                                  ?.testdetails[0]?.
                                  labtechnician || "-"
                              ) : (
                                dpt.testdetails[0]?.labtechnician || "-"
                              )}
                            </div>
                          </div>

                          {(() => {
                            const labTech =
                              dpt.testdetails?.[0]?.Packagegroup?.[0]
                                ?.testdetails?.[0]?.labtechnician ??
                              dpt.testdetails?.[0]?.labtechnician ??
                              "";

                            const srTech =
                              dpt.testdetails?.[0]?.Packagegroup?.[0]
                                ?.testdetails?.[0]?.sr_tech ??
                              dpt.testdetails?.[0]?.sr_tech ??
                              "";

                            return labTech.toLowerCase() !==
                              srTech.toLowerCase() && srTech !== "" ? (
                              <div className="foot_mid">
                                {SignPerson.sr_tech_sign ? (
                                  <img
                                    className="foot_sign"
                                    src={SignPerson?.sr_tech_sign}
                                    alt=""
                                  />
                                ) : (
                                  <div style={{ height: "50px" }}></div>
                                )}
                                <div className="foot_verify">
                                  Verified By: {SignPerson.sr_tech_name ? SignPerson.sr_tech_name : srTech}
                                </div>
                              </div>
                            ) : null;
                          })()}

                          <div className="foot_right">
                            {SignPerson?.Name && SignPerson?.sign && (
                              <div>
                                <img
                                  className="foot_sign"
                                  src={SignPerson?.sign}
                                  alt=""
                                />
                                <p className="foot_doc">{`${SignPerson?.Name}, ${SignPerson?.Qualification}`}</p>
                                <p className="foot_doc">
                                  {SignPerson?.Designation}
                                </p>

                                {SignPerson.State_RegistrationNumber && (
                                  <p
                                    style={{
                                      display: "flex",
                                      justifyContent: "flex-start",
                                      fontSize: "15px",
                                      width: "250px",
                                      fontWeight: "400",
                                    }}
                                  >
                                    Reg. No:{" "}
                                    {SignPerson.State_RegistrationNumber}
                                  </p>
                                )}
                              </div>
                            )}
                          </div>
                        </div>
                      </td>
                    </tr>
                  </div>


                </tfoot>

              </table>
            );
          }
        )}

      </div>
    );
  }

  return null;
};

export default BiochemistryReport;
