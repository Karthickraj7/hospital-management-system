import React, { useEffect, useState } from "react";
import EditIcon from "@mui/icons-material/Edit";
import { createTheme, ThemeProvider } from "@mui/material/styles";
import { DataGrid } from "@mui/x-data-grid";
import axios from "axios";
import Button from "@mui/material/Button";
import { format } from "date-fns";
import { useNavigate } from "react-router-dom";
import { useSelector } from "react-redux";
import DeleteForeverIcon from "@mui/icons-material/DeleteForever";

const theme = createTheme({
  components: {
    MuiDataGrid: {
      styleOverrides: {
        columnHeader: {
          backgroundColor: "var(--ProjectColor)",
          textAlign: "Center",
        },
        root: {
          "& .MuiDataGrid-root .MuiDataGrid-columnHeader, .MuiDataGrid-columnHeaderTitleContainer":
            {
              textAlign: "center",
              display: "flex !important",
              justifyContent: "center !important",
            },
          "& .MuiDataGrid-window": {
            overflow: "hidden !important",
          },
        },
        cell: {
          borderTop: "0px !important",
          borderBottom: "1px solid  var(--ProjectColor) !important",
          display: "flex",
          justifyContent: "center",
        },
      },
    },
  },
});

const LabIndentIssueMaster = () => {
  const userRecord = useSelector((state) => state.userRecord?.UserData);
  const urllink=useSelector(state=>state.userRecord?.UrlLink);
  const IndentIssueListData = useSelector(
    (state) => state.userRecord?.IndentIssueListData
  );

  const navigate = useNavigate();

  const [datalist, setdatalist] = useState([]);

  const cu_date = format(new Date(), "yyyy-MM-dd");

  console.log("vathuruchu", datalist);

  const [isedit, setisedit] = useState(null);

  const [Selecteditemdata, setSelecteditemdata] = useState([]);
  const [AvailQuantity, setAvailQuantity] = useState(0);
  console.log(Selecteditemdata);
  const [OverallPurchaseRecieveFormData, setOverallPurchaseRecieveFormData] =
    useState({
      Indent_Issue_Invoice_NO: "",
      Indent_Issue_Date: cu_date,
      ProductCategory: "",
      IndentRaiseInvoice: "",
      Request_From: "",
      Request_Raise_Date: "",
      Request_To: "",
      Reason: "",
      CreatedBy: userRecord?.username,
      Location: "CentralStore",
      RecievedBy: "",
      Finel_NetAmount: "",
      Issue_From: "CentralStore",
      Issue_To: "",
    });

  const [PurchaseRecieveFormData, setPurchaseRecieveFormData] = useState({
    Item_Code: "",
    Item_Name: "",
    Generic_Name: "",
    Strength: "",
    UOM: "",
    Pack_type: "",
    Pack_Quantity: "",
    Order_Quantity: "",
    TotalQuantity: "",
    Issue_Quantity: "",
    Issue_TotalQuantity: "",
    HSNCode: "",
    BatchNo: "",
    ManufactureDate: "",
    ExpiryDate: "",
    MRP: "",
    Tax_Percentage: "",
    TotalAmount: "",
  });

  


  const [datalist1, setdatalist1] = useState([]);
  const [page, setPage] = useState(0);
  const [page1, setPage1] = useState(0);
  const pageSize = 10;
  const showdown = datalist.length;
  const showdown1 = datalist1.length;
  const totalPages = Math.ceil(datalist.length / 10);
  const totalPages1 = Math.ceil(datalist1.length / 10);

  



  useEffect(() => {

    if (IndentIssueListData && Object.keys(IndentIssueListData).length !== 0) {
     
        axios
          .get(
            `${urllink}LabInventory/get_Medical_Indent_Issue_InvoiceNo?producttype=${IndentIssueListData.Productype}`
          )
          .then((response) => {
            console.log("INV:", response.data.nextInvoiceNo);
            setOverallPurchaseRecieveFormData((prevData) => ({
              ...prevData,
              Indent_Issue_Invoice_NO: response.data.nextInvoiceNo,
              ProductCategory: IndentIssueListData.Productype,
              IndentRaiseInvoice: IndentIssueListData.IndentRaise_InvoiceNo,
              Request_From: IndentIssueListData.RequestFrom,
              Request_Raise_Date: IndentIssueListData.RequestDate,
              Request_To: IndentIssueListData.RequestTo,
              Issue_To: IndentIssueListData.RequestFrom,
            }));

            const A_data = IndentIssueListData.items;

            const b_data = A_data.filter((r)=>r.Status !== "Rejected").map((p, index) => {
              const { Approved_Quantity, Pack_Quantity, ...rest } = p;

              const TotalQuantity = Approved_Quantity * Pack_Quantity;

              return {
                id: index + 1,
                ...rest,
                ApprovedQuantity: Approved_Quantity,
                Pack_Quantity: Pack_Quantity,
                TotalQuantity: TotalQuantity,
              };
            });

            console.log("A_data", b_data);

            setdatalist(b_data);
          })
          .catch((error) => {
            console.error("Error fetching data:", error);
          });
    
    }
  }, [IndentIssueListData]);



  useEffect(() => {


    if (PurchaseRecieveFormData.Item_Code !=='' && OverallPurchaseRecieveFormData.Issue_From !=='' &&
        OverallPurchaseRecieveFormData.ProductCategory !== '') {
      if (
        OverallPurchaseRecieveFormData.ProductCategory ==="Medical") {
        axios
          .get(
            `${urllink}LabInventory/get_medical_stock_information?Location=${OverallPurchaseRecieveFormData.Issue_From}&Item_Code=${PurchaseRecieveFormData.Item_Code}&producttype=${OverallPurchaseRecieveFormData.ProductCategory}`
          )
          .then((response) => {
            console.log("wrt:", response.data);
            let data =response.data
            
            let ArrayCheck = data.every((ele)=> +ele.AvailableQuantity <= 0  )
            
            if(data.length === 0  || ArrayCheck === true){

              alert('Stock Not Available In Store')
              handleClear()             
            }
            else{
              setSelecteditemdata(response.data);
            }
          })
          .catch((error) => {
            // Handle errors here
            console.error("Error fetching data:", error);
          });
      }

      if (OverallPurchaseRecieveFormData.ProductCategory === "NonMedical" || OverallPurchaseRecieveFormData.ProductCategory === "Stationary") {
        axios
          .get(
            `${urllink}LabInventory/get_Nonmedical_stock_information?Location=${OverallPurchaseRecieveFormData.Issue_From}&Item_Code=${PurchaseRecieveFormData.Item_Code}&Productype=${OverallPurchaseRecieveFormData.ProductCategory}`
          )
          .then((response) => {
            console.log("wrtwwwwww:", response.data);
            let data =response.data
            
            let ArrayCheck = data.every((ele)=> +ele.AvailableQuantity <= 0  )
            
            if(data.length === 0  || ArrayCheck === true){

              alert('Stock Not Available In Store')
              handleClear()             
            }
            else{
              setSelecteditemdata(response.data);
            }

            
          })
          .catch((error) => {
            console.error("Error fetching data:", error);
          });
      }
    }
  }, [
    PurchaseRecieveFormData.Item_Code,
    OverallPurchaseRecieveFormData.ProductCategory,
    OverallPurchaseRecieveFormData.Issue_From,
  ]);

  useEffect(() => {
    if (datalist1.length !== 0) {

      let G_Total = 0;

      datalist1.map((ele, ind) => {
        return (G_Total += +ele.TotalAmount);
      });

      console.log("G_Total:", G_Total);

      setOverallPurchaseRecieveFormData((prev) => ({
        ...prev,
        Finel_NetAmount: G_Total,
      }));
    }
  }, [datalist1]);

  useEffect(()=>{

    if(datalist.length !==0 && datalist1.length ===0 ){

      let ArrayCheck = datalist.every((ele)=>ele.Status === 'Rejected')

      // console.log('ConditinArray',ArrayCheck)
      if(ArrayCheck === true){
        navigate("/Home/LabIndentIssueList");
      }

    }

  },[datalist,datalist1])

  
  const dynamicColumns = () => {
    if (
      OverallPurchaseRecieveFormData.ProductCategory === "Medical" ) {
      return [
        { field: "Item_Code", headerName: "Item Code", width: 200 },
        { field: "Item_Name", headerName: "Item Name", width: 200 },
        { field: "Generic_Name", headerName: "Generic Name", width: 150 },
        { field: "Strength", headerName: "Strength", width: 120 },
        { field: "UOM", headerName: "UOM", width: 120 },
        { field: "Pack_type", headerName: "Pack Type", width: 150 },
        { field: "Pack_Quantity", headerName: "Pack Quantity", width: 140 },
        { field: "ApprovedQuantity", headerName: "Order Quantity", width: 140 },
        { field: "TotalQuantity", headerName: "Total Quantity", width: 140 },
        {
          field: "actions",
          headerName: "Actions",
          width: 120,
          renderCell: (params) => {
            console.log('0000',params.row.Status);
            
            return params.row.Status === "Rejected" ? (
              "Action Completed"
            ):(
              <>
                <Button
                  className="cell_btn"
                  onClick={() => handleRequestEdit(params.row)}
                >
                  <EditIcon />
                </Button>
        
                <Button
                  className="cell_btn"
                  onClick={() => handleRejectedEdit(params)}
                  title="Reject"
                >
                  <DeleteForeverIcon />
                </Button>
              </>
            ) 
          },
        },
      ];
    }else {
      return [
        { field: "Item_Code", headerName: "Item Code", width: 200 },
        { field: "Item_Name", headerName: "Item Name", width: 200 },
        { field: "Pack_type", headerName: "Pack Type", width: 170 },
        { field: "Pack_Quantity", headerName: "Pack Quantity", width: 170 },
        { field: "ApprovedQuantity", headerName: "Order_Quantity", width: 170 },
        { field: "TotalQuantity", headerName: "Total Quantity", width: 140 },
        {
          field: "actions",
          headerName: "Actions",
          width: 120,
          renderCell: (params) => {
            console.log('0000',params.row.Status);
            
            return params.row.Status === "Rejected" ? (
              "Action Completed"
            ):(
              <>
                <Button
                  className="cell_btn"
                  onClick={() => handleRequestEdit(params.row)}
                >
                  <EditIcon />
                </Button>
        
                <Button
                  className="cell_btn"
                  onClick={() => handleRejectedEdit(params)}
                  title="Reject"
                >
                  <DeleteForeverIcon />
                </Button>
              </>
            ) 
          },
        },
      ];
    }
  };

  const dynamicColumns1 = () => {
    if (OverallPurchaseRecieveFormData.ProductCategory === "Medical" ) {
      return [
        { field: "Item_Code", headerName: "Item Code", width: 200 },
        { field: "Item_Name", headerName: "Item Name", width: 200 },
        { field: "Generic_Name", headerName: "Generic Name", width: 150 },
        { field: "Strength", headerName: "Strength", width: 120 },
        { field: "UOM", headerName: "UOM", width: 100 },
        {
          field: "ManufactureDate",
          headerName: "Manufacture Date",
          width: 170,
        },
        { field: "ExpiryDate", headerName: "Expiry Date", width: 150 },
        { field: "HSNCode", headerName: "HSN Code", width: 170 },
        { field: "BatchNo", headerName: "Batch No", width: 170 },
        { field: "Pack_type", headerName: "Pack Type", width: 150 },
        { field: "Order_Quantity", headerName: "Order Quantity", width: 150 },
        { field: "Issue_Quantity", headerName: "Issued Quantity", width: 170 },
        { field: "MRP", headerName: "MRP", width: 150 },
        { field: "Tax_Percentage", headerName: "Tax Percentage", width: 170 },
        { field: "TotalAmount", headerName: "Total Amount", width: 170 },
        {
          field: "actions",
          headerName: "Actions",
          width: 120,
          renderCell: (params) => (
            <>
              <Button
                className="cell_btn"
                onClick={() => handleRequestEdit1(params.row)}
              >
                <EditIcon />
              </Button>
            </>
          ),
        },
      ];
    } 
     else {
      return [
        { field: "Item_Code", headerName: "Item Code", width: 200 },
        { field: "Item_Name", headerName: "Item Name", width: 200 },
        { field: "Pack_type", headerName: "Pack Type", width: 170 },
        { field: "Order_Quantity", headerName: "Order Quantity", width: 170 },
        {
          field: "Issue_Quantity",
          headerName: "Issue Quantity",
          width: 170,
        },
        { field: "MRP", headerName: "MRP", width: 170 },
        { field: "Tax_Percentage", headerName: "Tax Percentage", width: 170 },
        { field: "TotalAmount", headerName: "Total Amount", width: 170 },
        {
          field: "actions",
          headerName: "Actions",
          width: 120,
          renderCell: (params) => (
            <>
              <Button
                className="cell_btn"
                onClick={() => handleRequestEdit1(params.row)}
              >
                <EditIcon />
              </Button>
            </>
          ),
        },
      ];
    }
  };

  const handlePageChange = (params) => {
    setPage(params.page);
  };
  const handlePageChange1 = (params) => {
    setPage1(params.page);
  };

 

  const handleInputFormChange = (e) => {
    const { name, value } = e.target;

     

    if (name === "BatchNo") {
      let S_data = Selecteditemdata.find((ele) => {
        return ele.Batch_No === value;
      });
      if (S_data) {

        setAvailQuantity(S_data.AvailableQuantity)

        if(OverallPurchaseRecieveFormData.ProductCategory ==='Medical'){
        setPurchaseRecieveFormData((prev) => ({
          ...prev,
          [name]: value,
          HSNCode: S_data.HSN_Code,
          ManufactureDate: S_data.ManufactureDate,
          ExpiryDate: S_data.ExpiryDate,
          MRP: S_data.MRP_Per_Quantity,
          Tax_Percentage: S_data.Tax_Percentage,
        }));
      }
      } else {
        setAvailQuantity(0)
        setPurchaseRecieveFormData((prev) => ({
          ...prev,
          [name]: value,
          HSNCode: "",
          ManufactureDate: "",
          ExpiryDate: "",
          MRP: "",
          Tax_Percentage: "",
          Issue_Quantity:'',
          Issue_TotalQuantity:"",
        }));
      }
    } else if (name === "Issue_Quantity") {
      
      if(OverallPurchaseRecieveFormData.ProductCategory ==='Medical'){

      let S_data = Selecteditemdata.find((ele) => {
        return ele.Batch_No === PurchaseRecieveFormData.BatchNo;
      })
      if (S_data.Pack_Quantity*value  <= +AvailQuantity) {
       
        setPurchaseRecieveFormData((prev) => ({
          ...prev,
          [name]: value,
          MRP: S_data.MRP_Per_Quantity,
          Issue_TotalQuantity:S_data.Pack_Quantity*value,
          Tax_Percentage:S_data.Tax_Percentage,
        }));
      } else {
        alert(`Available Quantity is less the the entered Quantity ,enter belew the ${AvailQuantity}`);
      }

    }else{

      let S_data = Selecteditemdata.find((ele) => {
        return ele.Item_Code === PurchaseRecieveFormData.Item_Code;
      })
          
      console.log('ans',Selecteditemdata,AvailQuantity);

      if (S_data.Pack_Quantity*value  <= +S_data.AvailableQuantity) {
       
        setPurchaseRecieveFormData((prev) => ({
          ...prev,
          [name]: value,
          MRP: S_data.MRP_Per_Quantity,
          Issue_TotalQuantity:S_data.Pack_Quantity*value,
          Tax_Percentage:S_data.Tax_Percentage,
        }));
      } else {
        alert(`Available Quantity is less the the entered Quantity ,enter belew the ${S_data.AvailableQuantity}`);
      }

    }



    } else {
      setPurchaseRecieveFormData((prev) => ({
        ...prev,
        [name]: value,
      }));
    }
  };

  useEffect(() => {
    const T_Amount =
      PurchaseRecieveFormData.MRP *
      PurchaseRecieveFormData.Issue_TotalQuantity;

    setPurchaseRecieveFormData((prev) => ({
      ...prev,
      TotalAmount: T_Amount.toFixed(2),
    }));
  }, [
    PurchaseRecieveFormData.Issue_TotalQuantity,
    PurchaseRecieveFormData.MRP,
  ]);



  const handleRequestEdit = (params) => {
    if(OverallPurchaseRecieveFormData.Issue_From !==''){
      setPurchaseRecieveFormData({
        Item_Code: params.Item_Code,
        Item_Name: params.Item_Name,
        Generic_Name: params.Generic_Name,
        Strength: params.Strength,
        UOM: params.UOM,
        Pack_type: params.Pack_type,
        Pack_Quantity: params.Pack_Quantity,
        Order_Quantity: params.ApprovedQuantity,
        TotalQuantity: params.TotalQuantity,
        Issue_Quantity: "",
        Issue_TotalQuantity: "",
        HSNCode: "",
        BatchNo: "",
        ManufactureDate: "",
        ExpiryDate: "",
        MRP: "",
        Tax_Percentage: "",
        TotalAmount: "",
      });
    }else{
      alert('Select The Issue From')
    }
  };


  const handleRejectedEdit = (params) => {
    

    const index = params.row;
    console.log("index:", index);
    
    let Deletedata={
      IndentRaiseInvoice:OverallPurchaseRecieveFormData.IndentRaiseInvoice,
      S_No:index.S_No,
      Item_Code:index.Item_Code,
      ProductCategory:OverallPurchaseRecieveFormData.ProductCategory,
      CreatedBy: userRecord?.username,
    }


    const resultReject = window.confirm(
      "Are you sure ,you want to reject it ?"
    );

    if (resultReject) {
      axios
        .post(
          `${urllink}LabInventory/Update_indent_issue_Single_Rejection`,
          Deletedata
        )
        .then((response) => {
          console.log(response.data);

          let updatedDatalist = datalist.map((ele) => {
            if (ele.Item_Code === index.Item_Code) {
                ele.Status = 'Rejected';  // Ensure 'Rejected' is a string if it should be
            }
            return ele;
        });
        setdatalist(updatedDatalist);
        dynamicColumns()

        })
        .catch((error) => {
          console.log(error);
        });
    }

  };

  const handleRequestEdit1 = (params) => {
    setPurchaseRecieveFormData({ ...params });
    setisedit(params);
  };

  
  const handleAdd = () => {
    let requiredFields;

    if (
      OverallPurchaseRecieveFormData.ProductCategory === "Medical" 
    ) {
      requiredFields = [
        "Item_Code",
        "Item_Name",
        "Generic_Name",
        "Strength",
        "UOM",
        "Pack_type",
        "Order_Quantity",
        "TotalQuantity",
        "Issue_Quantity",
        "Issue_TotalQuantity",
        "HSNCode",
        "BatchNo",
        "ManufactureDate",
        "ExpiryDate",
        "MRP",
        "Tax_Percentage",
        "TotalAmount",
      ];
    }  
    else{
      requiredFields = [
        "Item_Code",
        "Item_Name",
        "Pack_type",
        "Order_Quantity",
        "TotalQuantity",
        "Issue_Quantity",
        "Issue_TotalQuantity",
        "MRP",
        "Tax_Percentage",
        "TotalAmount",
      ];
    }

    const missingFields = requiredFields.filter(
      (field) => !PurchaseRecieveFormData[field]
    );

    if (missingFields.length === 0) {
      console.log("PurchaseRecieveFormData", PurchaseRecieveFormData);
      let id = 0;
      const data = { id: datalist1.length + 1, ...PurchaseRecieveFormData };

      console.log("dataArray", data);
      setdatalist1((prev) => [...prev, data]);
      setdatalist((prev) =>
        prev.filter(
          (item) => item.Item_Code !== PurchaseRecieveFormData.Item_Code
        )
      );
      handleClear();
    } else {
      alert(`Please fill out all required fields: ${missingFields.join(", ")}`);
    }
  };

  const handleUpdate = () => {
    let requiredFields;
    if (
      OverallPurchaseRecieveFormData.ProductCategory === "Medical" 
    ) {
      requiredFields = [
        "Item_Code",
        "Item_Name",
        "Generic_Name",
        "Strength",
        "UOM",
        "Pack_type",
        "Order_Quantity",
        "TotalQuantity",
        "Issue_Quantity",
        "Issue_TotalQuantity",
        "HSNCode",
        "BatchNo",
        "ManufactureDate",
        "ExpiryDate",
        "MRP",
        "Tax_Percentage",
        "TotalAmount",
      ];
    }  
    else{
      requiredFields = [
        "Item_Code",
        "Item_Name",
        "Pack_type",
        "Order_Quantity",
        "TotalQuantity",
        "Issue_Quantity",
        "Issue_TotalQuantity",
        "MRP",
        "Tax_Percentage",
        "TotalAmount",
      ];
    }

    const missingFields = requiredFields.filter(
      (field) => !PurchaseRecieveFormData[field]
    );

    if (missingFields.length === 0) {
      const indexOfItemToUpdate = datalist1.findIndex(
        (item) => item.Item_Code === isedit.Item_Code
      );
      setdatalist1((prev) => {
        const updatedCart = [...prev];
        updatedCart[indexOfItemToUpdate] = PurchaseRecieveFormData;
        return updatedCart;
      });
      setisedit(null);
      handleClear();
    } else {
      alert(`Please fill out all required fields: ${missingFields.join(", ")}`);
    }
  };


 

  const handleClear = () => {
      setPurchaseRecieveFormData({
        Item_Code: "",
        Item_Name: "",
        Generic_Name: "",
        Strength: "",
        UOM: "",
        Pack_type: "",
        Pack_Quantity: "",
        Order_Quantity: "",
        TotalQuantity: "",
        Issue_Quantity: "",
        Issue_TotalQuantity: "",
        HSNCode: "",
        BatchNo: "",
        ManufactureDate: "",
        ExpiryDate: "",
        MRP: "",
        Tax_Percentage: "",
        TotalAmount: "",
      });
    
  };

 
  

  // const handleExportToExcel = () => {
  //     if(datalist1.length !==0){
  //         let columns;
  //         if(OverallPurchaseRecieveFormData.ProductCategory === 'Medical'){
  //            columns = [
  //                 { header: 'Item Code', dataKey: 'Item_Code' },
  //                 { header: 'Item Name', dataKey: 'Item_Name' },
  //                 { header: 'Generic_Name', dataKey: 'Generic_Name' },
  //                 { header: 'Strength', dataKey: 'Strength' },
  //                 { header: 'UOM', dataKey: 'UOM' },
  //                 { header: 'ManufactureDate', dataKey: 'ManufactureDate' },
  //                 { header: 'ExpiryDate', dataKey: 'ExpiryDate' },
  //                 { header: 'HSNCode', dataKey: 'HSNCode' },
  //                 { header: 'BatchNo', dataKey: 'BatchNo' },
  //                 { header: 'Pack_type', dataKey: 'Pack' },
  //                 { header: 'Order_Quantity', dataKey: 'Order_Quantity' },
  //                 { header: 'PerOrder_Quantity', dataKey: 'PerOrder_Quantity' },
  //                 { header: 'RecievedPack', dataKey: 'RecievedPack' },
  //                 { header: 'Issue_Quantity', dataKey: 'Issue_Quantity' },
  //                 { header: 'RecievedPerOrder_Quantity', dataKey: 'RecievedPerOrder_Quantity' },
  //                 { header: 'PendingQuantity', dataKey: 'PendingQuantity' },
  //                 { header: 'Reason', dataKey: 'Reason' },
  //                 { header: 'MRP', dataKey: 'MRP' },
  //                 { header: 'GST', dataKey: 'GST' },
  //                 { header: 'IGST', dataKey: 'IGST' },
  //                 { header: 'DiscountType', dataKey: 'DiscountType' },
  //                 { header: 'Discount', dataKey: 'Discount' },
  //                 { header: 'TotalAmount', dataKey: 'TotalAmount' },
  //               ];
  //         }else{
  //             columns = [
  //                 { header: 'Item Code', dataKey: 'Item_Code' },
  //                 { header: 'Item Name', dataKey: 'Item_Name' },
  //                 { header: 'Pack_type', dataKey: 'Pack' },
  //                 { header: 'Order_Quantity', dataKey: 'Order_Quantity' },
  //                 { header: 'PerOrder_Quantity', dataKey: 'PerOrder_Quantity' },
  //                 { header: 'RecievedPack', dataKey: 'RecievedPack' },
  //                 { header: 'Issue_Quantity', dataKey: 'Issue_Quantity' },
  //                 { header: 'RecievedPerOrder_Quantity', dataKey: 'RecievedPerOrder_Quantity' },
  //                 { header: 'PendingQuantity', dataKey: 'PendingQuantity' },
  //                 { header: 'Reason', dataKey: 'Reason' },
  //                 { header: 'MRP', dataKey: 'MRP' },
  //                 { header: 'GST', dataKey: 'GST' },
  //                 { header: 'IGST', dataKey: 'IGST' },
  //                 { header: 'DiscountType', dataKey: 'DiscountType' },
  //                 { header: 'Discount', dataKey: 'Discount' },
  //                 { header: 'TotalAmount', dataKey: 'TotalAmount' },
  //               ];
  //         }

  //         const header = columns.map(col => col.header);

  //         const csv = [
  //             `ProductCategory : ${OverallPurchaseRecieveFormData.ProductCategory}`,
  //             `IndentRaiseInvoice : ${OverallPurchaseRecieveFormData.IndentRaiseInvoice}`,
  //             `PurchaseRaiseDate : ${OverallPurchaseRecieveFormData.Purchaserise_date}`,
  //             `Raised By : ${OverallPurchaseRecieveFormData.CreatedBy}`,
  //             `SupplierCode : ${OverallPurchaseRecieveFormData.SupplierCode}`,
  //             `Request_From : ${OverallPurchaseRecieveFormData.Request_From}`,
  //             `GRN Invoice : ${OverallPurchaseRecieveFormData.PurchaseRecieveInvoice}`,
  //             `GRN Date : ${OverallPurchaseRecieveFormData.Purchaserecieve_date}`,
  //             `GRN Recieved By : ${OverallPurchaseRecieveFormData.RecievedBy}`,
  //             " ",
  //             '\ufeff' + header.join(","), // BOM + header row
  //             ...datalist1.map(row => columns.map(col => row[col.dataKey])),
  //             '', // Empty row for spacing
  //         ].join("\r\n");

  //         var data = new Blob([csv], { type: "text/csv" });
  //         // Fix the template literal for saveAs function
  //         saveAs(data, `Report_${new Date().toISOString()}.csv`);
  //     }else{
  //         alert('No Data to Save')
  //     }
  // };

  
  
  const handleSubmit = () => {
    const requiredFields = ["Finel_NetAmount", "Issue_From", "Issue_To"];

    const missingFields = requiredFields.filter(
      (field) => !OverallPurchaseRecieveFormData[field]
    );

    if (missingFields.length === 0) {
      const newdataa = {
        OverallPurchaseRecieveFormData: { ...OverallPurchaseRecieveFormData },
        datalist1: [...datalist1],
      };

      if(OverallPurchaseRecieveFormData.ProductCategory === "Medical" ){
        axios
        .post(
          `${urllink}LabInventory/Medical_indent_issue_insert`,
          newdataa
        )
        .then((response) => {
          console.log(response.data);
          navigate("/Home/LabIndentIssueList");
        })
        .catch((error) => {
          console.error("Error posting data:", error);
        });
      }else{
        axios
        .post(
          `${urllink}LabInventory/NonMedical_indent_issue_insert`,
          newdataa
        )
        .then((response) => {
          console.log(response.data);
          navigate("/Home/LabIndentIssueList");
        })
        .catch((error) => {
          console.error("Error posting data:", error);
        });

      }

      console.log(newdataa);
    } else {
      alert(`Please fill out all required fields: ${missingFields.join(", ")}`);
    }
  };


  return (
    <>
      <div className="appointment">
        <div className="h_head">
          <h3>Indent Issue L</h3>
        </div>
        <br/>


          <div className="RegisFormcon">
        
              <div className="RegisForm_1">
              <label>
                  Indent Issue Invoice No :
                </label>
                <input
                  type="text"
                  name="Indent_Issue_Invoice_NO"
                  value={OverallPurchaseRecieveFormData.Indent_Issue_Invoice_NO}
                  readOnly
                />
              </div>


                <div className="RegisForm_1">
                  <label>
                  Indent Issue Date :
                </label>
                <input
                  type="date"
                  name="Indent_Issue_Date"
                  value={OverallPurchaseRecieveFormData.Indent_Issue_Date}
                  readOnly
                />
              </div>

              <div className="RegisForm_1">
                <label>
                  Product Category :
                </label>
                <input
                  type="text"
                  name="ProductCategory"
                  value={OverallPurchaseRecieveFormData.ProductCategory}
                  readOnly
                />
              </div>

              <div className="RegisForm_1">
                <label>
                  Raise Invoice No :
                </label>
                <input
                  type="text"
                  name="IndentRaiseInvoice"
                  value={OverallPurchaseRecieveFormData.IndentRaiseInvoice}
                  readOnly
                />
              </div>

              <div className="RegisForm_1">
                <label>
                  Request From :
                </label>
                <input
                  type="text"
                  name="Request_From"
                  value={OverallPurchaseRecieveFormData.Request_From}
                  readOnly
                />
              </div>

              <div className="RegisForm_1">
                <label>
                  Request Raise Date :
                </label>
                <input
                  type="date"
                  name="Request_Raise_Date"
                  value={OverallPurchaseRecieveFormData.Request_Raise_Date}
                  readOnly
                />
              </div>

              <div className="RegisForm_1">
                <label>
                  Request To :
                </label>
                <input
                  type="text"
                  name="Request_To"
                  value={OverallPurchaseRecieveFormData.Request_To}
                  autoComplete="off"
                  readOnly
                />
              </div>

              <div className="RegisForm_1">
                <label>
                  Net Amount :
                </label>
                <input
                  type="number"
                  name="Finel_NetAmount"
                  value={OverallPurchaseRecieveFormData.Finel_NetAmount}
                  readOnly
                  required
                  className="Stoct_Product_master_form_Input"
                />
              </div>

              <div className="RegisForm_1">
                <label>
                  Issue From :
                </label>
                <input
                  type="text"
                  name="Issue_From"
                  value={OverallPurchaseRecieveFormData.Issue_From} 
                  readOnly
                />
              </div>

              <div className="RegisForm_1">
                <label>
                  Issue To :
                </label>
                <input
                  type="text"
                  name="Issue_To"
                  value={OverallPurchaseRecieveFormData.Issue_To}
                  readOnly
                />
              </div>

          </div>

          <br/>
          <br/>
          
          
      

       {datalist.length!==0 && <div className="IP_grid">
          <ThemeProvider theme={theme}>
            <div className="IP_grid_1">
              <DataGrid
                rows={datalist.slice(page * pageSize, (page + 1) * pageSize)} // Display only the current page's data
                columns={dynamicColumns()} // Use dynamic columns here
                pageSize={10}
                initialState={{
                  pagination: {
                    paginationModel: {
                      pageSize: 10,
                    },
                  },
                }}
                pageSizeOptions={[10]}
                onPageChange={handlePageChange}
                hideFooterPagination
                hideFooterSelectedRowCount
                className=" Ip_data_grid"
              />
              {showdown > 0 && datalist.length > 10 && (
                <div className="IP_grid_foot">
                  <button
                    onClick={() =>
                      setPage((prevPage) => Math.max(prevPage - 1, 0))
                    }
                    disabled={page === 0}
                  >
                    Previous
                  </button>
                  Page {page + 1} of {totalPages}
                  <button
                    onClick={() =>
                      setPage((prevPage) =>
                        Math.min(prevPage + 1, totalPages - 1)
                      )
                    }
                    disabled={page === totalPages - 1}
                  >
                    Next
                  </button>
                </div>
              )}
            </div>
          </ThemeProvider>
          {showdown !== 0 && datalist.length !== 0 ? (
            ""
          ) : (
            <div className="IP_norecords">
              <span>No Records Found</span>
            </div>
          )}
        </div> }

        <br/>
        <br/>

        <div className="RegisFormcon">
       
        <div className="RegisForm_1">
        <label>
              Item Code :
            </label>
            <input
              type="text"
              name="Item_Code"
              value={PurchaseRecieveFormData.Item_Code}
              required
              readOnly
            />
          </div>  

          <div className="RegisForm_1">
           <label>
              Item Name :
            </label>
            <input
              type="text"
              name="Item_Name"
              value={PurchaseRecieveFormData.Item_Name}
              required
              readOnly
            />
          </div>


         {OverallPurchaseRecieveFormData.ProductCategory === "Medical"  &&
            <>
            <div className="RegisForm_1">
              <label>
                  Generic Name :
                </label>
                <input
                  type="text"
                  name="Generic_Name"
                  value={PurchaseRecieveFormData.Generic_Name}
                  readOnly
                />
            </div>


            <div className="RegisForm_1">
                <label>
                Strength :
              </label>
              <input
                type="text"
                name="Strength"
                value={PurchaseRecieveFormData.Strength}
                readOnly
              />
            </div>


            <div className="RegisForm_1">
                <label>
                UOM :
              </label>
              <input
                type="text"
                name="UOM"
                value={PurchaseRecieveFormData.UOM}
                required
                readOnly
              />
            </div>
            </>
          }  
                <div className="RegisForm_1">
                   <label>
                    Pack Type :
                  </label>
                  <input
                    type="text"
                    name="Pack_type"
                    value={PurchaseRecieveFormData.Pack_type}
                    required
                    readOnly
                  />
                </div>

                <div className="RegisForm_1">
                   <label>
                    Pack Quantity :
                  </label>
                  <input
                    type="number"
                    name="Pack_Quantity"
                    value={PurchaseRecieveFormData.Pack_Quantity}
                    readOnly
                  />
                </div>

                <div className="RegisForm_1">
                   <label>
                    Order Quantity :
                  </label>
                  <input
                    type="number"
                    name="Order_Quantity"
                    value={PurchaseRecieveFormData.Order_Quantity}
                    readOnly
                  />
                </div>


                <div className="RegisForm_1">
                   <label>
                    Total Quantity :
                  </label>
                  <input
                    type="number"
                    name="TotalQuantity"
                    value={PurchaseRecieveFormData.TotalQuantity}
                    readOnly
                  />
                </div>
              {OverallPurchaseRecieveFormData.ProductCategory === "Medical"  &&
              <>
                <div className="RegisForm_1">
                   <label>
                    Batch No :
                  </label>
                  <input
                    id="browser"
                    list="browsers"
                    type="text"
                    name="BatchNo"
                    value={PurchaseRecieveFormData.BatchNo}
                    onChange={handleInputFormChange}
                    required
                    autoComplete="off"
                  />

                  <datalist id="browsers">
                    {Selecteditemdata.map((item, index) => (
                      <option key={index} value={`${item.Batch_No}`}>
                        {`${item.Item_Name} | BatchNo:${
                          item.Batch_No
                        } | Ava.Quantity:${
                          item.AvailableQuantity
                        } | MRP:${parseFloat(item.MRP_Per_Quantity).toFixed(
                          2
                        )}`}
                      </option>
                    ))}
                  </datalist>
                </div>

                <div className="RegisForm_1">
                   <label>
                    HSN Code :
                  </label>
                  <input
                    type="text"
                    name="HSNCode"
                    value={PurchaseRecieveFormData.HSNCode}
                    readOnly
                  />
                </div>

                <div className="RegisForm_1">
                   <label>
                    Manufacture Date :
                  </label>
                  <input
                    type="date"
                    name="ManufactureDate"
                    value={PurchaseRecieveFormData.ManufactureDate}
                    readOnly
                    required
                  />
                </div>


                <div className="RegisForm_1">
                   <label>
                    Expiry Date :
                  </label>
                  <input
                    type="date"
                    name="ExpiryDate"
                    value={PurchaseRecieveFormData.ExpiryDate}
                    readOnly
                  />
                </div>
                </>
                }

                <div className="RegisForm_1">
                   <label>
                    Issue Quantity :
                  </label>
                  <input
                    type="number"
                    name="Issue_Quantity"
                    list='Issue_Quantitylist'
                    value={PurchaseRecieveFormData.Issue_Quantity}
                    onChange={handleInputFormChange}
                  />

              {OverallPurchaseRecieveFormData.ProductCategory !== "Medical"&&
                  <datalist id="Issue_Quantitylist">
                    {Selecteditemdata.map((item, index) => (
                      <option key={index} >
                        {` Ava.Quantity:${
                          item.AvailableQuantity
                        }
                        `}
                      </option>
                    ))}
                  </datalist>}


                </div>

                <div className="RegisForm_1">
                   <label>
                    Total Quantity :
                  </label>
                  <input
                    type="number"
                    name="Issue_TotalQuantity"
                    value={PurchaseRecieveFormData.Issue_TotalQuantity}
                    readOnly
                  />
                </div>

                <div className="RegisForm_1">
                   <label>
                    MRP (Per Quantity) :
                  </label>
                  <input
                    type="number"
                    name="MRP"
                    value={PurchaseRecieveFormData.MRP}
                    readOnly
                    required
                  />
                </div>
                
                <div className="RegisForm_1">
                   <label>
                   Tax Percentage :
                  </label>
                  <input
                    type="number"
                    name="Tax_Percentage"
                    value={PurchaseRecieveFormData.Tax_Percentage}
                    readOnly
                    required
                  />
                </div>

                <div className="RegisForm_1">
                   <label>
                    Total Amount :
                  </label>
                  <input
                    type="number"
                    name="TotalAmount"
                    placeholder="Enter Total Amount"
                    value={PurchaseRecieveFormData.TotalAmount}
                    required
                    readOnly
                    className="Stoct_Product_master_form_Input"
                  />
                </div>




        </div>
          
          <br/>

        <div className="Stoct_Product_master_form_Save">
                <button
                  className=" Stoct_Product_master_form_Save_button"
                  onClick={isedit ? handleUpdate : handleAdd}
                >
                  {isedit ? "Update" : "Add"}
                </button>
              </div>

       

        {datalist1.length !== 0 && (
          <div className="IP_grid">
            <ThemeProvider theme={theme}>
              <div className="IP_grid_1">
                <DataGrid
                  rows={datalist1.slice(
                    page1 * pageSize,
                    (page1 + 1) * pageSize
                  )} // Display only the current page's data
                  columns={dynamicColumns1()} // Use dynamic columns here
                  pageSize={10}
                  initialState={{
                    pagination: {
                      paginationModel: {
                        pageSize: 10,
                      },
                    },
                  }}
                  pageSizeOptions={[10]}
                  onPageChange={handlePageChange1}
                  hideFooterPagination
                  hideFooterSelectedRowCount
                  className=" Ip_data_grid"
                />
                {showdown1 > 0 && datalist1.length > 10 && (
                  <div className="IP_grid_foot">
                    <button
                      onClick={() =>
                        setPage1((prevPage) => Math.max(prevPage - 1, 0))
                      }
                      disabled={page1 === 0}
                    >
                      Previous
                    </button>
                    Page {page1 + 1} of {totalPages1}
                    <button
                      onClick={() =>
                        setPage1((prevPage) =>
                          Math.min(prevPage + 1, totalPages - 1)
                        )
                      }
                      disabled={page1 === totalPages1 - 1}
                    >
                      Next
                    </button>
                  </div>
                )}
              </div>
            </ThemeProvider>
            {showdown1 !== 0 && datalist1.length !== 0 ? (
              ""
            ) : (
              <div className="IP_norecords">
                <span>No Records Found</span>
              </div>
            )}
          </div>
        )}
        {datalist1.length !== 0 && (
          <div className="Stoct_Product_master_form_Save">
            <button
              className=" Stoct_Product_master_form_Save_button"
              onClick={handleSubmit}
            >
              Submit
            </button>
          </div>
        )}

      </div>
    </>
  );
};

export default LabIndentIssueMaster;
