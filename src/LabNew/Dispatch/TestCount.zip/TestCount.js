import React, { useState, useEffect } from "react";
import { useSelector } from "react-redux";
import { createTheme, ThemeProvider } from "@mui/material/styles";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import ReactGrid from "../../OtherComponent/ReactGrid/ReactGrid";
import Tooltip from '@mui/material/Tooltip';
import ArrowBackIosNewIcon from '@mui/icons-material/ArrowBackIosNew';
import ArrowForwardIosIcon from '@mui/icons-material/ArrowForwardIos';
import { format } from "date-fns";


const TestCount = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const today = new Date().toISOString().slice(0, 10);
  const [searchQuery1, setSearchQuery1] = useState(today);
  const [searchQuery2, setSearchQuery2] = useState("date");
  const [searchQuery3, setSearchQuery3] = useState("");
  const [searchQuery4, setSearchQuery4] = useState("All");
  const [searchQuery5, setSearchQuery5] = useState('');
  const [searchQuery6, setSearchQuery6] = useState('');
  const [from, setFrom] = useState("")
  const [to, setTo] = useState("")
  const [input, setInput] = useState("date")

  const [summa, setsumma] = useState([]);
  const urllink = useSelector((state) => state.userRecord?.UrlLink);
  const navigate = useNavigate();
  const [page, setPage] = useState(0);
  const pageSize = 10;
  const userRecord = useSelector((state) => state.userRecord?.UserData);
  const [totalPages, setTotalPages] = useState(0);
  const [testCount, setTestCount] = useState(0);
  const [OpCount, setOpCount] = useState(0);
  const [IpCount, setIpCount] = useState(0);
  const [TestNameList, setTestNameList] = useState([]);
  const [subDep, setSetDep] = useState([]);


  const handleSearchChange = (e, key) => {
    const value = e.target.value;
    if (key === "name") setSearchQuery(value);
    if (key === "date") setSearchQuery1(value);

    if (key === "dateType") {
      setSearchQuery2(value);

      if (value.includes("month")) {
        setInput("month");
      } else {
        setInput("date");
      }

      const todays = new Date().toISOString().slice(0, 10);
      const today = new Date();
      const fullDate = today.toISOString().split("T")[0];
      const currentMonth = fullDate.slice(0, 7);

      if (value === "date") {
        setSearchQuery1(todays);
      } else if (value === "month") {
        setSearchQuery1(currentMonth);
      }
    }

    if (key === "testType") setSearchQuery3(value);
    if (key === "PatientType") setSearchQuery4(value);
    if (key === "from") setFrom(value);
    if (key === "to") setTo(value);
    if (key === "patient") setSearchQuery5(value);
    if (key === "dept") setSearchQuery6(value);
  };

  useEffect(() => {
    const offset = page * pageSize;

    const isSearchCleared =
      !searchQuery && !searchQuery1 && !searchQuery2 && !searchQuery3;
    console.log("Search Cleared:", isSearchCleared);

    console.log("Fetching default data...");
    axios
      .get(
        `${urllink}Lab/Get_Test_Count_Data?Location=${userRecord?.location}&limit=${pageSize}&offset=${offset}&testName=${searchQuery}&date=${searchQuery1}&dateType=${searchQuery2}&testType=${searchQuery3}&patient=${searchQuery4}&from=${from}&to=${to}&patientName=${searchQuery5}&dept=${searchQuery6}`
      )
      .then((response) => {
        //   console.log(response.data.test_data);
        const totalrecords = response.data.total_records;
        const Oprecords = response.data.OP_records;
        const Iprecords = response.data.IP_records;
        const data = response.data.test_data.map((row, index) => ({
          id: index + 1,
          ...row,
          status: "Status",
        }));
        data.sort((a, b) => {
          const invoiceA = parseInt(a.Billing_Invoice.replace(/\D/g, ""), 10);
          const invoiceB = parseInt(b.Billing_Invoice.replace(/\D/g, ""), 10);
          return invoiceB - invoiceA;
        });
        setTotalPages(0);
        setsumma(data);
        setTestCount(totalrecords);
        setOpCount(Oprecords);
        setIpCount(Iprecords);
        setTotalPages(Math.ceil(totalrecords / pageSize));
      })
      .catch((error) => {
        console.error("Error fetching data:", error);
      });
  }, [
    urllink,
    userRecord?.location,
    page,
    searchQuery,
    searchQuery1,
    searchQuery3,
    searchQuery4,
    searchQuery5,
    searchQuery6,
    from, to,
  ]);

  useEffect(() => {

    axios
      .get(`${urllink}Lab/test_and_group_forpackage`)
      .then((res) => {
        console.log(res);
        setTestNameList(res.data);
      })
      .catch((err) => {
        console.error(err);
      });

    axios
      .get(`${urllink}Masters/All_Other_Lab_Masters_POST_AND_GET?Type=LabSubDepartment`)
      .then((response) => {
        const data = response.data;
        console.log("data", data);
        setSetDep(data);
      })
      .catch((error) => {
        console.error("Error fetching SubDepartment data:", error);
      });
  }, [urllink])

  // const dynamicColumns = [
  //   { key: "id", headerName: "S No", width: 100 },
  //   { key: "Billing_Invoice", headerName: "Invoice", width: 100 },
  //   { key: "Test_Name", headerName: "Test Name", width: 250 },
  //   { key: "Test_Method", headerName: "Test Type", width: 250 },
  //   { key: "Service_Status", headerName: "Collection Status", width: 100 },
  //   { key: "Analysis_Status", headerName: "Report Entry Status", width: 100 },
  //   { key: "Verify_Status", headerName: "Verify Status", width: 100 },
  //   { key: "Approve_Status", headerName: "Approve Status", width: 100 },
  // ];


  const statusColors = {
    captureSample: '#FFD700', // Yellow for Service_Status (Pending)
    labTechnician: '#FFA500', // Orange for Analysis_Status (Pending)
    seniorTechnician: '#1E90FF', // Blue for Verify_Status (Pending)
    pathologist: '#800080', // Purple for Approve_Status (Pending)
    completed: '#008000', // Green for all completed
  };

  const getStatusColor = (row) => {
    if (row.Service_Status === "Pending") return statusColors.captureSample;
    if (row.Analysis_Status === "Pending") return statusColors.labTechnician;
    if (row.Verify_Status === "Pending") return statusColors.seniorTechnician;
    if (row.Approve_Status === "Pending") return statusColors.pathologist;
    return statusColors.completed;
  };


  const dynamicColumns = [
    { key: "id", headerName: "S No", frozen: true, width: 40 },
    {
      key: "CreatedAt", headerName: "Bill Date", width: 300,
      renderCell: (params) => format(new Date(params.row.CreatedAt), "dd-MM-yyyy")
    },
    { key: "Barcode_Id", headerName: "Sample ID", width: 100 },
    { key: "Patient_Id", headerName: "Patient ID", width: 100 },
    { key: "Patient_Name", headerName: "Patient Name", width: 300, renderCell: (params) => params.row.Patient_Name?.toString().toUpperCase() },
    { key: "SubDepartment_Name", headerName: "Department", width: 250 },
    { key: "Test_Name", headerName: "Test Name", width: 250 },
    {
      key: "Test_Method",
      headerName: "Test Type",
      width: 250,
      renderCell: (params) => params.row.Test_Method?.toString().toUpperCase()
    },
    // { key: "Service_Status", headerName: "Collection Status", width: 100 },
    // { key: "Analysis_Status", headerName: "Report Entry Status", width: 100 },
    // { key: "Verify_Status", headerName: "Verify Status", width: 100 },
    // { key: "Approve_Status", headerName: "Approve Status", width: 100 },
    // {
    //   key: 'status', // Ensure this matches the key in your data
    //   headerName: 'Status',
    //   width: 100,
    //   renderCell: (params) => {
    //     // Handle possibly undefined Service_Statuses
    //     const serviceStatuses = params.row.Service_Status || [];
    //     return (
    //       <Tooltip title={
    //         <>
    //           {console.log("-----Haii------", params)}
    //           {/* <div>Capture Status : {serviceStatuses[0].Capture}</div> */}
    //           <div>Analaysis Status : {params.row.Analysis_Status}</div>
    //           <div>Verified Status : {params.row.Verify_Status}</div>
    //           <div>Approve Status : {params.row.Approve_Status}</div>
    //         </>
    //       } arrow>
    //         <span>{params.row.status}</span>
    //       </Tooltip>
    //     );
    //   },
    // },
    {
      key: "Status",
      name: "Status",
      width: 100,
      renderCell: (params) => (
        <div
          style={{
            backgroundColor: getStatusColor(params.row),
            color: '#fff',
            textAlign: 'center',
            padding: '4px',
            borderRadius: '4px',
          }}
        >
          {params.row.Service_Status === "Pending" ? "Capture Sample" :
            params.row.Analysis_Status === "Pending" ? "Lab Technician" :
              params.row.Verify_Status === "Pending" ? "Senior Technician" :
                params.row.Approve_Status === "Pending" ? "Pathologist" : "Completed"}
        </div>
      ),
    },
  ];

  return (
    <div className="appointment">
      <div className="h_head">
        <h3>Lab Test Data</h3>
      </div>
      <div className="con_1 ">

        <div className="inp_1" style={{ gap: "5px", }}>
          {/* <label htmlFor="input">Date</label> */}
          <select
            name="dateType"
            value={searchQuery2}
            onChange={(e) => handleSearchChange(e, "dateType")}
            style={{ width: "120px", }}
          >
            <option value={"date"}>Date</option>
            <option value={"customdate"}>Custom Date</option>
            <option value={"month"}>Month</option>
            <option value={"custommonth"}>Custom Month</option>
          </select>
          {searchQuery2 === "date" || searchQuery2 === "month" ?
            (<input
              id="input"
              type={input}
              value={searchQuery1}
              onChange={(e) => handleSearchChange(e, 'date')}
              placeholder='Enter Invoice Number'
            />
            ) :
            (
              <div>
                <div style={{ display: "inline-block", }}>
                  <span style={{ display: "inline-block", width: "40px", color: "black", fontSize: "13px", fontWeight: "bold" }}>From </span>
                  <input
                    id="input"
                    type={input}
                    value={from}
                    onChange={(e) => handleSearchChange(e, 'from')}
                    placeholder='From Date'
                  />
                </div>
                <div style={{ display: "inline-block" }}>
                  <span style={{ display: "inline-block", width: "40px", color: "black", fontSize: "13px", fontWeight: "bold" }}> To </span>
                  <input
                    id="input"
                    type={input}
                    value={to}
                    onChange={(e) => handleSearchChange(e, 'to')}
                    placeholder='To Date'
                  />
                </div>
              </div>)}

        </div>

        <div className="inp_1">
          <label htmlFor="input">Department</label>
          <input
            value={searchQuery6}
            onChange={(e) => handleSearchChange(e, "dept")}
            placeholder="Enter Department"
            type="text"
            id="dept"
            name="dept"
            list="subdepList"
            className=""
            required
            autoComplete="Off"
          />
          <datalist id="subdepList">
            {Array.isArray(subDep) && subDep?.map((row, index) => (
              <option key={index} value={row.SubDepartment_Name} />
            ))}
          </datalist>
        </div>

        <div className="inp_1">
          <label htmlFor="input">Test Name</label>
          <input
            value={searchQuery}
            onChange={(e) => handleSearchChange(e, "name")}
            placeholder="Enter Test Name"
            type="text"
            id="testname"
            name="testname"
            list="testnamelist"
            className=""
            required
            autoComplete="Off"
          />
          <datalist id="testnamelist">
            {Array.isArray(TestNameList) && TestNameList?.map((item, index) => (
              <option key={index} value={item.name}>
                {item.Test_Code}
              </option>
            ))}
          </datalist>
        </div>


        <div className="inp_1">
          <label htmlFor="input">Test Method</label>
          <select
            value={searchQuery3}
            onChange={(e) => handleSearchChange(e, "testType")}
          >
            <option value={""}>All</option>
            <option value={"individual"}>Individual</option>
            <option value={"group"}>Group</option>
            <option value={"Offers"}>Offers</option>
          </select>
        </div>


        <div className="inp_1">
          <label htmlFor="input">Patient Type</label>
          <select
            value={searchQuery4}
            onChange={(e) => handleSearchChange(e, "PatientType")}
          >
            <option value={"All"}>All</option>
            <option value={"IP"}>IP</option>
            <option value={"OP"}>OP</option>
          </select>
        </div>


        <div className="inp_1">
          <label htmlFor="input">Patient Name</label>
          <input
            name="patient"
            type="text"
            value={searchQuery5}
            onChange={(e) => handleSearchChange(e, "patient")}
            placeholder='Enter Patient Name/Id'
          />
        </div>
      </div>
      <div className="h_head">
        <h3>Lab Test Counts</h3>
      </div>
      <div className="con_1 ">
        <div className="inp_1">
          <label htmlFor="input">Test Count :</label>
          <input
            type="text"
            value={testCount}
            onChange={(e) => handleSearchChange(e, "count")}
            readOnly
          />
        </div>
        {searchQuery4 === "All" && (
          <>
            <div className="inp_1">
              <label htmlFor="input">OP Test Count :</label>
              <input
                type="text"
                value={OpCount}
                onChange={(e) => handleSearchChange(e, "count")}
                readOnly
              />
            </div>
            <div className="inp_1">
              <label htmlFor="input">IP Test Count :</label>
              <input
                type="text"
                value={IpCount}
                onChange={(e) => handleSearchChange(e, "count")}
                readOnly
              />
            </div>
          </>
        )}
      </div>
      {/* <div className='grid_1'>
        <ReactGrid
          RowData={summa}
          columns={dynamicColumns}
          className="data_grid"
        />

        {summa.length === 0 && (
          <div className="IP_norecords">
            <span>No Records Found</span>
          </div>
        )}
      </div> */}

      <div className='grid_1'>
        <ReactGrid columns={dynamicColumns} RowData={summa}
          // hidePagination={true}
          className='data_grid'
        />
       
      </div>
    </div>
  );
};

export default TestCount;
