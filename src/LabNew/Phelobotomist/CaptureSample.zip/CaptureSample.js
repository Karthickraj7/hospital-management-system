import * as React from 'react';
import { useEffect, useState } from 'react';
import { DataGrid } from '@mui/x-data-grid';
// import { Helmet } from 'react-helmet';
// import SearchIcon from '@mui/icons-material/Search';
import axios from "axios";
// import './Neww.css';
import Button from '@mui/material/Button'; 
import ForwadIcon from "@mui/icons-material/Forward";
import { createTheme, ThemeProvider } from '@mui/material/styles';
import { useNavigate } from 'react-router-dom';
import { useDispatch } from 'react-redux';
// import  faForward  from '@fortawesome/free-solid-svg-icons';
import Tooltip from '@mui/material/Tooltip';
import { useSelector } from 'react-redux';
// import { IoIosPrint } from "react-icons/io";
import ReactGrid from "../../OtherComponent/ReactGrid/ReactGrid";
import ArrowBackIosNewIcon from '@mui/icons-material/ArrowBackIosNew';
import ArrowForwardIosIcon from '@mui/icons-material/ArrowForwardIos';

const theme = createTheme({
    components: {
        MuiDataGrid: {
            styleOverrides: {
                columnHeader: {
                    backgroundColor: "var(--ProjectColor)",
                    textAlign: 'Center',
                    color: "var(--header-text-color)"
                },
                root: {
                    "& .MuiDataGrid-root .MuiDataGrid-columnHeader, .MuiDataGrid-columnHeaderTitleContainer": {
                        textAlign: 'center',
                        display: 'flex !important',
                        justifyContent: 'center !important'
                    },
                    "& .MuiDataGrid-window": {
                        overflow: "hidden !important",
                    },
                },
                cell: {
                    borderTop: "0px !important",
                    borderBottom: "1px solid  var(--ProjectColor) !important",
                    display: 'flex',
                    justifyContent: 'center'
                },
            },
        },
    },
});

const CaptureSample = () => {
    const userRecord = useSelector((state) => state.userRecord?.UserData);
    console.log('userRecord', userRecord)
    const navigate = useNavigate();
    const [page, setPage] = useState(0);
    const [searchQuery, setSearchQuery] = useState('');
    const [searchQuery1, setSearchQuery1] = useState('');
    const [searchQuery2, setSearchQuery2] = useState('');
    const [searchQuery3, setSearchQuery3] = useState('');
    const [searchQuery4, setSearchQuery4] = useState('');
    const [summa, setsumma] = useState([]);
    const [filteredRows, setFilteredRows] = useState([]);
    const dispatchvalue = useDispatch()
    const [totalPages, setTotalPages] = useState(0); // New state for total pages
    const urllink = useSelector(state => state.userRecord?.UrlLink)


    const pageSize = 10;

  


    useEffect(() => {
    const offset = page * pageSize;
    const departmentCodes = userRecord?.Lab_Department?.join(','); // Convert array to comma-separated string

    const isSearchCleared = !searchQuery && !searchQuery1 && !searchQuery2 && !searchQuery3;
    if (isSearchCleared) {
    axios.get(`${urllink}Lab/getcapturelist?Location=${userRecord?.location}&limit=${pageSize}&offset=${offset}&Department=${departmentCodes}`)
        .then((response) => {
            console.log(response.data);
            const totalrecords = response.data.total_records
            const data = response.data.patients_data.map((row, index) => ({
                id: index + 1, // Assuming you want a sequential ID
                ...row,
                status: "Status"
            }));
            data.sort((a, b) => {
                const invoiceA = parseInt(a.Billing_Invoice.replace(/\D/g, ''), 10);
                const invoiceB = parseInt(b.Billing_Invoice.replace(/\D/g, ''), 10);
                return invoiceB - invoiceA;
            });
            setFilteredRows([])
            setTotalPages(0)
            setsumma(data);
            setTotalPages(Math.ceil(totalrecords / pageSize));
        })
        .catch((error) => {
            console.error('Error fetching data:', error);
        });
    } else {
            console.log("Performing search...");
            // Perform search
            fetchSearchData();
          }
}, [urllink, userRecord,userRecord?.Department, page, searchQuery, searchQuery1, searchQuery2, searchQuery3, searchQuery4]);


const fetchSearchData = async () => {
    
    try {
      // Check if at least one search query is provided
      if (!searchQuery && !searchQuery1 && !searchQuery2 && !searchQuery3 && !searchQuery4) {
        
        return; // Stop execution if no input is given
      }
  
      
      const response = await axios.get(`${urllink}Lab/getsearchdataforphelobotomist`, {
        params: {
          name: searchQuery,
          patientid: searchQuery1,
          barcode: searchQuery2,
          invoice: searchQuery3,
          Location:userRecord.userRecord?.location,
          Department:userRecord?.Department,
          SubDepartment_Name:searchQuery4,

        },
      });
      const totalrecords = response.data.total_records
      const data = response.data.patients_data.map((row, index) => ({
        id: index + 1, // Assuming Patient_Id is the unique identifier
        ...row,
        status: 'Status',
      }));

      data.sort((a, b) => {
        const invoiceA = parseInt(a.Billing_Invoice.replace(/\D/g, ''), 10);
        const invoiceB = parseInt(b.Billing_Invoice.replace(/\D/g, ''), 10);
        return invoiceB - invoiceA;
      });
      setsumma([]);
      setTotalPages(0)
      setFilteredRows(data); // Set filtered search results into filteredRows
      setTotalPages((Math.ceil(totalrecords / pageSize)))

    } catch (error) {
      console.error('Error fetching search data:', error);
    }
  }; 

    


    const handleSearchChange = (event, type) => {
        const value = event.target.value;
        if (type === 'name') {
            setSearchQuery(value);
        }
        if (type === 'patientid') {
            setSearchQuery1(value);
        }
        if (type==='barcode'){
            setSearchQuery2(value)
        }
        if(type === 'invoice'){
                setSearchQuery3(value)
        }
        if(type === 'departmentsearch'){
                setSearchQuery4(value)
        }
    };


    const handleSampleCapture = (params) => {
        console.log(params)
        const data = params
        dispatchvalue({ type: 'Capturesample', value: data });
        if(data.Bill_status === "Paid" || "Due"){
            dispatchvalue({ type: "HrFolder", value: "phelobotomistnavigation" });
        }
    };


    const dynamicColumns = [
        { key: 'Barcode', headerName: 'Sample Barcode', width: 150 },

        { key: 'Billing_Invoice', headerName: 'Invoice', width: 150 },
        { key: 'billdept', headerName: 'Dept', width: 150 },
        { key: 'Patient_Id', headerName: 'Patient Id', width: 80 },
        { key: 'UpdatedAt', headerName: 'Date', width: 100 },
        { key: 'Patient_Name', headerName: 'Patient Name', width: 150 },
        { key: 'Age', headerName: 'Age', width: 80 },
        { key: 'Gender', headerName: 'Gender', width: 100 },

        {
            key: 'actions',
            headerName: 'Options',
            width: 100,
            renderCell: (params) => (
                <>
                    <Button className='cell_btn' onClick={() => handleSampleCapture(params.row)}>
                        <ForwadIcon />
                    </Button>
                </>
            ),
        },
        { key: 'Phone', headerName: 'Phone', width: 120 },
        // { key: 'Patient_Group', headerName: 'Patient Group', width: 150 },
        { key: 'Refering_Doctor', headerName: 'Reference Doctor', width: 120 },
        // { key: 'Test_Name', headerName: 'Test Name', width: 150 },
        { key: 'TestCount', headerName: 'Test Count', width: 100 },



        
        {
            key: 'status', // Ensure this matches the key in your data
            headerName: 'Status',
            width: 150,
            renderCell: (params) => {
                // Handle possibly undefined Service_Statuses
                const serviceStatuses = params.row.Service_Statuses || [];
                return (
                    <Tooltip title={
                        <>
                            {serviceStatuses.map((item, index) => (
                                <div key={index}>{item.testname}: {item.status}</div>
                            ))}
                        </>
                    } arrow>
                        <span>{params.row.status}</span>
                    </Tooltip>
                );
            },
        },

    ];






    return (
        <>
            <div className="appointment">
                <div className="h_head">
                    <h3 style={{color:"white"}}>Sample Collection List</h3>

                </div>
                <div className="con_1 ">
                    <div className="inp_1">
                        <label htmlFor="input">Patient Name :</label>
                        <input type="text" value={searchQuery} onChange={(e) => handleSearchChange(e, 'name')} placeholder='Enter the Patient Name' />
                    </div>
                    <div className="inp_1">
                        <label htmlFor="input">patientid :</label>
                        <input type="text" value={searchQuery1} onChange={(e) => handleSearchChange(e, 'patientid')} placeholder='Enter patientid' />
                    </div>
                    <div className="inp_1">
            <label htmlFor="input">Barcode</label>
            <input
                id="input"
                type="text"
                value={searchQuery2}
                onChange={(e) => handleSearchChange(e, 'barcode')}
                placeholder='Enter Barcode Number'
            />
        </div>
        <div className="inp_1">
            <label htmlFor="input">Invoice No</label>
            <input
                id="input"
                type="text"
                value={searchQuery3}
                onChange={(e) => handleSearchChange(e, 'invoice')}
                placeholder='Enter Invoice Number'
            />
        </div>

                </div>
                <div className='grid_1'>
                    
                        <ReactGrid
                            RowData ={filteredRows.length > 0 ? filteredRows : summa}
                            columns={dynamicColumns}
                            hidePagination={true}
                            className='data_grid'
                        />
                        
                   <div className="pagination-controls">
                                    <button
                                        onClick={() => setPage((prevPage) => Math.max(prevPage - 1, 0))}
                                        disabled={page === 0}
                                        className="pagination-button"
                                    >
                                        <ArrowBackIosNewIcon />
                                    </button>
                                    Page {page + 1} of {totalPages}
                                    <button
                                        onClick={() => setPage((prevPage) => (prevPage + 1 < totalPages ? prevPage + 1 : prevPage))}
                                        disabled={page + 1 >= totalPages}
                                        className="pagination-button"
                                    >
                                        <ArrowForwardIosIcon />
                                    </button>
                                </div>
                                {summa.length === 0 && filteredRows.length === 0 && (
                                    <div className="IP_norecords">
                                        <span>No Records Found</span>
                                    </div>
                                )}
                </div>
            </div>
        </>
    );
}

export default CaptureSample;
