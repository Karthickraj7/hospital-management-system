import * as React from 'react';
import { useEffect, useState } from 'react';
import axios from 'axios';
import { FaPrint } from 'react-icons/fa';
import Button from '@mui/material/Button';
import { useNavigate } from 'react-router-dom';
import { useSelector, useDispatch } from 'react-redux';
import VisibilityIcon from "@mui/icons-material/Visibility";
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import ExpandLessIcon from '@mui/icons-material/ExpandLess';
import ReactGrid from "../../OtherComponent/ReactGrid/ReactGrid";
import ArrowBackIosNewIcon from '@mui/icons-material/ArrowBackIosNew';
import ArrowForwardIosIcon from '@mui/icons-material/ArrowForwardIos';
import ToastAlert from "../../OtherComponent/ToastContainer/ToastAlert";
import Tooltip from '@mui/material/Tooltip';
import LayersIcon from '@mui/icons-material/Layers';

const Patienttestlist = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const dispatchvalue = useDispatch();

  const today = new Date().toISOString().slice(0, 10);

  const [searchQuery, setSearchQuery] = useState('');
  const [searchQuery1, setSearchQuery1] = useState('');
  const [searchQuery2, setSearchQuery2] = useState('');
  const [searchQuery3, setSearchQuery3] = useState('');
  const [searchQuery4, setSearchQuery4] = useState('currentdate');
  const [searchQuery5, setSearchQuery5] = useState(today);
  const [searchQuery6, setSearchQuery6] = useState('');
  const [searchQuery7, setSearchQuery7] = useState('');
  const [searchQuery8, setSearchQuery8] = useState('');

  const [statusFilter, setStatusFilter] = useState(''); // New state for status filter

  const [viewtest, setViewtest] = useState([]);
  const [openModal, setOpenModal] = useState(false);
  const [expandedTest, setExpandedTest] = useState(null);
  const isSidebarOpen = useSelector((state) => state.userRecord?.isSidebarOpen);
  const [filteredRows, setFilteredRows] = useState([]);
  const urllink = useSelector(state => state.userRecord?.UrlLink);
  const userRecord = useSelector(state => state.userRecord?.UserData);
  const PageSize = 10;
  const [page, setPage] = useState(0);
  const [totalPages, setTotalPages] = useState(0);
  const [statusCount, setStatusCount] = useState({});

  console.log("Record---------->>>>", userRecord);

  const toast = useSelector((state) => state.userRecord?.toast);

  // Define status colors
  const statusColors = {
    captureSample: '#FFD700', // Yellow for Service_Status (Pending)
    labTechnician: '#FFA500', // Orange for Analysis_Status (Pending)
    seniorTechnician: '#1E90FF', // Blue for Verify_Status (Pending)
    pathologist: '#800080', // Purple for Approve_Status (Pending)
    completed: '#008000', // Green for all completed
  };

  useEffect(() => {
    const offset = page * PageSize;
    const limit = PageSize;
    const department = Array.isArray(userRecord?.Lab_Department)
      ? userRecord.Lab_Department.filter(Boolean).join(',')
      : '';
    const fetchData = async () => {
      try {
        const response = await axios.get(`${urllink}Lab/get_patienttestlist`, {
          params: {
            Location: userRecord?.location,
            limit,
            offset,
            patient_name: searchQuery,
            phone: searchQuery1,
            barcode: searchQuery2,
            invoice: searchQuery3,
            departments: department,
            dateType: searchQuery4,
            date: searchQuery5,
            from: searchQuery6,
            to: searchQuery7,
            patient:searchQuery8,
          },
        });
        let data = response.data.data.map((row, index) => ({
          id: index,
          ...row,
        }));
        data.sort((a, b) => {
          const invoiceA = parseInt(a.Billing_Invoice.replace(/\D/g, ''), 10);
          const invoiceB = parseInt(b.Billing_Invoice.replace(/\D/g, ''), 10);
          return invoiceB - invoiceA;
        });

        // Apply status filter if one is selected
        if (statusFilter) {
          data = data.filter((row) => {
            if (statusFilter === 'total') return true; // Show all for Total Patients
            if (statusFilter === 'collection' && row.Service_Status === 'Pending') return true;
            if (statusFilter === 'analysis' && row.Analysis_Status === 'Pending') return true;
            if (statusFilter === 'verify' && row.Verify_Status === 'Pending') return true;
            if (statusFilter === 'approve' && row.Approve_Status === 'Pending') return true;
            if (statusFilter === 'completed' && row.Approve_Status === 'Completed') return true;
            return false;
          });
        }

        setFilteredRows(data);
        setTotalPages(Math.ceil(response.data.total_records / PageSize));
      } catch (error) {
        console.error('Error fetching data:', error);
        setFilteredRows([]);
        setTotalPages(0);
      }
    };
    fetchData();
  }, [
    urllink,
    userRecord,
    page,
    dispatchvalue,
    searchQuery,
    searchQuery1,
    searchQuery2,
    searchQuery3,
    searchQuery4,
    searchQuery5,
    searchQuery6,
    searchQuery7,
    searchQuery8,
    statusFilter, // Add statusFilter as a dependency
  ]);

  useEffect(() => {
    const department = Array.isArray(userRecord?.Lab_Department)
      ? userRecord.Lab_Department.filter(Boolean).join(',')
      : '';
    axios
      .get(`${urllink}Lab/get_status_count`, {
        params: {
          Location: userRecord?.location,
          departments: department,
          dateType: searchQuery4,
          date: searchQuery5,
          from: searchQuery6,
          to: searchQuery7,
        },
      })
      .then((response) => {
        console.log(response.data);
        setStatusCount(response.data);
      })
      .catch((error) => {
        console.error('Error fetching data:', error);
      });
  }, [urllink, userRecord?.location, userRecord?.Lab_Department, searchQuery4, searchQuery5, searchQuery6, searchQuery7]);

  const handleSearchChange = (event, type) => {
    const value = event.target.value;
    if (type === 'name') setSearchQuery(value);
    else if (type === 'phone') setSearchQuery1(value);
    else if (type === 'barcode') setSearchQuery2(value);
    else if (type === 'invoice') setSearchQuery3(value);
    else if (type === 'dateType') setSearchQuery4(value);
    else if (type === 'date') setSearchQuery5(value);
    else if (type === 'fromdate') setSearchQuery6(value);
    else if (type === 'todate') setSearchQuery7(value); 
    else if (type === 'PatientType') setSearchQuery8(value); 
  };

const handleBarcodeReprint = (params) => {
  console.log(params);
  dispatchvalue({ type: 'PrintBarcode', value: params });
  dispatchvalue({ type: 'setActiveFolder', value: 'BarcodePrint' });
};

const handleviewtest = (params) => {
  console.log('Params:', params);
  const testData = params?.Test_Names.map((test, index) => ({
    id: index,
    testname: test.Test_Name,
    subTests: test.SubTests || [],
    department: test.department,
  }));
  console.log('Test Data for Modal:', testData);
  setViewtest(testData);
  setExpandedTest(null);
  setOpenModal(true);
};

const toggleSubTests = (testId) => {
  setExpandedTest(expandedTest === testId ? null : testId);
};

const handlePress = (params) => {
  console.log('Params--------', params.row);
  const Access = userRecord.AccessTwo.split(',');
  console.log(typeof Access);

  let key = '';
  let page = '';

  if (params.row.Service_Status === 'Pending') {
    key = 'L12-1';
    page = 'Phelobotomist';
  } else if (params.row.Analysis_Status === 'Pending') {
    key = 'L12-2';
    page = 'LabTechnician';
  } else if (params.row.Verify_Status === 'Pending') {
    key = 'L12-3';
    page = 'SrTechnician';
  } else if (params.row.Approve_Status === 'Pending') {
    key = 'L12-4';
    page = 'Pathologist';
  } else {
    key = 'L12-5';
    page = 'Dispatch';
  }
  if (Access.includes(key)) {
    dispatchvalue({ type: 'setPreviousFolder', value: 'Patienttestlist' });
    dispatchvalue({ type: 'setActiveFolder', value: page });
    const nav = {
      name: params.row.Patient_Name,
      date: params.row.CreatedAt,
    };
    console.log('Key--------', nav);

    dispatchvalue({ type: 'searchLab', value: nav });
  } else {
    const tdata = {
      message: `Access Denied`,
      type: 'warn',
    };
    dispatchvalue({ type: 'toast', value: tdata });
  }
};

const getStatusColor = (row) => {
  if (row.Service_Status === 'Pending') return statusColors.captureSample;
  if (row.Analysis_Status === 'Pending') return statusColors.labTechnician;
  if (row.Verify_Status === 'Pending') return statusColors.seniorTechnician;
  if (row.Approve_Status === 'Pending') return statusColors.pathologist;
  return statusColors.completed;
};

// New function to handle status click and filter rows
const handleStatusClick = (status) => {
  setStatusFilter(status);
  setPage(0); // Reset to first page when filter changes
};

const dynamicColumns = [
  { key: 'CreatedAt', name: 'Date', width: 70, frozen: true },
  {
    key: 'Billing_Invoice',
    name: 'OP/IP No',
    frozen: true,
    width: 140,
  },
  { key: 'Barcode', name: 'Sample Barcode', frozen: true, width: 70 },
  { key: 'Patient_Id', name: 'Patient Id', frozen: true, width: 70 },
  { key: 'Visit_Id', name: 'Visit ID', width: 70 },
  { key: 'Patient_Name', name: 'Patient Name', width: 90 },
  { key: 'Age', name: 'Age', width: 50 },
  { key: 'Phone', name: 'Phone No', width: 80 },
  {
    key: 'Status',
    name: 'Status',
    width: 100,
    renderCell: (params) => (
      <div
        style={{
          backgroundColor: getStatusColor(params.row),
          color: '#fff',
          textAlign: 'center',
          padding: '4px',
          borderRadius: '4px',
          cursor: 'pointer',
        }}
        onClick={() => handlePress(params)}
      >
        {params.row.Service_Status !== 'Completed'
          ? 'Capture Sample'
          : params.row.Analysis_Status !== 'Completed'
            ? 'Lab Technician'
            : params.row.Verify_Status !== 'Completed'
              ? 'Senior Technician'
              : params.row.Approve_Status !== 'Completed'
                ? 'Pathologist'
                : 'Completed'}
      </div>
    ),
  },
  {
    key: 'Test_Names',
    name: 'Departments',
    width: 90,
    renderCell: (params) => {
      console.log('DEPT---------------', params);
      const testNames = Array.isArray(params.row?.Test_Names) ? params.row.Test_Names : [];
      const testData = Array.from(new Set(testNames.map((test) => test.department || 'Unknown')));
      return (
        <>
          {testData.length > 0 ? (
            testData.map((d) => (
              <div key={d} style={{ fontSize: '10px' }}>
                {d}
              </div>
            ))
          ) : (
            <div>No department</div>
          )}
        </>
      );
    },
  },
  {
    key: 'Test_Names',
    name: 'View Tests',
    width: 70,
    renderCell: (params) => (
      <Button
        onClick={() => handleviewtest(params.row)}
        startIcon={<VisibilityIcon />}
        sx={{ color: 'var(--ProjectColor)', '&:hover': { color: 'var(--ProjectColorhover)' } }}
      />
    ),
  },
  {
    field: 'Action',
    headerName: 'Barcode Reprint',
    width: 120,
    renderCell: (params) => (
      <Button className="cell_btn" style={{ height: '35px' }} onClick={() => handleBarcodeReprint(params.row)}>
        <FaPrint />
      </Button>
    ),
  },
];

return (
  <div className="appointment">
    <ToastAlert Message={toast.message} Type={toast.type} />

    <div className=";alksdfjios" style={{ width: '70% !important' }}>
      <table className="responsive-table-M007" style={{ width: '70% !important' }}>
        <thead>
          <tr>
            <th colSpan={6} style={{ textAlign: 'center' }}>
              Patient Queue Waiting At
            </th>
          </tr>
          <tr>
            <td>
              <div
                style={{
                  backgroundColor: '#ca1f3cff',
                  color: '#fff',
                  textAlign: 'center',
                  padding: '4px',
                  borderRadius: '4px',
                  cursor: 'pointer',
                }}
                onClick={() => handleStatusClick('total')}
              >
                Total Patients
              </div>
            </td>
            <td>
              <div
                style={{
                  backgroundColor: '#FFD700',
                  color: '#fff',
                  textAlign: 'center',
                  padding: '4px',
                  borderRadius: '4px',
                  cursor: 'pointer',
                }}
                onClick={() => handleStatusClick('collection')}
              >
                Sample Capture
              </div>
            </td>
            <td>
              <div
                style={{
                  backgroundColor: '#FFA500',
                  color: '#fff',
                  textAlign: 'center',
                  padding: '4px',
                  borderRadius: '4px',
                  cursor: 'pointer',
                }}
                onClick={() => handleStatusClick('analysis')}
              >
                Lab Technician
              </div>
            </td>
            <td>
              <div
                style={{
                  backgroundColor: '#1E90FF',
                  color: '#fff',
                  textAlign: 'center',
                  padding: '4px',
                  borderRadius: '4px',
                  cursor: 'pointer',
                }}
                onClick={() => handleStatusClick('verify')}
              >
                Senior Technician
              </div>
            </td>
            <td>
              <div
                style={{
                  backgroundColor: '#800080',
                  color: '#fff',
                  textAlign: 'center',
                  padding: '4px',
                  borderRadius: '4px',
                  cursor: 'pointer',
                }}
                onClick={() => handleStatusClick('approve')}
              >
                Pathologist
              </div>
            </td>
            <td>
              <div
                style={{
                  backgroundColor: '#008000',
                  color: '#fff',
                  textAlign: 'center',
                  padding: '4px',
                  borderRadius: '4px',
                  cursor: 'pointer',
                }}
                onClick={() => handleStatusClick('completed')}
              >
                Dispatched
              </div>
            </td>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>{statusCount.total}</td>
            <td>{statusCount.collection}</td>
            <td>{statusCount.analysis}</td>
            <td>{statusCount.verify}</td>
            <td>{statusCount.approve}</td>
            <td>{statusCount.completed}</td>
          </tr>
        </tbody>
      </table>
    </div>
    <div className="h_head">
      <h3>Patient Request List</h3>
    </div>
    <div className="con_1">
      <div className="inp_1">
        <label htmlFor="input">Patient Name :</label>
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => handleSearchChange(e, 'name')}
          placeholder="Enter the Patient Name"
        />
      </div>
      <div className="inp_1">
        <label htmlFor="input">Phone :</label>
        <input
          type="text"
          value={searchQuery1}
          onChange={(e) => handleSearchChange(e, 'phone')}
          placeholder="Enter the Phone Number"
        />
      </div>
      <div className="inp_1">
        <label htmlFor="input">Barcode</label>
        <input
          id="input"
          type="text"
          value={searchQuery2}
          onChange={(e) => handleSearchChange(e, 'barcode')}
          placeholder="Enter Barcode Number"
        />
      </div>
      <div className="inp_1">
        <label htmlFor="input">OP/IP No</label>
        <input
          id="input"
          type="text"
          value={searchQuery3}
          onChange={(e) => handleSearchChange(e, 'invoice')}
          placeholder="Enter Invoice Number"
        />
      </div>
      <div className="inp_1">
        <label htmlFor="input">Patient Type</label>
        <select
          value={searchQuery8}
          onChange={(e) => handleSearchChange(e, "PatientType")}
        >
          <option value={"All"}>All</option>
          <option value={"IP"}>IP</option>
          <option value={"OP"}>OP</option>
        </select>
      </div>

      <div className="inp_1">
        <label htmlFor="input">Date Type</label>
        <select
          value={searchQuery4}
          onChange={(e) => handleSearchChange(e, 'dateType')}
          style={{ width: '165px' }}
        >
          <option value="currentdate">Current</option>
          <option value="customdate">Custom Date</option>
        </select>
      </div>
      {searchQuery4 === 'currentdate' ? (
        <div className="inp_1">
          <label htmlFor="input">Date</label>
          <input
            id="input"
            type="date"
            value={searchQuery5}
            onChange={(e) => handleSearchChange(e, 'date')}
            placeholder="Enter Invoice Number"
          />
        </div>
      ) : (
        <div className="inp_1" style={{ gap: '5px' }}>
          <span style={{ color: 'black', fontSize: '13px', fontWeight: 'bold' }}>From </span>
          <input
            id="input"
            type="date"
            value={searchQuery6}
            onChange={(e) => handleSearchChange(e, 'fromdate')}
            placeholder="From Date"
          />
          <span style={{ color: 'black', fontSize: '13px', fontWeight: 'bold' }}> To </span>
          <input
            id="input"
            type="date"
            value={searchQuery7}
            onChange={(e) => handleSearchChange(e, 'todate')}
            placeholder="To Date"
          />
        </div>
      )}
    </div>

    <div className="grid_1">
      <ReactGrid
        columns={dynamicColumns}
        RowData={filteredRows}
        hidePagination={true}
        className="data_grid"
      />
      <div className="pagination-controls">
        <button
          onClick={() => setPage((prevPage) => Math.max(prevPage - 1, 0))}
          disabled={page === 0}
          className="pagination-button"
        >
          <ArrowBackIosNewIcon />
        </button>
        Page {page + 1} of {totalPages}
        <button
          onClick={() => setPage((prevPage) => (prevPage + 1 < totalPages ? prevPage + 1 : prevPage))}
          disabled={page + 1 >= totalPages}
          className="pagination-button"
        >
          <ArrowForwardIosIcon />
        </button>
      </div>
    </div>

    {openModal && (
      <div
        className={isSidebarOpen ? 'sideopen_showcamera_profile' : 'showcamera_profile'}
        onClick={() => setOpenModal(false)}
      >
        <div
          className="newwProfiles newwPopupforreason uwagduaguleaveauto"
          onClick={(e) => e.stopPropagation()}
        >
          <br />
          <div className="appointment">
            <div className="h_head">
              <h4>Tests</h4>
            </div>
            <div className="Main_container_app">
              <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                <thead>
                  <tr>
                    <th style={{ border: '1px solid #ddd', padding: '8px', width: '70px' }}>S.No</th>
                    <th style={{ border: '1px solid #ddd', padding: '8px', width: '250px' }}>Test Name</th>
                  </tr>
                </thead>
                <tbody>
                  {viewtest.map((test) => (
                    <React.Fragment key={test.id}>
                      <tr>
                        <td style={{ border: '1px solid #ddd', padding: '8px', textAlign: 'center' }}>
                          {test.id + 1}
                        </td>
                        <td style={{ border: '1px solid #ddd', padding: '8px', display: 'flex', alignItems: 'center' }}>
                          <span>{test.testname || 'Unnamed Test'}</span>
                          {test.subTests.length > 0 && (
                            <Button
                              onClick={() => toggleSubTests(test.id)}
                              sx={{ minWidth: '30px', padding: '0', marginLeft: '8px' }}
                            >
                              {expandedTest === test.id ? <ExpandLessIcon /> : <ExpandMoreIcon />}
                            </Button>
                          )}
                        </td>
                      </tr>
                      {expandedTest === test.id &&
                        test.subTests.length > 0 &&
                        test.subTests.map((subTest, idx) => (
                          <tr key={idx}>
                            <td style={{ border: '1px solid #ddd', padding: '8px' }}></td>
                            <td style={{ border: '1px solid #ddd', padding: '8px', paddingLeft: '28px' }}>
                              {subTest.test_name}
                            </td>
                          </tr>
                        ))}
                    </React.Fragment>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
          <div className="Register_btn_con">
            <button className="RegisterForm_1_btns" onClick={() => setOpenModal(false)}>
              Close
            </button>
          </div>
        </div>
      </div>
    )}
    {loading && (
      <div className="spinner-overlay">
        <div className="spinner">
          <div className="rect1"></div>
          <div className="rect2"></div>
          <div className="rect3"></div>
          <div className="rect4"></div>
          <div className="rect5"></div>
        </div>
      </div>
    )}
  </div>
);
};

export default Patienttestlist;