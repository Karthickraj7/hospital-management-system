import axios from "axios";
import React, { useEffect, useState, useMemo } from "react";
import { useDispatch, useSelector } from "react-redux";
import Button from "@mui/material/Button";
import ReactGrid from "../../OtherComponent/ReactGrid/ReactGrid";
import ToastAlert from "../../OtherComponent/ToastContainer/ToastAlert";
import { useNavigate } from "react-router-dom";
import LoupeIcon from "@mui/icons-material/Loupe";
import VisibilityIcon from '@mui/icons-material/Visibility';
import ModelContainer from "../../OtherComponent/ModelContainer/ModelContainer";
import ArrowForwardIcon from "@mui/icons-material/ArrowForward";

const AdvanceRefundList = () => {
  const UrlLink = useSelector((state) => state.userRecord?.UrlLink);
  const UserData = useSelector((state) => state.userRecord?.UserData);
  const toast = useSelector((state) => state.userRecord?.toast);
  const dispatchvalue = useDispatch();
  const navigate = useNavigate();
  const [Filterdataaaaa, setFilterdataaaaa] = useState([]);
  const [AdvanceData, setAdvanceData] = useState([]);
  const formatDate = (date) => {
    const d = new Date(date);
    const month = (d.getMonth() + 1).toString().padStart(2, "0");
    const day = d.getDate().toString().padStart(2, "0");
    const year = d.getFullYear();
    return `${year}-${month}-${day}`;
  };
  const [TodayDate, setTodayDate] = useState(formatDate(new Date()));

  const [searchOptions, setSearchOptions] = useState({
    AdvanceType: "OP",
    DateType: "All",
    CurrentDate: TodayDate,
    FromDate: "",
    ToDate: "",
    // Paymentmode:'',
    SearchbyFirstName: "",
    SearchbyPhoneNumber: "",
    SearchbyPatientId: "",
    SearchbyRegistrationId: "",
    SearchbySpeciality: "",
    SearchbyDoctor: "",
    SearchTimeOrderby: "",
    SearchStatus: "Paid",
  });
  const [selectAdvance, setSelectAdvance] = useState(false);
  const [selectedPatient, setSelectedPatient] = useState({});
  const [Load,setLoad] = useState(false);


  useEffect(() => {
    axios.get(`${UrlLink}Frontoffice/IP_Advance_Refund`, {
      params: { ...searchOptions },
    })
      .then((res) => {
        const ress = res?.data;
        setFilterdataaaaa(Array.isArray(ress) ? ress : []);
      })
      .catch((err) => {
        console.log(err);
        setFilterdataaaaa([]);
      });
  }, [UrlLink, searchOptions,Load]);


  const HandleOnchangeSearch = (e) => {
    const { name, value } = e.target;

    console.log(`Updating ${name} with value:`, value);

    if (name === "SearchbyPhoneNumber") {
      if (value.length <= 10) {
        setSearchOptions((prev) => ({
          ...prev,
          [name]: value,
        }));
      }
    } else if (name === "DateType") {
      if (value === "Current") {
        setSearchOptions((prev) => ({
          ...prev,
          DateType: value,
          CurrentDate: TodayDate, // Ensure TodayDate is properly defined
          FromDate: "",
          ToDate: "",
        }));
      } else if (value === "Customize") {
        setSearchOptions((prev) => ({
          ...prev,
          DateType: value,
          CurrentDate: "",
        }));
      }
      else if (value === 'All') {
        setSearchOptions((prev) => ({
          ...prev,
          DateType: value,
          CurrentDate: '',
          FromDate: '',
          ToDate: '',
        }));
      }
    } else {
      setSearchOptions((prev) => ({
        ...prev,
        [name]: value,
      }));
    }
  };

  //   useEffect(() => {
  //     axios.get(`${UrlLink}Frontoffice/get_overall_advance_details`)
  //         .then((res) => {
  //             const ress = res?.data?.AdvanceDetails

  //             if (Array.isArray(ress)) {
  //               console.log('billllll',ress);

  //                 setFilterdataaaaa(ress);
  //             } else {
  //                 setFilterdataaaaa([]);
  //             }
  //         })
  //         .catch((err) => {
  //             console.log(err);
  //         });
  // }, [UrlLink]);

  const handlenewDocRegister = () => {
    dispatchvalue({ type: "Registeredit", value: {} });
    navigate("/Home/CashierFolder");
    dispatchvalue({ type: "HrFolder", value: "AdvanceCollection" });
    dispatchvalue({ type: "setPreviousFolder", value: null });
    dispatchvalue({ type: "showMenu", value: true });
  };



const PatientIPRegisterColumns = useMemo(() => {
  const baseColumns = [
    { key: "Receipt_No", name: "Receipt No" },
    { key: "PatientId", name: "Patient Id" },
    { key: "RegistrationId", name: searchOptions.AdvanceType === 'IP' ? "IP No" : "OP No" },
    { key: "PatientName", name: "Patient Name" },
    { key: "PhoneNo", name: "Phone No" },
    { key: "Date", name: "Date / Time" },
    { key: "Amount", name: "Amount" },
    // { key: "isRefferal", name: "isRefferal" },
    // { key: "Specilization", name: "Specialization" },
    // { key: "DoctorName", name: "Doctor Name" },
    {
  key: "Refund Advance",
  name: "Refund Advance",
  renderCell: (params) => {
    if (params.row.Status === "Approved") {
      // Show Action button instead of View
      return (
        <Button
          className="cell_btn"
          onClick={() => {
            if (UserData?.Edit) {
              handleNewAdvanceCollection(params.row); // navigate function
            }
          }}
        >
          <ArrowForwardIcon className="check_box_clrr_cancell" />
        </Button>
      );
    }

    // Default View button
    return (
      <Button
        className="cell_btn"
        onClick={() => {
          if (UserData?.Edit) {
            handleAdvanceView(params.row); // view function
          }
        }}
      >
        <VisibilityIcon className="check_box_clrr_cancell" />
      </Button>
    );
  },
}

    // {
    //   key: "Refund Advance",
    //   name: "Refund Advance",
    //   renderCell: (params) => (
    //     <Button
    //       className="cell_btn"
    //       onClick={() => {
    //         if (UserData?.Edit) {
    //           handleNewAdvanceCollection(params.row);
    //         }
    //       }}
    //     >
    //       <ArrowForwardIcon className="check_box_clrr_cancell" />
    //     </Button>
    //   ),
    // },.get
  ];

  // Add "Room No" only for IP
  if (searchOptions.AdvanceType === 'IP') {
    baseColumns.splice(3, 0, {
      key: "RoomDetails",
      name: "Room No"
    });
  }

  return baseColumns;
},
 [searchOptions.AdvanceType, UserData]);  const AdvanceColumns = [
    {
      key: "id",
      name: "S.No",
    },
    {
      key: "PatientId",
      name: "Patient Id",
    },
    {
      key: "PatientName",
      name: "Patient Name",
    },
    {
      key: "RegistrationId",
      name: "Registration Id",
    },

    {
      key: "PhoneNo",
      name: "PhoneNo",
    },
    {
      key: "AdvanceAmount",
      name: "Advance Amount",
    },
    {
      key: "Date",
      name: "Date",
    },
    {
      key: "Time",
      name: "Time",
    },
    {
      key: "ReceivedBy",
      name: "Received By",
    },
  ];

  const handleAdvanceView = (row) => {
    console.log("Icon clickedddd");
    setSelectedPatient(row)
    setSelectAdvance(true);
    if (row) {
      axios.get(`${UrlLink}Frontoffice/get_overall_advance_details?RegistrationId=${row.RegistrationId}&Type=${row.type}`)
        .then((res) => {
          const ress = res?.data?.AdvanceDetails

          if (Array.isArray(ress)) {
            console.log('advanceeeee', ress);

            setAdvanceData(ress);
          } else {
            setAdvanceData([]);
          }
        })
        .catch((err) => {
          console.log(err);
        });
    }
  }

  const handleNewAdvanceCollection = (row) => {
    dispatchvalue({ type: "AdvanceDetails", value: row });
    console.log('paramssss', row);
    navigate("/Home/CashierFolder");
    dispatchvalue({ type: "HrFolder", value: "AdvanceRefundPage" });
    dispatchvalue({ type: "setPreviousFolder", value: null });
    dispatchvalue({ type: "showMenu", value: true });
  }

  const handleAdvanceRequest = () =>{
      // const userConfirmed = window.confirm("Do you want to refund this advance?");

      // if (!userConfirmed) {
      //   return; // Stop execution if the user clicks "No"
      // }

      const submitdata = {
        ...searchOptions,
        selectAdvance : selectAdvance,
        selectedPatient : selectedPatient,
        Status : 'RefundRequest'
      }

      console.log(submitdata,'submitdata')

      axios
      .post(`${UrlLink}Frontoffice/IP_Advance_Refund_Request`, submitdata)
      .then((resp) => {
        const response = resp.data;
        console.log(response,'response');

        const messageType = Object.keys(response)[0];
        const messageContent = Object.values(response)[0];
        setSelectAdvance(false);
        setLoad((prev) => !prev);

        dispatchvalue({
                    type: 'toast',
                    value: { message: messageContent, type: messageType },
                });
        

      })
      .catch((e) => console.log(e));




  }

  const handleAdvanceApproved = () => {

    const submitdata = {
        ...searchOptions,
        selectAdvance : selectAdvance,
        selectedPatient : selectedPatient,
        Status : 'Approved'

      }

      console.log(submitdata,'submitdata')

      axios
      .post(`${UrlLink}Frontoffice/IP_Advance_Refund_Request`, submitdata)
      .then((resp) => {
        const response = resp.data;
        console.log(response,'response');

        const messageType = Object.keys(response)[0];
        const messageContent = Object.values(response)[0];
        setSelectAdvance(false);
        setLoad((prev) => !prev);

        dispatchvalue({
                    type: 'toast',
                    value: { message: messageContent, type: messageType },
                });
        

      })
      .catch((e) => console.log(e));

  }


  return (
    <>
      <div className="Main_container_app">
        <h3>Advance Refund Request List</h3>

        <div className="RegisFormcon_1" style={{ marginBottom: "10px" }}>
          <div className="RegisForm_1">
            <label>
              Advance Type<span>:</span>
            </label>
            <select
              name="AdvanceType"
              value={searchOptions.AdvanceType}
              onChange={HandleOnchangeSearch}
            >
              <option value="OP">OP</option>
              <option value="IP">IP</option>
            </select>
          </div>
          <div className="RegisForm_1">
            <label>
              Date Type<span>:</span>
            </label>
            <select
              name="DateType"
              value={searchOptions.DateType}
              onChange={HandleOnchangeSearch}
            >
              <option value='All'>All</option>
              <option value="Current">Current Date</option>
              <option value="Customize">Customize</option>
            </select>
          </div>

          {searchOptions.DateType === 'Current' && (
            <div className="RegisForm_1">
              <label>Current Date<span>:</span></label>
              <input
                type='date'
                name='CurrentDate'
                value={searchOptions.CurrentDate}
                onChange={HandleOnchangeSearch}
                readOnly
              />

            </div>
          )}

          {searchOptions.DateType === 'Customize' && (
            <>
              <div className="RegisForm_1">
                <label>From Date<span>:</span></label>
                <input
                  type='date'
                  name='FromDate'
                  value={searchOptions.FromDate}
                  onChange={HandleOnchangeSearch}
                />

              </div>

              <div className="RegisForm_1">
                <label>To Date<span>:</span></label>
                <input
                  type='date'
                  name='ToDate'
                  value={searchOptions.ToDate}
                  onChange={HandleOnchangeSearch}
                  min={searchOptions.FromDate}
                />

              </div>
            </>
          )}

          <div className="RegisForm_1">
            <label htmlFor="input">
              Patient ID<span>:</span>
            </label>
            <input
              type="text"
              name="SearchbyPatientId"
              value={searchOptions.SearchbyPatientId}
              onChange={HandleOnchangeSearch}
            />
          </div>
          <div className="RegisForm_1">
            <label htmlFor="input">
              Registration ID<span>:</span>
            </label>
            <input
              type="text"
              name="SearchbyRegistrationId"
              value={searchOptions.SearchbyRegistrationId}
              onChange={HandleOnchangeSearch}
            />
          </div>
          <div className="RegisForm_1">
            <label htmlFor="input">
               Patient Name<span>:</span>
            </label>
            <input
              type="text"
              name="SearchbyFirstName"
              value={searchOptions.SearchbyFirstName}
              onChange={HandleOnchangeSearch}
            />
          </div>
          <div className="RegisForm_1">
            <label htmlFor="input">
              Phone No<span>:</span>
            </label>
            <input
              type="text"
              name="SearchbyPhoneNumber"
              value={searchOptions.SearchbyPhoneNumber}
              onChange={HandleOnchangeSearch}
            />
          </div>

          <div className="RegisForm_1">
            <label htmlFor="input">
              Status<span>:</span>
            </label>
            <select
              name="SearchStatus"
              value={searchOptions.SearchStatus}
              onChange={HandleOnchangeSearch}
            >
              <option value="Paid">Paid</option>
              <option value="RefundRequest">RefundRequest</option>
              <option value="Approved">Approved</option>
            </select>
          </div>
          <button
            className="search_div_bar_btn_1"
            onClick={handlenewDocRegister}
            title="New Advance Billing"
          >
            <LoupeIcon />
          </button>
        </div>


        <ReactGrid columns={PatientIPRegisterColumns} RowData={Filterdataaaaa} />
      </div>
      {selectAdvance && (
        <div className="loader" onClick={() => setSelectAdvance(false)}>
          <div
            style={{width:'500px', height:'250px', backgroundColor:'whitesmoke'}}
            onClick={(e) => e.stopPropagation()}
          >
            <div style={{textAlign:'center', backgroundColor:'#9d9d9d', marginTop:'5px', borderRadius:'5px'}}>Advance Refund Request</div>
            <div className="RegisFormcon_1">
              <div className="RegisForm_1">
                <label htmlFor="selectDepModal.SelectDepartment">
                  Patient Id <span>:</span>
                </label>
                <span>{selectedPatient?.PatientId}</span>
              </div>
              <div className="RegisForm_1">
                <label htmlFor="selectDepModal.SelectDepartment">
                  {selectedPatient?.type === 'OP' ? "OP No" : "IP No"} <span>:</span>
                </label>
                <span>{selectedPatient?.RegistrationId}</span>
              </div>
              <div className="RegisForm_1">
                <label htmlFor="selectDepModal.SelectDepartment">
                  Patient Name <span>:</span>
                </label>
                <span>{selectedPatient?.PatientName}</span>
              </div>
              <div className="RegisForm_1">
                <label htmlFor="selectDepModal.SelectDepartment">
                  Advance Amount <span>:</span>
                </label>
                <span>{selectedPatient?.Amount}</span>
              </div>
            </div>
            <button style={{marginTop:'50px', cursor:'pointer', padding:'5px 5px'}} onClick={searchOptions.SearchStatus  === 'Paid'? handleAdvanceRequest : handleAdvanceApproved}>
              { searchOptions.SearchStatus  === 'Paid'? 'Refund Request' : 'Approved'} 
            </button>
          </div>
        </div>
      )}

            <ToastAlert Message={toast.message} Type={toast.type} />


      <ModelContainer />
    </>
  );
};

export default AdvanceRefundList;
