




//----------------------grok-----------//


import React, { useState, useEffect } from 'react';
import { Modal, Button, message, Spin } from 'antd';
import JoditRichEditor from './JoditRichEditor';
import { useDispatch, useSelector } from "react-redux";
import axios from "axios";


const DocumentEditor = ({ visible, onClose, documentId, from ,requestid,test }) => {
  const [content, setContent] = useState('');
  const [docName, setDocName] = useState('');
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState(null);
  const dispatchvalue = useDispatch();
  const [completeId, setCompleteId] = useState(null);

  const UrlLink = useSelector((state) => state.userRecord?.UrlLink);

  const Technician = useSelector((state) => state.userRecord?.radiologytech);
  
  
  useEffect(() => {
    if (visible && documentId) {
      setLoading(true);
      setError(null);
      setContent('');
      setDocName('');
      console.log("helllllooooo")
      if (from === 'Technician') {
        console.log("inside the technician");
      axios.get(`${UrlLink}Radiology/Documents_Edit_link?document_id=${documentId}&from=${from}&request=${requestid}&test=${test}`)
                // .then((res) => {
                //   if (!res.ok) {
                //     throw new Error(`HTTP error! Status: ${res.status}`);
                //   }
                //   return res.json();
                // })
                .then((res) => {
                  // console.log('Loading updated content:', res.data);
                  const decodedHtml = atob(res.data.html);
                  // console.log("Decoded HTML:", decodedHtml);
                  setContent(decodedHtml || '<p>No content available.</p>');
                  setDocName(res.data.fileName || 'Untitled Document');
                })
                .catch((error) => {
                  console.error('Error fetching document:', error);
                  setError(`Failed to load document: ${error.message}`);
                  message.error(`Failed to load document: ${error.message}`);
                })
                .finally(() => {
                  setLoading(false);
                });
      }
      else if (from === 'doctor') {
        console.log("inside the doctor");
      axios.get(`${UrlLink}Radiology/Documents_Edit_link?document_id=${documentId}&from=${from}&request=${requestid}&test=${test}`)
        .then((res) => {
          console.log("Response Data:", res.data);
          function padBase64(base64) {
            base64 = base64.trim().replace(/\s/g, '');
            const padding = 4 - (base64.length % 4);
            return base64 + '='.repeat(padding % 4);
          }
          let decodedHtml = '';
          try {
            const paddedHtml = padBase64(res.data.html);
            decodedHtml = atob(paddedHtml);
            console.log("Decoded HTML:", decodedHtml);
          } catch (e) {
            console.error("Base64 decoding failed:", e.message);
            decodedHtml = '<p>Unable to decode content. Invalid format.</p>';
          }
          // console.log("Decoded HTML:", decodedHtml);
          setContent(decodedHtml || '<p>No content available.</p>');
          setDocName(res.data.fileName || 'Untitled Document');
          setCompleteId(res.data.completeId || null);
        })
        .catch((error) => {
          console.error('Error fetching document:', error);
          setError(`Failed to load document: ${error.message}`);
          message.error(`Failed to load document: ${error.message}`);
        })
        .finally(() => {
          setLoading(false);
        });
      }
      else {
           axios.get(`${UrlLink}Radiology/Documents_Edit_link?document_id=${documentId}&from=${from}&request=${requestid}&test=${test}`)
                
                .then((res) => {
                  // console.log('Loading updated content:', res.data);
                  const decodedHtml = atob(res.data.html);
                  // console.log("Decoded HTML:", decodedHtml);
                  setContent(decodedHtml || '<p>No content available.</p>');
                  setDocName(res.data.fileName || 'Untitled Document');
                })
                .catch((error) => {
                  console.error('Error fetching document:', error);
                  setError(`Failed to load document: ${error.message}`);
                  message.error(`Failed to load document: ${error.message}`);
                })
                .finally(() => {
                  setLoading(false);
                });
      }
    }
  }, [visible, documentId, UrlLink,from, requestid, test]);

  console.log(from,"gokkkkul");
    
  const handleSave = async () => {
    if (!documentId) {
      message.error('Document ID is missing. Please try again.');
      return;
    }

    try {
      setSaving(true);
      setError(null);

      const updateData = {
        html: content,
        ReportName: docName,
        completeId: completeId,
      };
      if (from === 'Technician'){
        console.log("inside the technician");
        dispatchvalue({ type: "radiologyhtmlcon", value: updateData });
        if (onClose) onClose(true);
      }
      else if(from === 'doctor'){
        console.log("inside the doctor",updateData);
        dispatchvalue({ type: "radiologyhtmlcon", value: updateData });
        if (onClose) onClose(true);
      }
      else{

         console.log("inside the iiiiiiiiiiii");
        const response = await fetch(`${UrlLink}Radiology/Documents_Edit_link/${documentId}/`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(updateData),
      });

      if (response.ok) {
        message.success('Document saved successfully!');
        if (onClose) onClose(true);
      } else {
        const errorData = await response.json();
        setError(`Save failed: ${errorData.error || 'Unknown error'}`);
        message.error(`Save failed: ${errorData.error || 'Unknown error'}`);
      }}
    } catch (error) {
      console.error('Error saving document:', error);
      setError(`An error occurred while saving: ${error.message}`);
      message.error(`An error occurred while saving: ${error.message}`);
    } finally {
      setSaving(false);
    }
  };

  const handlePrint = () => {
    if (!content) {
      message.error('Nothing to print.');
      return;
    }

    const printWindow = window.open('', '_blank');
    printWindow.document.write(`
      <html>
        <head><title>Print Document - ${docName}</title>
        <style>
          body { font-family: Arial, sans-serif; white-space: pre-wrap; line-height: 1.5; }
          ul, ol { margin-left: 20px; }
          p { margin: 10px 0; }
        </style>
      </head>
      <body>${content}</body>
    </html>
    `);
    printWindow.document.close();
    printWindow.print();
  };

  return (
    <Modal
      title={docName || 'Edit Document'}
      open={visible}
      onCancel={() => onClose?.(false)}
      footer={null}
      width={900}
      style={{ top: 20 }}
      destroyOnClose
    >
      {loading ? (
        <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: 300 }}>
          <Spin size="large" />
        </div>
      ) : error ? (
        <div style={{ textAlign: 'center', color: 'red' }}>
          <p>{error}</p>
          <Button onClick={() => onClose?.(false)}>Close</Button>
        </div>
      ) : (
        <>
          <JoditRichEditor
            initialContent={content}
            onSave={(updatedContent) => {
              console.log('Updated content from Jodit:', updatedContent);
              setContent(updatedContent);
            }}
          />
          <div style={{ textAlign: 'right', marginTop: 10 }}>
            <Button
              type="primary"
              onClick={handleSave}
              loading={saving}
              disabled={saving || !content}
              style={{ marginRight: 8 }}
            >
              Save
            </Button>
            <Button onClick={handlePrint} disabled={!content || saving}>
              Print
            </Button>
          </div>
        </>
      )}
    </Modal>
  );
};

export default DocumentEditor;





