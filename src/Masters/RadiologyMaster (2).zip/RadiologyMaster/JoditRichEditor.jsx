

// -----------------------------------grok---------------------------------//

import React, { useEffect, useRef, useState } from 'react';
import JoditEditor from 'jodit-react';

const JoditRichEditor = ({ initialContent, onSave }) => {
  const editorRef = useRef(null);
  const [content, setContent] = useState(initialContent || '');

  useEffect(() => {
    if (initialContent) {
      setContent(initialContent);
    }
  }, [initialContent]);

  const config = {
    readonly: false,
    height: 500,
    uploader: {
      insertImageAsBase64URI: true,
    },
    preserveWhiteSpace: true,
    cleanHTML: {
      fillEmptyParagraph: false,
      removeEmptyElements: false,
    },
    editorCssClass: 'jodit-document',
    style: {
      fontFamily: 'Arial, sans-serif',
      whiteSpace: 'pre-wrap',
      lineHeight: '1.5',
    },
    showSourceButton: true,
    extraAllowedContent: 'p(*),ul(*),ol(*),li(*),strong(*),em(*),pre(*),h1(*),h2(*),h3(*)',
    buttons: [
      'bold', 'italic', 'underline', 'link', 'source', '|',
      'ul', 'ol', 'image', 'video', '|',
      'undo', 'redo', '|', 'hr', 'formatBlock', 'align', 'about',
    ],
    events: {
      beforeFileUpload: (files) => {
        for (let file of files) {
          const reader = new FileReader();
          reader.onload = function (e) {
            const base64 = e.target.result;
            if (file.type.startsWith('video/')) {
              const videoHTML = `
                <video controls style="max-width:100%">
                  <source src="${base64}" type="${file.type}">
                  Your browser does not support the video tag.
                </video>`;
              editorRef.current?.editor.selection.insertHTML(videoHTML);
            } else {
              editorRef.current?.editor.selection.insertImage(base64, null, file.name);
            }
          };
          reader.readAsDataURL(file);
        }
        return false;
      },
    },
  };

  const handleSave = () => {
    if (onSave) {
      onSave(content);
    }
  };

  return (
    <div>
      <JoditEditor
        ref={editorRef}
        value={content}
        config={config}
        onBlur={(newContent) => {
          setContent(newContent);
        }}
      />
      <button onClick={handleSave} className="btn btn-primary mt-2">
        Save
      </button>
    </div>
  );
};

export default JoditRichEditor;



